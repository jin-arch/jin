import { defineConfig, loadEnv } from "vite";
import react from "@vitejs/plugin-react";
import path from "path";

// https://vite.dev/config/
export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), "");
  /** Local Express (EcoFarm server). Override in .env: VITE_API_PROXY_TARGET */
  const proxyTarget = env.VITE_API_PROXY_TARGET || "http://127.0.0.1:5000";

  return {
    plugins: [react()],
    resolve: {
      alias: {
        "@": path.resolve(__dirname, "./src"),
      },
    },
    server: {
      proxy: {
        // When VITE_API_BASE_URL is unset in dev, requests use relative /api → proxied here
        "/api": {
          target: proxyTarget,
          changeOrigin: true,
        },
      },
    },
  };
});
