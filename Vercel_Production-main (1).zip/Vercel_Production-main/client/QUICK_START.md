# Quick Start Guide

## Getting Started

1. **Install dependencies** (already done):

   ```bash
   npm install
   ```

2. **Start development server**:

   ```bash
   npm run dev
   ```

3. **Build for production**:
   ```bash
   npm run build
   ```

## Adding shadcn/ui Components

```bash
npx shadcn@latest add button
npx shadcn@latest add card
npx shadcn@latest add dialog
npx shadcn@latest add form
```

Components will be added to `src/components/ui/`.

## Project Structure

- **`src/app/`** - App initialization, providers, router
- **`src/routes/`** - React Router route definitions
- **`src/pages/`** - Page components
- **`src/components/`** - Atomic Design components
  - `atoms/` - Basic components (Button, Input)
  - `molecules/` - Simple groups (FormField)
  - `organisms/` - Complex components (Forms)
  - `templates/` - Page layouts
  - `ui/` - shadcn/ui components
- **`src/hooks/`** - Custom React hooks
- **`src/validations/`** - Zod schemas
- **`src/lib/`** - Library configurations
- **`src/utils/`** - Helper functions

## Example Usage

### Creating a Form

1. Create validation schema in `src/validations/`:

```typescript
import { z } from "zod";
export const myFormSchema = z.object({
  name: z.string().min(1, "Name is required"),
});
export type MyFormData = z.infer<typeof myFormSchema>;
```

2. Create form hook in `src/hooks/`:

```typescript
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { myFormSchema, type MyFormData } from "@/validations/my-form";

export function useMyForm() {
  const form = useForm<MyFormData>({
    resolver: zodResolver(myFormSchema),
    defaultValues: { name: "" },
  });

  const onSubmit = (data: MyFormData) => {
    // Handle submission
  };

  return { form, onSubmit: form.handleSubmit(onSubmit) };
}
```

3. Create form component in `src/components/organisms/`:

```typescript
import { useMyForm } from "@/hooks/use-my-form";
import { Button } from "@/components/atoms/button";
import { Input } from "@/components/atoms/input";
import { FormField } from "@/components/molecules/form-field";

export function MyForm() {
  const { form, onSubmit } = useMyForm();
  const {
    register,
    formState: { errors },
  } = form;

  return (
    <form onSubmit={onSubmit}>
      <FormField label="Name" error={errors.name?.message}>
        <Input {...register("name")} />
      </FormField>
      <Button type="submit">Submit</Button>
    </form>
  );
}
```

### Using React Query

```typescript
import { useQuery } from "@tanstack/react-query";

export function useData() {
  return useQuery({
    queryKey: ["data"],
    queryFn: async () => {
      const res = await fetch("/api/data");
      return res.json();
    },
  });
}
```

## Path Aliases

Use `@/` prefix for imports:

- `@/components` → `src/components`
- `@/hooks` → `src/hooks`
- `@/lib` → `src/lib`
- `@/utils` → `src/utils`
- etc.

## Next Steps

1. Review the example form in `src/components/organisms/example-form/`
2. Add your routes in `src/routes/index.tsx`
3. Create your pages in `src/pages/`
4. Add shadcn/ui components as needed
5. Follow Atomic Design principles for component structure
