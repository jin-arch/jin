import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getFeedbacks, deleteFeedback } from "@/services/feedback.service";
import type { Feedback } from "@/constants/feedbacks";

/**
 * Hook to fetch all feedbacks
 */
export function useFeedbacks() {
  return useQuery<Feedback[], Error>({
    queryKey: ["feedbacks"],
    queryFn: getFeedbacks,
    staleTime: 2 * 60 * 1000, // 2 minutes
  });
}

/**
 * Hook to delete a feedback
 */
export function useDeleteFeedback() {
  const queryClient = useQueryClient();

  return useMutation<void, Error, string>({
    mutationFn: deleteFeedback,
    onSuccess: () => {
      // Invalidate and refetch feedbacks after deletion
      queryClient.invalidateQueries({ queryKey: ["feedbacks"] });
      // Also update dashboard count
      queryClient.invalidateQueries({ queryKey: ["dashboard"] });
    },
  });
}
