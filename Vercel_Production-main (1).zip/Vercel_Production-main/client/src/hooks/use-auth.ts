import { useCallback } from "react";

export interface User {
  id: string;
  username: string;
  email: string;
  role: string;
}

export function useAuth() {
  // Read from localStorage on every render so changes after login/logout are observed immediately.
  const getUser = useCallback((): User | null => {
    const userStr = localStorage.getItem("user");
    if (!userStr) return null;
    try {
      return JSON.parse(userStr) as User;
    } catch {
      return null;
    }
  }, []);

  const user = getUser();
  const token = localStorage.getItem("auth_token");
  const isAuthenticated = !!token && !!user;

  const logout = () => {
    localStorage.removeItem("auth_token");
    localStorage.removeItem("user");
    // force a reload so components re-evaluate auth state immediately
    try {
      window.location.reload();
    } catch {
      /* ignore */
    }
  };

  return {
    user,
    token,
    isAuthenticated,
    logout,
  };
}
