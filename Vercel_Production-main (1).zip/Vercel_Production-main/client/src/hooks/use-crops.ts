import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  getCrops,
  getCropById,
  deleteCrop,
  createCrop,
} from "@/services/crop.service";
import type { Crop } from "@/constants/crops";

/**
 * React Query hook to fetch all crops
 */
export function useCrops() {
  return useQuery<Crop[]>({
    queryKey: ["crops"],
    queryFn: getCrops,
  });
}

/**
 * React Query hook to fetch a single crop by ID
 */
export function useCrop(id: string | null) {
  return useQuery<Crop | null>({
    queryKey: ["crop", id],
    queryFn: () => (id ? getCropById(id) : Promise.resolve(null)),
    enabled: !!id,
  });
}

/**
 * React Query hook to delete a crop
 */
export function useDeleteCrop() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: deleteCrop,
    onSuccess: () => {
      // Invalidate and refetch crops list after deletion
      queryClient.invalidateQueries({ queryKey: ["crops"] });
      // Also update dashboard count
      queryClient.invalidateQueries({ queryKey: ["dashboard"] });
    },
  });
}

/**
 * React Query hook to create a new crop
 */
export function useCreateCrop() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: createCrop,
    onSuccess: () => {
      // Invalidate and refetch crops list after creation
      queryClient.invalidateQueries({ queryKey: ["crops"] });
      // Also update dashboard count
      queryClient.invalidateQueries({ queryKey: ["dashboard"] });
    },
  });
}
