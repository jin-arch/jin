import { useQuery } from "@tanstack/react-query";
import {
  getDashboardData,
  type DashboardData,
} from "@/services/dashboard.service";

export function useDashboard() {
  return useQuery<DashboardData, Error>({
    queryKey: ["dashboard"],
    queryFn: getDashboardData,
    staleTime: 5 * 60 * 1000, // 5 minutes
  });
}
