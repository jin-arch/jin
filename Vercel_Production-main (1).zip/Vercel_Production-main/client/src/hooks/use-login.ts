import { useMutation } from "@tanstack/react-query";
import { useNavigate, useLocation } from "react-router-dom";
import {
  loginService,
  type LoginCredentials,
  type LoginResponse,
  type ApiError,
} from "@/services/auth.service";

export function useLogin() {
  const navigate = useNavigate();
  const location = useLocation();

  return useMutation<LoginResponse, ApiError, LoginCredentials>({
    mutationFn: loginService,
    onSuccess: (data) => {
      // Store token and user data (you can use localStorage, cookies, or a state management solution)
      localStorage.setItem("auth_token", data.token);
      localStorage.setItem("user", JSON.stringify(data.user));

      // Redirect to the original destination if available, otherwise dashboard
      const from = (location.state as any)?.from?.pathname || "/dashboard";
      navigate(from, { replace: true });
    },
    onError: (error) => {
      // Error handling is done in the component
      console.error("Login error:", error);
    },
  });
}
