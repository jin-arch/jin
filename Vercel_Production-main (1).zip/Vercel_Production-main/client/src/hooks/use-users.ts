import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getUsers, deleteUser, uploadUserProfilePhoto, disableUser } from "@/services/user.service";
import type { User } from "@/constants/users";

/**
 * Hook to fetch all users
 */
export function useUsers() {
  return useQuery<User[], Error>({
    queryKey: ["users"],
    queryFn: getUsers,
    staleTime: 2 * 60 * 1000, // 2 minutes
  });
}

/**
 * Hook to delete a user
 */
export function useDeleteUser() {
  const queryClient = useQueryClient();

  return useMutation<void, Error, string>({
    mutationFn: deleteUser,
    onSuccess: () => {
      // Invalidate and refetch users after deletion
      queryClient.invalidateQueries({ queryKey: ["users"] });
      // Also update dashboard count
      queryClient.invalidateQueries({ queryKey: ["dashboard"] });
    },
  });
}

/**
 * Hook to disable/enable a user (admin action)
 */
export function useDisableUser() {
  const queryClient = useQueryClient();

  return useMutation<{ success: boolean; uid?: string; disabled?: boolean }, Error, { id: string; disabled?: boolean }>(
    {
      mutationFn: ({ id, disabled = true }) => disableUser(id, disabled),
      // Optimistic update: update users list immediately
      onMutate: async ({ id, disabled = true }) => {
        await queryClient.cancelQueries({ queryKey: ["users"] });
        const previous = queryClient.getQueryData<User[]>(["users"]);
        if (previous) {
          queryClient.setQueryData<User[]>(["users"], (old = []) =>
            old.map((u) => (u.id === id ? { ...u, status: disabled ? "OFFLINE" : "ACTIVE" } : u))
          );
        }
        return { previous };
      },
      onError: (_err, _variables, context: any) => {
        if (context?.previous) {
          queryClient.setQueryData(["users"], context.previous);
        }
      },
      onSuccess: (data) => {
        // Reconcile cache with server response when available
        if (data && typeof data.disabled === 'boolean') {
          queryClient.setQueryData<User[] | undefined>(["users"], (old) => {
            if (!old) return old;
            return old.map((u) => (u.id === data.uid ? { ...u, status: data.disabled ? 'OFFLINE' : 'ACTIVE' } : u));
          });
        }
      },
      onSettled: () => {
        queryClient.invalidateQueries({ queryKey: ["users"] });
        queryClient.invalidateQueries({ queryKey: ["dashboard"] });
      },
    }
  );
}

export function useUploadUserPhoto() {
  const queryClient = useQueryClient();

  return useMutation<
    { photoURL: string },
    Error,
    { userId: string; file: File }
  >({
    mutationFn: ({ userId, file }) => uploadUserProfilePhoto(userId, file),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["users"] });
    },
  });
}
