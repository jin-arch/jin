import { useQuery } from "@tanstack/react-query";

// Example API function
async function fetchExampleData() {
  const response = await fetch("/api/example");
  if (!response.ok) {
    throw new Error("Failed to fetch data");
  }
  return response.json();
}

// Example React Query hook
export function useQueryExample() {
  return useQuery({
    queryKey: ["example"],
    queryFn: fetchExampleData,
  });
}
