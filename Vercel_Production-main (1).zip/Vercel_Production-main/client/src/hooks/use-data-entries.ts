import { useQuery } from "@tanstack/react-query";
import { getDataEntries } from "@/services/data-entry.service";
import type { DataEntry } from "@/constants/data-entries";

export function useDataEntries() {
  return useQuery<DataEntry[]>({
    queryKey: ["dataEntries"],
    queryFn: getDataEntries,
  });
}
