import { useQuery } from "@tanstack/react-query";
import { fetchAllScans } from "@/services/admin-scan.service";

export function useAdminScans() {
  return useQuery({
    queryKey: ["adminScans"],
    queryFn: fetchAllScans,
    staleTime: 2 * 60 * 1000,
  });
}
