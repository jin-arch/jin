import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  getSoils,
  getSoilById,
  deleteSoil,
  createSoil,
  updateSoil,
} from "@/services/soil.service";
import type { Soil } from "@/constants/soils";

/**
 * React Query hook to fetch all soils
 */
export function useSoils() {
  return useQuery<Soil[]>({
    queryKey: ["soils"],
    queryFn: getSoils,
  });
}

/**
 * React Query hook to fetch a single soil by ID
 */
export function useSoil(id: string | null) {
  return useQuery<Soil | null>({
    queryKey: ["soil", id],
    queryFn: () => (id ? getSoilById(id) : Promise.resolve(null)),
    enabled: !!id,
  });
}

/**
 * React Query hook to delete a soil
 */
export function useDeleteSoil() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: deleteSoil,
    onSuccess: () => {
      // Invalidate and refetch soils list after deletion
      queryClient.invalidateQueries({ queryKey: ["soils"] });
      // Also update dashboard count
      queryClient.invalidateQueries({ queryKey: ["dashboard"] });
    },
  });
}

/**
 * React Query hook to create a new soil
 */
export function useCreateSoil() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: createSoil,
    onSuccess: () => {
      // Invalidate and refetch soils list after creation
      queryClient.invalidateQueries({ queryKey: ["soils"] });
      // Also update dashboard count
      queryClient.invalidateQueries({ queryKey: ["dashboard"] });
    },
  });
}

/**
 * React Query hook to update an existing soil
 */
export function useUpdateSoil() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ id, data }: { id: string; data: Parameters<typeof updateSoil>[1] }) =>
      updateSoil(id, data),
    onSuccess: () => {
      // Invalidate and refetch soils list after update
      queryClient.invalidateQueries({ queryKey: ["soils"] });
      // Also update dashboard count
      queryClient.invalidateQueries({ queryKey: ["dashboard"] });
    },
  });
}
