import { useQuery } from "@tanstack/react-query";
import { getUploadHistory } from "@/services/system.service";
import type { UploadHistoryItem } from "@/constants/system";

export function useUploadHistory() {
  return useQuery<UploadHistoryItem[]>({
    queryKey: ["uploadHistory"],
    queryFn: getUploadHistory,
  });
}
