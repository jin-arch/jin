import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

interface MetricCardProps {
  label: string;
  value: string | number;
  icon?: ReactNode;
  description?: string;
  button?: {
    label: string;
    onClick: () => void;
    hasNotification?: boolean;
    className?: string;
  };
  className?: string;
  variant?: "accent" | "light";
  trend?: {
    value: string;
    isPositive?: boolean;
  };
}

import { TrendingUp, TrendingDown } from "lucide-react";

export function MetricCard({
  label,
  value,
  icon,
  description,
  button,
  className,
  variant = "accent",
  trend,
}: MetricCardProps) {
  const isLight = variant === "light";
  const baseClasses = isLight
    ? "relative overflow-hidden rounded-2xl p-6 shadow-2xl flex flex-col border border-gray-200 bg-white text-gray-800"
    : "relative overflow-hidden rounded-2xl p-6 shadow-[0_18px_40px_rgba(42,123,155,0.18)] flex flex-col border border-white/25 text-white";

  return (
    <div className={cn(baseClasses, className)} style={isLight ? {} : { background: "radial-gradient(120% 120% at 50% 50%, #2A7B9B 0%, #57C785 50%, #EDDD53 100%)" }}>
      {!isLight && (
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(255,255,255,0.24),transparent_40%),radial-gradient(circle_at_bottom_left,rgba(255,255,255,0.12),transparent_36%)]" />
      )}

      {/* Header with icon, label and trend */}
      <div className={cn("relative z-10 flex items-center justify-between mb-4 min-h-[40px]", isLight ? "" : "") }>
        <div className="flex items-center gap-2">
          {icon && <div className={isLight ? "text-black" : "text-white/95"}>{icon}</div>}
          <h3 className={cn("text-sm font-semibold uppercase tracking-wider", isLight ? "text-gray-600" : "text-white")}>{label}</h3>
        </div>
        {trend && (
          <div className={cn("flex items-center text-xs font-semibold", trend.isPositive !== false ? "text-emerald-500" : "text-red-500")}>
            {trend.isPositive !== false ? <TrendingUp className="w-3 h-3 mr-1" /> : <TrendingDown className="w-3 h-3 mr-1" />}
            {trend.value}
          </div>
        )}
      </div>

      {/* Value - centered and large */}
      <div className="relative z-10 flex-1 flex items-center justify-center">
        <p className={cn("text-6xl font-extrabold drop-shadow-[0_2px_8px_rgba(0,0,0,0.12)] tracking-tight", isLight ? "text-gray-900" : "text-white")}>{value}</p>
      </div>

      {/* Description */}
      {description && (
        <p className={cn("relative z-10 text-xs mb-2 text-center", isLight ? "text-gray-500" : "text-white/90")}>{description}</p>
      )}

      {/* Footer area - always reserve space so numbers align across cards */}
      <div className="relative z-10 flex justify-center mt-6 h-8">
        {button ? (
          <button
            onClick={button.onClick}
            className={cn("relative text-xs font-bold px-5 py-1.5 rounded-full shadow-sm transition-colors uppercase tracking-wide", isLight ? "text-white bg-[#4EA466] hover:bg-green-700" : "text-[#2A7B9B] bg-white/95 hover:bg-white", button.className)}
          >
            {button.label}
            {button.hasNotification && (
              <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full border-2 border-white"></span>
            )}
          </button>
        ) : (
          <div aria-hidden className="w-[120px] h-8" />
        )}
      </div>
    </div>
  );
}
