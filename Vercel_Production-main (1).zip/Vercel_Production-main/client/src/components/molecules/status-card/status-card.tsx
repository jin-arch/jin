interface StatusCardProps {
  label: string;
  status: string;
  description: string;
  buttonLabel?: string;
  onButtonClick?: () => void;
}

export function StatusCard({
  label,
  status,
  description,
  buttonLabel,
  onButtonClick,
}: StatusCardProps) {
  return (
    <div
      className="relative overflow-hidden rounded-2xl p-6 shadow-[0_18px_40px_rgba(42,123,155,0.18)] border border-white/25 text-white"
      style={{
        background:
          "radial-gradient(120% 120% at 50% 50%, #2A7B9B 0%, #57C785 50%, #EDDD53 100%)",
      }}
    >
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(255,255,255,0.22),transparent_40%),radial-gradient(circle_at_bottom_left,rgba(255,255,255,0.12),transparent_36%)]" />

      <h3 className="relative z-10 text-sm font-semibold uppercase tracking-[0.2em] mb-4 text-white">
        {label}
      </h3>
      <div className="relative z-10 mb-2">
        <p className="text-3xl font-bold text-white drop-shadow-[0_2px_8px_rgba(0,0,0,0.12)]">
          {status}
        </p>
      </div>
      <p className="relative z-10 text-sm text-white/90 mb-4">{description}</p>
      {buttonLabel && onButtonClick && (
        <button
          onClick={onButtonClick}
          className="relative z-10 text-sm font-semibold text-[#2A7B9B] bg-white/95 hover:bg-white px-4 py-2 rounded-full transition-colors shadow-sm"
        >
          {buttonLabel}
        </button>
      )}
    </div>
  );
}
