import { useState, useEffect } from "react";
import { Sidebar } from "@/components/organisms/sidebar/sidebar";
import { Bell } from "lucide-react";
import { cn } from "@/lib/utils";

interface DashboardLayoutProps {
  children: React.ReactNode;
  title?: string;
  subtitle?: string;
  /** Override main content area padding / background (e.g. denser data pages). */
  mainClassName?: string;
}

export function DashboardLayout({
  children,
  title,
  subtitle,
  mainClassName,
}: DashboardLayoutProps) {
  const [sidebarOpen, setSidebarOpen] = useState(() => {
    const saved = localStorage.getItem("sidebarOpen");
    return saved !== null ? JSON.parse(saved) : true;
  });

  useEffect(() => {
    localStorage.setItem("sidebarOpen", JSON.stringify(sidebarOpen));
  }, [sidebarOpen]);

  return (
    <div className="min-h-screen bg-[linear-gradient(180deg,#f7fbfc_0%,#eef8f1_48%,#f6f4df_100%)]">
      <Sidebar
        isOpen={sidebarOpen}
        onToggle={() => setSidebarOpen(!sidebarOpen)}
      />

      {/* Main content */}
      <div
        className={`transition-all duration-300 ${
          sidebarOpen ? "md:ml-64" : "md:ml-20"
        }`}
      >
        {/* Top bar */}
        <header className="sticky top-0 z-30 border-b border-white/60 bg-white/75 backdrop-blur-xl">
          <div className="flex items-center justify-between px-6 py-4">
            <div className="flex items-center gap-4">
              {title && (
                <div>
                  <h1 className="text-3xl md:text-4xl font-extrabold tracking-tight text-[#1f3b4d]">
                    {title}
                  </h1>
                  {subtitle && (
                    <p className="text-sm text-slate-600 mt-1">{subtitle}</p>
                  )}
                </div>
              )}
            </div>
            <button className="relative text-[#1f3b4d] hover:text-[#2A7B9B]">
              <Bell className="w-6 h-6" />
              <span className="absolute top-0 right-0 w-2 h-2 bg-red-500 rounded-full"></span>
            </button>
          </div>
        </header>

        {/* Page content */}
        <main className={cn("relative p-6", mainClassName)}>
          {children}
          {/* EcoFarm logo fixed to the viewport bottom-right (hidden on very small screens) */}
          <img
            src="/logo.svg"
            alt="EcoFarm"
            className="pointer-events-none fixed right-6 bottom-6 w-60 md:w-72 opacity-100 z-50 hidden sm:block drop-shadow-2xl"
          />
        </main>
      </div>
    </div>
  );
}
