import { useState, useMemo, useEffect } from "react";
import { X, Eye, Trash2 } from "lucide-react";
import type { Feedback } from "@/constants/feedbacks";
import { useFeedbacks, useDeleteFeedback } from "@/hooks/use-feedbacks";
import { useUsers } from "@/hooks/use-users";
import { Pagination } from "@/components/molecules/pagination/pagination";
import { PAGINATION_PAGE_SIZE } from "@/constants/index";

interface FeedbacksModalProps {
  isOpen: boolean;
  onClose: () => void;
  onView?: (feedback: Feedback) => void;
  onDelete?: (feedbackId: string) => void;
}

export function FeedbacksModal({
  isOpen,
  onClose,
  onView,
  onDelete,
}: FeedbacksModalProps) {
  const { data: feedbacks, isLoading, error } = useFeedbacks();
  const deleteMutation = useDeleteFeedback();
  const { data: users } = useUsers();
  const [currentPage, setCurrentPage] = useState(1);

  // Paginate feedbacks
  const displayFeedbacks = useMemo(() => {
    if (!feedbacks) return [];
    const startIndex = (currentPage - 1) * PAGINATION_PAGE_SIZE;
    const endIndex = startIndex + PAGINATION_PAGE_SIZE;
    return feedbacks.slice(startIndex, endIndex);
  }, [feedbacks, currentPage]);

  const totalPages = Math.ceil((feedbacks?.length || 0) / PAGINATION_PAGE_SIZE);

  // Reset to page 1 if current page is out of bounds
  useEffect(() => {
    if (currentPage > totalPages && totalPages > 0) {
      setCurrentPage(1);
    }
  }, [currentPage, totalPages]);

  if (!isOpen) return null;

  const handleView = (feedback: Feedback) => {
    onView?.(feedback);
  };

  const getDisplayName = (feedback: Feedback) => {
    if (feedback.userName) return feedback.userName;
    if (feedback.userId && users) {
      const u = users.find((x) => x.id === feedback.userId || (x.id && x.id === String(feedback.userId)));
      if (u) return u.name;
    }
    return feedback.userId || 'Anonymous';
  };

  const handleDelete = (feedback: Feedback) => {
    if (
      window.confirm(
        `Are you sure you want to delete feedback from ${feedback.userName}?`,
      )
    ) {
      deleteMutation.mutate(feedback.id, {
        onSuccess: () => {
          onDelete?.(feedback.id);
        },
      });
    }
  };

  return (
    <div
      className="fixed inset-0 bg-slate-950/30 backdrop-blur-sm z-50 flex items-center justify-center p-4"
      onClick={onClose}
    >
      {/* Modal */}
      <div
        className="font-['Poppins',sans-serif] relative flex h-full w-full max-w-3xl max-h-[90vh] min-h-0 flex-col overflow-hidden rounded-[26px] border border-slate-200/70 bg-white shadow-[0_28px_80px_rgba(15,23,42,0.18)]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-start justify-between gap-4 border-b border-slate-200/70 bg-slate-50 px-6 py-6">
          <div className="space-y-2">
            <div className="inline-flex items-center rounded-full bg-emerald-50 px-3 py-1 text-xs font-semibold uppercase tracking-[0.24em] text-emerald-700">
              feedbacks
            </div>
            <div>
              <h2 className="text-2xl font-semibold tracking-tight text-slate-950">
                Overview of user feedbacks
              </h2>
              <p className="text-sm text-slate-500 mt-1">
                Review the latest feedback & manage entries at a glance.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="inline-flex h-11 w-11 items-center justify-center rounded-xl border border-slate-200 bg-white text-slate-600 shadow-sm transition hover:bg-slate-100 hover:text-slate-900"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 min-h-0 overflow-y-auto p-6">
          {isLoading ? (
            <div className="flex min-h-[220px] items-center justify-center rounded-3xl border border-dashed border-slate-200 bg-slate-50">
              <p className="text-slate-500">Loading feedbacks...</p>
            </div>
          ) : error ? (
            <div className="flex min-h-[220px] items-center justify-center rounded-3xl border border-dashed border-rose-200 bg-rose-50">
              <p className="text-rose-600">Error loading feedbacks</p>
            </div>
          ) : (
            <div className="space-y-4">
              {displayFeedbacks.map((feedback) => (
                <div
                  key={feedback.id}
                  className="group flex flex-col gap-4 rounded-[20px] border border-slate-200/80 bg-white p-5 shadow-sm transition hover:border-emerald-200 hover:bg-emerald-50/10"
                >
                  <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                    <div className="min-w-0">
                            <p className="text-base font-semibold uppercase tracking-[0.22em] text-emerald-700">
                              {getDisplayName(feedback)}
                            </p>
                            <p className="mt-1 text-sm text-slate-500">{feedback.created_at || feedback.timestamp || ''}</p>
                            <p className="mt-2 text-sm text-slate-900 font-medium">{feedback.title || feedback.subject || ''}</p>
                            <p className="mt-2 text-sm text-slate-500">{(feedback.userId && users && users.find((x) => x.id === feedback.userId)?.email) || feedback.userName || 'Email not provided'}</p>
                    </div>

                    <div className="flex items-center gap-3">
                      {typeof feedback.rating === 'number' && (
                        <div className="inline-flex items-center rounded-full bg-emerald-50 px-2 py-1 text-xs font-semibold text-emerald-700">
                          {feedback.rating}★
                        </div>
                      )}
                      <button
                        onClick={() => handleView(feedback)}
                        disabled={deleteMutation.isPending}
                        className="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-500 text-white shadow-lg shadow-emerald-500/20 transition hover:bg-emerald-600 disabled:opacity-50 disabled:cursor-not-allowed"
                        aria-label={`View feedback from ${getDisplayName(feedback)}`}
                      >
                        <Eye className="w-5 h-5" />
                      </button>
                      <button
                        onClick={() => handleDelete(feedback)}
                        disabled={deleteMutation.isPending}
                        className="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-rose-500 text-white shadow-lg shadow-rose-500/20 transition hover:bg-rose-600 disabled:opacity-50 disabled:cursor-not-allowed"
                        aria-label={`Delete feedback from ${getDisplayName(feedback)}`}
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Pagination - Fixed at bottom */}
        {feedbacks && feedbacks.length > 0 && (
          <div className="border-t border-slate-200/70 bg-slate-50 px-6 py-4">
            <Pagination
              currentPage={currentPage}
              totalPages={totalPages}
              onPageChange={setCurrentPage}
              pageSize={PAGINATION_PAGE_SIZE}
              totalItems={feedbacks.length}
            />
          </div>
        )}
      </div>
    </div>
  );
}
