import { Trash2, Edit } from "lucide-react";
import type { Crop } from "@/constants/crops";
import { Button } from "@/components/atoms/button/button";

interface CropCardProps {
  crop: Crop;
  onEdit?: (crop: Crop) => void;
  onDelete: (cropId: string) => void;
}

export function CropCard({ crop, onEdit, onDelete }: CropCardProps) {
  const handleDelete = () => {
    if (window.confirm(`Are you sure you want to delete ${crop.name}?`)) {
      onDelete(crop.id);
    }
  };

  return (
    <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-4 flex flex-col h-full">
      <div className="flex gap-4 flex-1">
        {/* Image */}
        <div className="flex-shrink-0">
          {crop.imageUrl ? (
            <img
              src={crop.imageUrl}
              alt={crop.name}
              className="w-24 h-24 rounded-lg object-cover border border-gray-200"
              onError={(e) => {
                // Fallback to placeholder if image fails to load
                const target = e.target as HTMLImageElement;
                target.src =
                  "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='96' height='96' viewBox='0 0 96 96'%3E%3Crect fill='%23e5e7eb' width='96' height='96'/%3E%3Ctext x='50%25' y='50%25' dominant-baseline='central' text-anchor='middle' font-family='Arial' font-size='12' fill='%239ca3af'%3ENo Image%3C/text%3E%3C/svg%3E";
              }}
            />
          ) : (
            <div className="w-24 h-24 rounded-lg bg-gray-200 border border-gray-300 flex items-center justify-center">
              <span className="text-xs text-gray-400 text-center px-2">
                No Image
              </span>
            </div>
          )}
        </div>

        {/* Title and Details */}
        <div className="flex-1 flex flex-col">
          {/* Title */}
          <h3 className="text-lg font-bold text-gray-900 mb-3">{crop.name}</h3>

          {/* Details Section - Below the title */}
          <div className="space-y-1 text-sm text-gray-900">
            <p>
              <span className="font-medium">Preferred Soil Type:</span>{" "}
              {crop.preferredSoilType || "Not specified"}
            </p>
            <p>
              <span className="font-medium">Ideal Moisture Level:</span>{" "}
              {crop.idealMoistureLevel || "Not specified"}
            </p>
            <p>
              <span className="font-medium">Recommended Soil Color:</span>{" "}
              {crop.recommendedSoilColor || "Not specified"}
            </p>
          </div>
        </div>
      </div>

      {/* Action Buttons at Bottom */}
      <div className="flex gap-2 mt-4 pt-4 border-t border-gray-100">
        {onEdit && (
          <Button
            onClick={() => onEdit(crop)}
            className="bg-yellow-500 hover:bg-yellow-600 text-black font-semibold px-4 py-2 rounded-lg flex items-center gap-2"
          >
            <Edit className="w-4 h-4" />
            EDIT
          </Button>
        )}
        <Button
          onClick={handleDelete}
          className="bg-red-500 hover:bg-red-600 text-white font-semibold px-4 py-2 rounded-lg flex items-center gap-2"
        >
          <Trash2 className="w-4 h-4" />
          DELETE
        </Button>
      </div>
    </div>
  );
}
