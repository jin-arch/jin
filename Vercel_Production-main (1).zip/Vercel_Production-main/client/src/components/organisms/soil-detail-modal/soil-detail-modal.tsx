import { useState, useRef, useEffect } from "react";
import {
  X,
  Check,
  AlertCircle,
  AlertTriangle,
  Trash2,
  Edit,
  Sprout,
  BrickWall,
  Tag,
  Upload,
  RotateCcw,
} from "lucide-react";
import type { Soil } from "@/constants/soils";
import { Button } from "@/components/atoms/button/button";

interface SoilDetailModalProps {
  isOpen: boolean;
  soil: Soil | null;
  onClose: () => void;
  onDelete?: (soilId: string) => void;
  onEdit?: (soil: Soil) => void;
  onSubmit?: (data: {
    uploadedBy: string;
    location: string;
    tags: string[];
    soilColor: string;
    soilTexture: string;
    suitability: "SUITABLE" | "NEEDS_IMPROVEMENT";
    recommendations: string;
    imageUrl?: string;
  }) => void;
}

export function SoilDetailModal({
  isOpen,
  soil,
  onClose,
  onDelete,
  onEdit,
  onSubmit,
}: SoilDetailModalProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isEditMode, setIsEditMode] = useState(false);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [uploadedBy, setUploadedBy] = useState("");
  const [location, setLocation] = useState("");
  const [tags, setTags] = useState<string[]>([]);
  const [tagInput, setTagInput] = useState("");
  const [showTagsPanel, setShowTagsPanel] = useState(false);
  const [soilColor, setSoilColor] = useState("");
  const [soilTexture, setSoilTexture] = useState("");
  const [suitability, setSuitability] = useState<
    "SUITABLE" | "NEEDS_IMPROVEMENT"
  >("SUITABLE");
  const [recommendations, setRecommendations] = useState("");
  const [showValidateConfirm, setShowValidateConfirm] = useState(false);
  const [showValidationSuccess, setShowValidationSuccess] = useState(false);

  // Predefined tags
  const soilColorTags = [
    "#DarkBrown",
    "#LightBrown",
    "#Reddish",
    "#Grayish",
    "#Black",
  ];
  const soilTextureTags = ["#Loamy", "#Clay", "#Sandy", "#Silt", "#Rocky"];

  // Reset pop-ups when modal closes
  useEffect(() => {
    if (!isOpen) {
      setShowValidateConfirm(false);
      setShowValidationSuccess(false);
    }
  }, [isOpen]);

  // Initialize form data when soil changes or edit mode is enabled
  useEffect(() => {
    if (soil && isEditMode) {
      setUploadedBy(soil.uploadedBy || "");
      setLocation(soil.location || "");
      setTags(soil.tags || []);
      
      // Get soil color - use direct value if exists, otherwise generate from tags
      let colorValue = soil.soilColor?.trim() || "";
      if (!colorValue) {
        const lightBrownTag = soil.tags.find((t) =>
          t.toLowerCase().includes("lightbrown")
        );
        if (lightBrownTag) {
          colorValue = "Light brown to pale → indicates low organic matter and limited fertility.";
        } else {
          const colorTag = soil.tags.find(
            (t) =>
              t.toLowerCase().includes("brown") ||
              t.toLowerCase().includes("reddish") ||
              t.toLowerCase().includes("grayish") ||
              t.toLowerCase().includes("black") ||
              t.toLowerCase().includes("darkbrown")
          );
          if (colorTag) {
            colorValue = `${colorTag.replace("#", "")} – indicates organic matter and fertility level.`;
          } else {
            colorValue = "Not specified – indicates organic matter and fertility level.";
          }
        }
      }
      
      // Get soil texture - use direct value if exists, otherwise generate from tags
      let textureValue = soil.soilTexture?.trim() || "";
      if (!textureValue) {
        const clayTag = soil.tags.find((t) => t.toLowerCase().includes("clay"));
        if (clayTag) {
          textureValue = "Hard, cracked clay → poor aeration, compact when dry, sticky when wet.";
        } else {
          const textureTag = soil.tags.find(
            (t) =>
              t.toLowerCase().includes("loamy") ||
              t.toLowerCase().includes("sandy") ||
              t.toLowerCase().includes("silt") ||
              t.toLowerCase().includes("rocky")
          );
          if (textureTag) {
            textureValue = `${textureTag.replace("#", "")} – affects water retention and aeration.`;
          } else {
            textureValue = "Not specified – affects water retention and aeration.";
          }
        }
      }
      
      setSoilColor(colorValue);
      setSoilTexture(textureValue);
      const currentSuitabilityValue =
        soil.suitability ||
        (soil.suitabilityScore >= 60 ? "SUITABLE" : "NEEDS_IMPROVEMENT");
      setSuitability(currentSuitabilityValue);
      
      let recommendationsValue = soil.recommendations?.trim() || "";
      if (!recommendationsValue) {
        if (currentSuitabilityValue === "NEEDS_IMPROVEMENT") {
          recommendationsValue =
            "Suggested Improvement Steps:\n1. Rehydrate and loosen the soil through deep watering or controlled irrigation to reduce compaction.\n2. Incorporate organic matter (e.g., compost, decomposed manure, or green waste) to enhance nutrient content and water retention.\n3. Use cover crops or legumes such as cowpea or sunn hemp temporarily—not for harvest, but to fix nitrogen and stabilize the topsoil.\n4. Avoid heavy tillage or machinery, as these may worsen soil compaction in its current state.\n5. After 2-3 months of rehabilitation, retest the soil to determine fertility improvements before planting cash crops.";
        } else {
          recommendationsValue =
            "This soil is suitable for farming. No specific improvements needed at this time.";
        }
      }
      setRecommendations(recommendationsValue);
      setImagePreview(soil.imageUrl || null);
    }
  }, [soil, isEditMode]);

  useEffect(() => {
    if (!isOpen) {
      setShowTagsPanel(false);
      setIsEditMode(false);
    }
  }, [isOpen]);

  if (!isOpen || !soil) return null;

  const currentSuitability = isEditMode
    ? suitability
    : soil.suitability ||
      (soil.suitabilityScore >= 60 ? "SUITABLE" : "NEEDS_IMPROVEMENT");
  const needsImprovement = currentSuitability === "NEEDS_IMPROVEMENT";

  // Edit mode handlers
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAddTag = () => {
    const trimmedTag = tagInput.trim();
    if (trimmedTag) {
      const formattedTag = trimmedTag.startsWith("#")
        ? trimmedTag
        : `#${trimmedTag}`;
      if (
        !tags.some((tag) => tag.toLowerCase() === formattedTag.toLowerCase())
      ) {
        setTags([...tags, formattedTag]);
        setTagInput("");
      }
    }
  };

  const handleToggleTag = (tag: string) => {
    if (tags.includes(tag)) {
      setTags(tags.filter((t) => t !== tag));
    } else {
      setTags([...tags, tag]);
    }
  };

  const handleRemoveTag = (tagToRemove: string) => {
    setTags(tags.filter((tag) => tag !== tagToRemove));
  };

  const handleRemoveImage = () => {
    setImagePreview(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleCancelEdit = () => {
    setIsEditMode(false);
    setShowTagsPanel(false);
  };

  const handleValidateClick = () => {
    if (!uploadedBy.trim()) {
      alert("Please enter who uploaded the soil");
      return;
    }
    setShowValidateConfirm(true);
  };

  const handleConfirmSave = () => {
    if (handleSubmitEdit()) {
      setShowValidateConfirm(false);
      setShowValidationSuccess(true);
    }
  };

  const handleSubmitEdit = (): boolean => {
    if (!uploadedBy.trim()) {
      alert("Please enter who uploaded the soil");
      return false;
    }

    if (onSubmit) {
      onSubmit({
        uploadedBy: uploadedBy.trim(),
        location: location.trim(),
        tags,
        soilColor: soilColor.trim(),
        soilTexture: soilTexture.trim(),
        suitability,
        recommendations: recommendations.trim(),
        imageUrl: imagePreview || undefined,
      });
    }

    setIsEditMode(false);
    return true;
  };

  const handleEditClick = () => {
    setIsEditMode(true);
  };

  // Get soil color description
  const getSoilColorDescription = () => {
    if (soil.soilColor) {
      const parts = soil.soilColor.split(": ");
      if (parts.length > 1) {
        return (
          <>
            <span className="font-bold underline decoration-red-500">
              {parts[0]}:
            </span>{" "}
            {parts.slice(1).join(": ")}
          </>
        );
      }
      return soil.soilColor;
    }
    const lightBrownTag = soil.tags.find((t) =>
      t.toLowerCase().includes("lightbrown")
    );
    if (lightBrownTag) {
      return (
        <>
          <span className="font-bold">
            Soil Color:
          </span>{" "}
          Light brown to pale → indicates low organic matter and limited
          fertility.
        </>
      );
    }
    const colorTag = soil.tags.find(
      (t) =>
        t.toLowerCase().includes("brown") ||
        t.toLowerCase().includes("reddish") ||
        t.toLowerCase().includes("grayish") ||
        t.toLowerCase().includes("black") ||
        t.toLowerCase().includes("darkbrown")
    );
    if (colorTag) {
      return (
        <>
          <span className="font-bold">
            Soil Color:
          </span>{" "}
          {colorTag.replace("#", "")} – indicates organic matter and fertility
          level.
        </>
      );
    }
    return (
      <>
        <span className="font-bold">
          Soil Color:
        </span>{" "}
        Not specified – indicates organic matter and fertility level.
      </>
    );
  };

  // Get soil texture description
  const getSoilTextureDescription = () => {
    if (soil.soilTexture) {
      const parts = soil.soilTexture.split(": ");
      if (parts.length > 1) {
        return (
          <>
            <span className="font-bold">
              {parts[0]}:
            </span>{" "}
            {parts.slice(1).join(": ")}
          </>
        );
      }
      return soil.soilTexture;
    }
    const clayTag = soil.tags.find((t) => t.toLowerCase().includes("clay"));
    if (clayTag) {
      return (
        <>
          <span className="font-bold">
            Soil Texture:
          </span>{" "}
          Hard, cracked clay → poor aeration, compact when dry, sticky when wet.
        </>
      );
    }
    const textureTag = soil.tags.find(
      (t) =>
        t.toLowerCase().includes("loamy") ||
        t.toLowerCase().includes("sandy") ||
        t.toLowerCase().includes("silt") ||
        t.toLowerCase().includes("rocky")
    );
    if (textureTag) {
      return (
        <>
          <span className="font-bold">
            Soil Texture:
          </span>{" "}
          {textureTag.replace("#", "")} – affects water retention and aeration.
        </>
      );
    }
    return (
      <>
        <span className="font-bold">
          Soil Texture:
        </span>{" "}
        Not specified – affects water retention and aeration.
      </>
    );
  };

  return (
    <>
      {/* Overlay */}
      <div
        className="fixed inset-0 bg-black/50 z-[60] flex items-center justify-center p-4 overflow-y-auto"
        onClick={onClose}
      >
        {/* Modal */}
        <div
          className="bg-white rounded-lg shadow-xl w-full max-w-4xl my-8 overflow-hidden flex flex-col max-h-[90vh]"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-gray-200">
            <h2 className="text-2xl font-bold text-gray-900">
              {isEditMode ? "Edit Soil" : "Soil Details"}
            </h2>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 transition-colors"
              aria-label="Close modal"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto p-6">
            <div className="flex gap-10">
              {/* Left Column - Image Display/Upload */}
              <div className="relative w-[266px] h-[253px]">
                {isEditMode ? (
                  <>
                    <div
                      onClick={() => fileInputRef.current?.click()}
                      className="w-full h-full border-2 border-dashed border-gray-300 rounded-lg flex flex-col items-center justify-center cursor-pointer hover:border-[#A0C878] transition-colors bg-gray-50"
                    >
                      {imagePreview ? (
                        <img
                          src={imagePreview}
                          alt="Soil preview"
                          className="w-full h-full object-cover rounded-lg"
                        />
                      ) : (
                        <>
                          <Upload className="w-12 h-12 text-gray-400 mb-2" />
                          <p className="text-gray-600 font-medium">
                            UPLOAD SOIL IMAGE
                          </p>
                        </>
                      )}
                    </div>
                    {imagePreview && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleRemoveImage();
                        }}
                        className="absolute top-2 right-2 bg-red-500 hover:bg-red-600 text-white rounded-full p-1.5 shadow-lg transition-colors z-10"
                        aria-label="Remove image"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    )}
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handleImageUpload}
                      className="hidden"
                    />
                  </>
                ) : (
                  <div className="w-[266px] h-[253px] border-2 border-gray-300 rounded-lg flex flex-col items-center justify-center bg-gray-50 overflow-hidden">
                    {soil.imageUrl ? (
                      <img
                        src={soil.imageUrl}
                        alt={`Soil ${soil.id}`}
                        className="w-full h-full object-cover rounded-lg"
                        onError={(e) => {
                          const target = e.target as HTMLImageElement;
                          target.src =
                            "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='400' height='300' viewBox='0 0 400 300'%3E%3Crect fill='%23e5e7eb' width='400' height='300'/%3E%3Ctext x='50%25' y='50%25' dominant-baseline='central' text-anchor='middle' font-family='Arial' font-size='18' fill='%239ca3af'%3ENo Image Available%3C/text%3E%3C/svg%3E";
                        }}
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-gray-200">
                        <span className="text-gray-400">No Image Available</span>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Right Column - Form Fields */}
              <div className="space-y-4 flex-1">
                {/* Uploaded By */}
                <div>
                  <label className="block text-sm font-bold text-gray-900 uppercase mb-2">
                    Uploaded by
                  </label>
                  {isEditMode ? (
                    <input
                      type="text"
                      value={uploadedBy}
                      onChange={(e) => setUploadedBy(e.target.value)}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#A0C878] focus:border-transparent"
                      placeholder="Enter name"
                    />
                  ) : (
                    <div className="space-y-1">
                      <p className="text-gray-900 text-sm">
                        {soil.uploadedBy || "N/A"}
                      </p>
                    </div>
                  )}
                </div>
                {/* Date Created */}
                <div>
                  <label className="block text-sm font-bold text-gray-900 uppercase mb-2">
                    Date created
                  </label>
                  <div className="space-y-1">
                    <p className="text-gray-600 text-sm">
                      {soil.dateCreated || "N/A"}
                    </p>
                  </div>       
                </div>

                {/* Location */}
                <div>
                  <label className="block text-sm font-bold text-gray-900 uppercase mb-2">
                    Location
                  </label>
                  {isEditMode ? (
                    <input
                      type="text"
                      value={location}
                      onChange={(e) => setLocation(e.target.value)}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#A0C878] focus:border-transparent"
                      placeholder="Enter location"
                    />
                  ) : (
                    <p className="text-gray-900 text-sm">
                      {soil.location || "N/A"}
                    </p>
                  )}
                </div>

                {/* Tags */}
                <div>
                  <label className="block text-sm font-bold text-gray-900 uppercase mb-2">
                    Tags
                  </label>
                  {isEditMode ? (
                    <>
                      <Button
                        type="button"
                        onClick={() => setShowTagsPanel(!showTagsPanel)}
                        className="bg-[#A0C878] hover:bg-[#8FB868] text-white font-semibold px-4 py-2 rounded-lg flex items-center gap-2"
                      >
                        <Tag className="w-4 h-4" />
                        ADD TAGS
                      </Button>

                      {/* Tags Panel */}
                      {showTagsPanel && (
                        <div className="mt-4 p-4 bg-[#A0C878] rounded-lg">
                          {/* Header */}
                          <div className="flex items-center gap-2 mb-4">
                            <Tag className="w-5 h-5 text-white" />
                            <h4 className="font-bold text-white uppercase">
                              ADD TAGS
                            </h4>
                          </div>

                          {/* Selected Tags Display */}
                          <div className="mb-4">
                            <label className="block text-sm font-medium text-white mb-2">
                              Tags:
                            </label>
                            <div className="flex flex-wrap gap-2 mb-2">
                              {tags.length > 0 ? (
                                tags.map((tag, index) => (
                                  <span
                                    key={index}
                                    className="inline-flex items-center gap-1 px-3 py-1 bg-white text-gray-900 text-sm font-medium rounded-full border border-gray-300"
                                  >
                                    {tag}
                                    <button
                                      onClick={() => handleRemoveTag(tag)}
                                      className="text-gray-500 hover:text-gray-700"
                                    >
                                      ×
                                    </button>
                                  </span>
                                ))
                              ) : (
                                <span className="text-white text-sm italic border-b border-white pb-1">
                                  (no tags selected)
                                </span>
                              )}
                            </div>
                            {/* Custom Tag Input */}
                            <div className="flex gap-2 mt-2">
                              <input
                                type="text"
                                value={tagInput}
                                onChange={(e) => setTagInput(e.target.value)}
                                onKeyPress={(e) => {
                                  if (e.key === "Enter") {
                                    e.preventDefault();
                                    handleAddTag();
                                  }
                                }}
                                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-white focus:border-transparent text-sm bg-white"
                                placeholder="Enter custom tag..."
                              />
                              <Button
                                type="button"
                                onClick={handleAddTag}
                                className="bg-white hover:bg-gray-100 text-[#A0C878] font-semibold px-3 py-2 rounded-lg text-sm"
                              >
                                Add
                              </Button>
                            </div>
                          </div>

                          {/* SOIL COLOR TAGS */}
                          <div className="mb-4">
                            <h5 className="font-bold text-white uppercase mb-2">
                              SOIL COLOR TAGS
                            </h5>
                            <div className="flex flex-wrap gap-2">
                              {soilColorTags.map((tag) => {
                                const isSelected = tags.includes(tag);
                                return (
                                  <button
                                    key={tag}
                                    type="button"
                                    onClick={() => handleToggleTag(tag)}
                                    className={`px-3 py-1 rounded-full text-sm font-medium transition-colors ${
                                      isSelected
                                        ? "bg-white text-gray-900"
                                        : "bg-[#8FB868] text-white hover:bg-[#7FA858]"
                                    }`}
                                  >
                                    {tag}
                                  </button>
                                );
                              })}
                            </div>
                          </div>

                          {/* SOIL TEXTURE TAGS */}
                          <div>
                            <h5 className="font-bold text-white uppercase mb-2">
                              SOIL TEXTURE TAGS
                            </h5>
                            <div className="flex flex-wrap gap-2">
                              {soilTextureTags.map((tag) => {
                                const isSelected = tags.includes(tag);
                                return (
                                  <button
                                    key={tag}
                                    type="button"
                                    onClick={() => handleToggleTag(tag)}
                                    className={`px-3 py-1 rounded-full text-sm font-medium transition-colors ${
                                      isSelected
                                        ? "bg-white text-gray-900"
                                        : "bg-[#8FB868] text-white hover:bg-[#7FA858]"
                                    }`}
                                  >
                                    {tag}
                                  </button>
                                );
                              })}
                            </div>
                          </div>
                        </div>
                      )}

                      {/* Display selected tags outside panel */}
                      {!showTagsPanel && tags.length > 0 && (
                        <div className="flex flex-wrap gap-2 mt-2">
                          {tags.map((tag, index) => (
                            <span
                              key={index}
                              className="inline-flex items-center gap-1 px-3 py-1 bg-gray-100 text-gray-700 text-sm font-medium rounded-full border border-gray-300"
                            >
                              {tag}
                              <button
                                onClick={() => handleRemoveTag(tag)}
                                className="text-gray-500 hover:text-gray-700"
                              >
                                ×
                              </button>
                            </span>
                          ))}
                        </div>
                      )}
                    </>
                  ) : (
                    <>
                      {soil.tags.length > 0 ? (
                        <div className="flex flex-wrap gap-2">
                          {soil.tags.map((tag, index) => (
                            <span
                              key={index}
                              className="inline-flex items-center gap-1 px-3 py-1 bg-gray-100 text-gray-700 text-sm font-medium rounded-full border border-gray-300"
                            >
                              {tag}
                            </span>
                          ))}
                        </div>
                      ) : (
                        <p className="text-gray-500 text-sm">No tags</p>
                      )}
                    </>
                  )}
                </div>
              </div>
            </div>

            {/* RESULTS Section */}
            <div className="mt-6">
              <h3 className="text-lg font-bold text-gray-900 uppercase mb-4">
                RESULTS
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Soil Color Card */}
                <div className="bg-white border border-gray-200 rounded-lg p-4 min-h-[100px]">
                  <div className="flex items-center gap-2 mb-2">
                    <Sprout className="w-5 h-5 text-[#A0C878]" />
                    <h4 className="font-bold text-gray-900 uppercase">
                      SOIL COLOR
                    </h4>
                  </div>
                  {isEditMode ? (
                    <textarea
                      value={soilColor}
                      onChange={(e) => setSoilColor(e.target.value)}
                      className="w-full px-3 py-2 border-0 bg-transparent focus:outline-none focus:ring-0 text-sm text-gray-700 placeholder-gray-300 resize-none overflow-hidden"
                      placeholder="Enter soil color..."
                      rows={3}
                    />
                  ) : (
                    <p className="text-sm text-gray-700 break-words">
                      {getSoilColorDescription()}
                    </p>
                  )}
                </div>

                {/* Soil Texture Card */}
                <div className="bg-white border border-gray-200 rounded-lg p-4 min-h-[100px]">
                  <div className="flex items-center gap-2 mb-2">
                    <BrickWall className="w-5 h-5 text-[#A0C878]" />
                    <h4 className="font-bold text-gray-900 uppercase">
                      SOIL TEXTURE
                    </h4>
                  </div>
                  {isEditMode ? (
                    <textarea
                      value={soilTexture}
                      onChange={(e) => setSoilTexture(e.target.value)}
                      className="w-full px-3 py-2 border-0 bg-transparent focus:outline-none focus:ring-0 text-sm text-gray-700 placeholder-gray-300 resize-none overflow-hidden"
                      placeholder="Enter soil texture..."
                      rows={3}
                    />
                  ) : (
                    <p className="text-sm text-gray-700 break-words">
                      {getSoilTextureDescription()}
                    </p>
                  )}
                </div>
              </div>
            </div>

            {/* Suitability Radio Buttons */}
            <div className="mt-6">
              <div className="flex gap-10 items-center">
                <label className="flex items-center gap-3 cursor-pointer flex-1">
                  <input
                    type="radio"
                    name="suitability"
                    value="SUITABLE"
                    checked={currentSuitability === "SUITABLE"}
                    onChange={(e) => {
                      if (isEditMode) {
                        setSuitability(e.target.value as "SUITABLE");
                      }
                    }}
                    disabled={!isEditMode}
                    className="w-5 h-5 text-[#A0C878] border-gray-300 flex-shrink-0"
                  />
                  <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-[#A0C878] text-white flex-1 justify-center">
                    <Check className="w-5 h-5" />
                    <span className="font-semibold whitespace-nowrap">
                      SOIL IS SUITABLE FOR FARMING
                    </span>
                  </div>
                </label>
                <label className="flex items-center gap-3 cursor-pointer flex-1">
                  <input
                    type="radio"
                    name="suitability"
                    value="NEEDS_IMPROVEMENT"
                    checked={currentSuitability === "NEEDS_IMPROVEMENT"}
                    onChange={(e) => {
                      if (isEditMode) {
                        setSuitability(e.target.value as "NEEDS_IMPROVEMENT");
                      }
                    }}
                    disabled={!isEditMode}
                    className="w-5 h-5 text-red-500 border-gray-300 flex-shrink-0"
                  />
                  <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-red-500 text-white flex-1 justify-center">
                    <AlertCircle className="w-5 h-5" />
                    <span className="font-semibold whitespace-nowrap">
                      SOIL NEEDS IMPROVEMENT
                    </span>
                  </div>
                </label>
              </div>

              {/* Warning Message */}
              {needsImprovement && (
                <p className="mt-4 text-red-600 text-sm pl-4">
                  No crop recommendations are given for this soil. Please
                  improve the soil first.
                </p>
              )}
            </div>

            {/* Recommendations & Reasoning */}
            <div className="mt-6 flex-1 flex flex-col">
              <h3 className="text-lg font-bold text-gray-900 uppercase mb-4 flex-shrink-0">
                RECOMMENDATIONS & REASONING
              </h3>
              {isEditMode ? (
                <textarea
                  value={recommendations}
                  onChange={(e) => setRecommendations(e.target.value)}
                  rows={6}
                  className="w-full flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#A0C878] focus:border-transparent resize-none"
                  placeholder="Add recommendations and reasonings..."
                />
              ) : (
                <div className="w-full py-4 text-gray-900">
                  <p className="text-sm whitespace-pre-line">
                    {soil.recommendations ||
                      (needsImprovement
                        ? "Suggested Improvement Steps:\n1. Rehydrate and loosen the soil through deep watering or controlled irrigation to reduce compaction.\n2. Incorporate organic matter (e.g., compost, decomposed manure, or green waste) to enhance nutrient content and water retention.\n3. Use cover crops or legumes such as cowpea or sunn hemp temporarily—not for harvest, but to fix nitrogen and stabilize the topsoil.\n4. Avoid heavy tillage or machinery, as these may worsen soil compaction in its current state.\n5. After 2-3 months of rehabilitation, retest the soil to determine fertility improvements before planting cash crops."
                        : "This soil is suitable for farming. No specific improvements needed at this time.")}
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Footer - Action Buttons */}
          <div className="flex items-center justify-end gap-3 p-6 border-t border-gray-200">
            {isEditMode ? (
              <>
                <Button
                  onClick={handleCancelEdit}
                  className="bg-blue-500 hover:bg-blue-600 text-white font-semibold px-4 py-2 rounded-lg flex items-center gap-2"
                >
                  <RotateCcw className="w-4 h-4" />
                  CLEAR
                </Button>
                {onDelete && (
                  <Button
                    onClick={() => {
                      onDelete(soil.id);
                      onClose();
                    }}
                    className="bg-red-500 hover:bg-red-600 text-white font-semibold px-4 py-2 rounded-lg flex items-center gap-2"
                  >
                    <Trash2 className="w-4 h-4" />
                    DELETE
                  </Button>
                )}
                <Button
                  onClick={handleValidateClick}
                  className="bg-[#A0C878] hover:bg-[#8FB868] text-white font-semibold px-4 py-2 rounded-lg flex items-center gap-2"
                >
                  <Check className="w-4 h-4" />
                  VALIDATE
                </Button>
              </>
            ) : (
              <>
                {onDelete && (
                  <Button
                    onClick={() => {
                      onDelete(soil.id);
                      onClose();
                    }}
                    className="bg-red-500 hover:bg-red-600 text-white font-semibold px-4 py-2 rounded-lg flex items-center gap-2"
                  >
                    <Trash2 className="w-4 h-4" />
                    DELETE
                  </Button>
                )}
                {onEdit && (
                  <Button
                    onClick={handleEditClick}
                    className="bg-yellow-500 hover:bg-yellow-600 text-white font-semibold px-4 py-2 rounded-lg flex items-center gap-2"
                  >
                    <Edit className="w-4 h-4" />
                    EDIT
                  </Button>
                )}
              </>
            )}
          </div>
        </div>
      </div>

      {/* Validation Success Pop-up */}
      {isOpen && showValidationSuccess && (
        <div
          className="fixed inset-0 bg-black/50 z-[80] flex items-center justify-center p-4"
          onClick={() => setShowValidationSuccess(false)}
        >
          <div
            className="bg-white rounded-lg shadow-xl max-w-md w-full p-6"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex flex-col items-center text-center space-y-4">
              <div className="w-16 h-16 rounded-full bg-green-500 flex items-center justify-center">
                <Check className="w-10 h-10 text-white" />
              </div>
              <p className="text-lg font-bold text-gray-900">
                Validation successful
              </p>
              <Button
                onClick={() => setShowValidationSuccess(false)}
                className="bg-[#A0C878] hover:bg-[#8FB868] text-white font-semibold px-6 py-2 rounded-lg"
              >
                Sync and Retrain
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Validate Confirmation Pop-up */}
      {isOpen && showValidateConfirm && (
        <div
          className="fixed inset-0 bg-black/50 z-[70] flex items-center justify-center p-4"
          onClick={() => setShowValidateConfirm(false)}
        >
          <div
            className="bg-white rounded-lg shadow-xl max-w-md w-full p-6"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex flex-col items-center text-center space-y-4">
              <div className="w-16 h-16 rounded-full bg-amber-100 flex items-center justify-center">
                <AlertTriangle className="w-10 h-10 text-amber-600" />
              </div>
              <p className="text-lg font-bold text-gray-900">
                Suitability score will be updated upon validation
              </p>
              <p className="text-sm text-gray-600">
                Do you want to save changes?
              </p>
              <div className="flex gap-3 w-full justify-center pt-2">
                <Button
                  onClick={() => setShowValidateConfirm(false)}
                  className="bg-red-500 hover:bg-red-600 text-white font-semibold px-6 py-2 rounded-lg"
                >
                  CANCEL
                </Button>
                <Button
                  onClick={handleConfirmSave}
                  className="bg-[#A0C878] hover:bg-[#8FB868] text-white font-semibold px-6 py-2 rounded-lg"
                >
                  SAVE
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
