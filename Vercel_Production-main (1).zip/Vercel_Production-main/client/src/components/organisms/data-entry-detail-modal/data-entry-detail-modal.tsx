import { useEffect, useState } from "react";
import {
  ArrowLeft,
  HeartPulse,
  Footprints,
  Lightbulb,
  Sprout,
  X,
} from "lucide-react";
import {
  SOIL_PLACEHOLDER_IMAGE,
  type DataEntry,
} from "@/constants/data-entries";
import { cn } from "@/lib/utils";

interface DataEntryDetailModalProps {
  entry: DataEntry | null;
  isOpen: boolean;
  onClose: () => void;
}

function healthLevelClass(level: string): string {
  const l = level.toLowerCase();
  if (l.includes("poor")) return "text-red-600";
  if (l.includes("fair")) return "text-red-600 text-xl sm:text-2xl";
  if (l.includes("good")) return "text-amber-600";
  if (l.includes("excellent")) return "text-emerald-600";
  return "text-gray-800";
}

export function DataEntryDetailModal({
  entry,
  isOpen,
  onClose,
}: DataEntryDetailModalProps) {
  const [showRecommendations, setShowRecommendations] = useState(false);

  useEffect(() => {
    setShowRecommendations(false);
  }, [entry?.id]);

  if (!isOpen || !entry) return null;

  const { analysis } = entry;
  const heroSrc = entry.imageUrl || SOIL_PLACEHOLDER_IMAGE;

  const recommendedCrops = [
    {
      name: "Corn",
      description: `Thrives in ${analysis.soilTexture.toLowerCase()} soil with moderate health score, staple crop and cash drop.`,
      season: "Dry Season (December - May)",
      tips: "Plant 2-3 seeds per hole, 1 meter apart, apply complete fertilizer at 30 days, harvest at 100-120 days.",
      score: "92%",
    },
    {
      name: "Corn",
      description: `Thrives in ${analysis.soilTexture.toLowerCase()} soil with moderate health score, staple crop and cash drop.`,
      season: "Dry Season (December - May)",
      tips: "Plant 2-3 seeds per hole, 1 meter apart, apply complete fertilizer at 30 days, harvest at 100-120 days.",
      score: "92%",
    },
    {
      name: "Corn",
      description: `Thrives in ${analysis.soilTexture.toLowerCase()} soil with moderate health score, staple crop and cash drop.`,
      season: "Dry Season (December - May)",
      tips: "Plant 2-3 seeds per hole, 1 meter apart, apply complete fertilizer at 30 days, harvest at 100-120 days.",
      score: "92%",
    },
  ];

  // Consolidate recommendations: prefer backend-provided, otherwise use sample crops
  const recItems: any[] = (entry as any).recommendations && (entry as any).recommendations.length
    ? (entry as any).recommendations
    : recommendedCrops;

  return (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6 bg-black/50"
      role="dialog"
      aria-modal="true"
      aria-labelledby="soil-scan-detail-title"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        className={cn(
          "relative w-full font-['Poppins',sans-serif]",
          showRecommendations
            ? "max-w-[620px] max-h-[92vh] overflow-y-auto rounded-[24px] bg-[#585858] p-4"
            : "max-w-[620px] rounded-[24px] bg-[#585858] p-4"
        )}
      >
        {!showRecommendations ? (
          <div className="min-h-[760px] overflow-hidden rounded-[18px] border border-[#d8d8d8] bg-[#efefef] shadow-[0_4px_14px_rgba(0,0,0,0.22)] flex flex-col">
            <button
              type="button"
              onClick={onClose}
              className="absolute top-5 right-5 z-20 flex h-9 w-9 items-center justify-center rounded-full bg-black/35 text-white backdrop-blur-sm transition hover:bg-black/50"
              aria-label="Close"
            >
              <X className="h-5 w-5" strokeWidth={2.5} />
            </button>

            <div className="relative h-[360px] w-full">
              <img
                src={heroSrc}
                alt={`Soil scan ${entry.scanId}`}
                className="absolute inset-0 h-full w-full object-cover"
              />

              <div className="absolute bottom-0 right-0 z-10">
                <button
                  type="button"
                  className="rounded-tl-2xl bg-[#9CCB79] px-6 py-3.5 text-center text-[25px] font-bold leading-none tracking-[0.01em] text-white shadow-md transition hover:bg-[#8fbe6d]"
                  onClick={() => setShowRecommendations(true)}
                >
                  VIEW RECOMMENDATIONS
                </button>
              </div>
            </div>

            <div className="flex-1 px-5 pb-5 pt-3 sm:px-6 sm:pt-4">
              <h2 id="soil-scan-detail-title" className="sr-only">
                Soil scan {entry.scanId}
              </h2>

              <section>
                <div className="flex items-center gap-2">
                  <HeartPulse className="h-4 w-4 text-red-500" strokeWidth={2.2} />
                  <h3 className="text-[24px] font-semibold tracking-[-0.01em] text-[#303030]">
                    Soil Health Assessment
                  </h3>
                </div>
                <div className="mt-3 grid grid-cols-2 gap-3">
                  <div className="rounded-xl bg-[#B1CD93] px-3 py-3 text-center shadow-[0_2px_4px_rgba(0,0,0,0.12)]">
                    <p className="text-[11px] font-medium text-[#40543B]">Health Level</p>
                    <p
                      className={cn(
                        "mt-1 text-[35px] font-bold leading-none",
                        healthLevelClass(analysis.healthLevel)
                      )}
                    >
                      {analysis.healthLevel}
                    </p>
                  </div>
                  <div className="rounded-xl bg-[#B1CD93] px-3 py-3 text-center shadow-[0_2px_4px_rgba(0,0,0,0.12)]">
                    <p className="text-[11px] font-medium text-[#40543B]">Score</p>
                    <p className="mt-1 text-[35px] font-bold leading-none text-[#4D74D4]">
                      {analysis.scoreDisplay}/100
                    </p>
                  </div>
                </div>
              </section>

              <section className="mt-4">
                <div className="flex items-center gap-2">
                  <Footprints className="h-4 w-4 text-[#7B3A83]" strokeWidth={2.2} />
                  <h3 className="text-[24px] font-semibold tracking-[-0.01em] text-[#303030]">Soil Properties</h3>
                </div>
                <hr className="mt-2 border-gray-300" />

                <div className="mt-3 space-y-3">
                  <div>
                    <p className="text-[12px] text-gray-800">Soil Texture</p>
                    <p className="text-[14px] font-bold text-gray-900">{analysis.soilTexture}</p>
                    <p className="text-[11px] text-gray-500">{analysis.textureSuitability}</p>
                  </div>
                  <div>
                    <p className="text-[12px] text-gray-800">Soil Color</p>
                    <p className="text-[14px] font-bold text-gray-900">{analysis.soilColor}</p>
                    <p className="text-[11px] text-gray-500">{analysis.soilColorNote}</p>
                  </div>
                </div>
              </section>
            </div>
          </div>
        ) : null}

        {showRecommendations ? (
          <div className="overflow-hidden rounded-[18px] border border-[#d8d8d8] bg-white shadow-[0_4px_14px_rgba(0,0,0,0.22)]">
            <button
              type="button"
              onClick={onClose}
              className="absolute top-7 right-7 z-20 flex h-8 w-8 items-center justify-center rounded-full bg-black/35 text-white backdrop-blur-sm transition hover:bg-black/50"
              aria-label="Close"
            >
              <X className="h-5 w-5" strokeWidth={2.5} />
            </button>

            <div className="rounded-t-[18px] bg-[#F4F7EF] px-4 py-3">
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-[#E5F0D7] text-[#7DB062]">
                    <Sprout className="h-4 w-4" />
                  </div>
                  <p className="text-[23px] font-semibold text-gray-900 leading-none">
                    Recommended Crops
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setShowRecommendations(false)}
                  className="inline-flex items-center gap-1 rounded-full border border-gray-200 bg-white px-2 py-1 text-[10px] font-semibold text-gray-700 transition hover:bg-gray-50"
                >
                  <ArrowLeft className="h-3.5 w-3.5" />
                  Back
                </button>
              </div>
              <div className="mt-3 h-px bg-[#d3dec5]" />
            </div>

            <div className="px-4 pb-5 pt-3">
              <h2 id="soil-scan-detail-title" className="sr-only">
                Soil scan {entry.scanId}
              </h2>

              <div className="space-y-3">
                {recItems.map((rec: any, idx: number) => {
                  const isString = typeof rec === 'string';
                  const name = !isString && rec.name ? rec.name : `Recommendation ${idx + 1}`;
                  const description = isString ? rec : rec.description || rec.text || JSON.stringify(rec);
                  const score = !isString && rec.score ? rec.score : null;

                  return (
                    <div
                      key={`rec-${idx}`}
                      className="relative overflow-hidden rounded-[10px] border border-[#d5d5d5] bg-[#ECF4E1] p-2.5 shadow-[0_2px_5px_rgba(0,0,0,0.16)]"
                    >
                      <div className="relative">
                        <div className="flex items-start justify-between gap-2">
                          <div className="space-y-0.5 pr-2">
                            <p className="text-[14px] font-bold text-gray-900 leading-none">{name}</p>
                            <p className="text-[12px] leading-[1.2] text-gray-700">{description}</p>
                          </div>
                          {score ? (
                            <div className="rounded-full bg-[#8DBD6F] px-3 py-1 text-[31px] font-bold text-white leading-none">{score}</div>
                          ) : null}
                        </div>
                        {(!isString && (rec.season || rec.tips)) ? (
                          <div className="mt-2 overflow-hidden rounded-[6px] border border-[#cad8b6] bg-[#DDECC8] shadow-sm">
                            <div className="flex flex-col sm:flex-row">
                              <div className="relative flex-1 border-b border-[#cad8b6] bg-[#CFE1B4] p-2.5 text-sm sm:border-b-0 sm:border-r">
                                <p className="text-[13px] font-bold text-[#202020] leading-none">Season</p>
                                <p className="mt-1 text-[14px] font-semibold text-gray-900 leading-tight">{rec.season}</p>
                              </div>
                              <div className="relative flex-1 bg-[#EBCF5B] p-2.5 text-sm">
                                <p className="text-[13px] font-bold text-[#202020] leading-none">Growing Tips</p>
                                <p className="mt-1 text-[11px] leading-[1.25] text-[#2f2f2f]">{rec.tips}</p>
                              </div>
                            </div>
                          </div>
                        ) : null}
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="mt-4 flex items-center gap-2 text-[22px] font-semibold text-gray-900">
                <div className="flex h-7 w-7 items-center justify-center rounded-xl bg-[#F4E17A] text-[#E0A90A]">
                  <Lightbulb className="h-4 w-4" />
                </div>
                Improvement Plan
              </div>
              <div className="mt-2 h-px w-full bg-[#d3dec5]" />
              <div className="mt-3 rounded-[12px] border border-[#d7d7d7] bg-white p-3 shadow-sm">
                <div className="grid gap-3 sm:grid-cols-2">
                  <div className="rounded-[10px] border border-[#dcae30] bg-[#E7DD80] p-3 text-center">
                    <p className="text-[11px] font-semibold text-[#B77A00]">
                      Health Level
                    </p>
                    <p className="mt-1 text-[42px] font-black text-gray-900 leading-none">
                      {analysis.healthLevel}
                    </p>
                  </div>
                  <div className="rounded-[10px] border border-[#dcae30] bg-[#E7DD80] p-3">
                    <p className="text-[11px] font-semibold text-[#B77A00]">
                      Timeline
                    </p>
                    <p className="mt-1 text-[14px] font-bold text-gray-900 leading-tight">
                      2-4 months for good improvement
                    </p>
                  </div>
                </div>

                <div className="mt-3 rounded-md bg-[#A4C682] px-3 py-2 text-[14px] text-[#4d5e43]">
                  Soil health at {analysis.scoreDisplay}%. Active improvement
                  needed.
                </div>

                <div className="mt-3">
                  <p className="text-[13px] font-semibold text-gray-900">
                    Recommended Actions
                  </p>
                  <ul className="mt-2 space-y-2 text-[13px] leading-[1.35] text-gray-700">
                    <li className="flex gap-2">
                      <span className="mt-0.5 flex h-5 w-5 items-center justify-center rounded-full bg-[#9DBF79] text-[11px] font-bold text-white">
                        1
                      </span>
                      <span>
                        Apply 2–3 tons of composted chicken manure per hectare
                        during dry season to increase organic matter and improve
                        soil structure.
                      </span>
                    </li>
                    <li className="flex gap-2">
                      <span className="mt-0.5 flex h-5 w-5 items-center justify-center rounded-full bg-[#9DBF79] text-[11px] font-bold text-white">
                        2
                      </span>
                      <span>
                        Mix in 1–2 kilos of crushed ipil-ipil leaves (Leucaena
                        leucocephala) per square meter to add nutrients and help
                        stabilize the soil composition.
                      </span>
                    </li>
                  </ul>
                </div>

                <div className="mt-3 overflow-hidden rounded-[8px] bg-[#E7DA56]">
                  <div className="flex">
                    <div className="w-2 bg-[#D59B1D]" />
                    <div className="flex-1 p-3">
                      <p className="text-[13px] font-semibold text-[#B77A00]">
                        ★ Priority Actions:
                      </p>
                      <div className="mt-2 space-y-1 text-[12px] text-[#5b4b14]">
                        <p>✓ Incorporate organic amendments</p>
                        <p>✓ Practice Crop rotation</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ) : null}
      </div>
    </div>
  );
}
