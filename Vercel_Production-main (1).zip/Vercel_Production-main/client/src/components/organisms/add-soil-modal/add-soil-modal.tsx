import { useState, useRef, useEffect } from "react";
import {
  X,
  Upload,
  Tag,
  Sprout,
  BrickWall,
  Check,
  AlertCircle,
  RotateCcw,
} from "lucide-react";
import { Button } from "@/components/atoms/button/button";
import { useAuth } from "@/hooks/use-auth";

interface AddSoilModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: {
    uploadedBy: string;
    location: string;
    tags: string[];
    soilColor: string;
    soilTexture: string;
    suitability: "SUITABLE" | "NEEDS_IMPROVEMENT";
    recommendations: string;
    imageUrl?: string;
  }) => void;
}

export function AddSoilModal({
  isOpen,
  onClose,
  onSubmit,
}: AddSoilModalProps) {
  const { user } = useAuth();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [location, setLocation] = useState("");
  const [tags, setTags] = useState<string[]>([]);
  const [tagInput, setTagInput] = useState("");
  const [showTagsPanel, setShowTagsPanel] = useState(false);
  const [soilColor, setSoilColor] = useState("");

  // Predefined tags
  const soilColorTags = [
    "#DarkBrown",
    "#LightBrown",
    "#Reddish",
    "#Grayish",
    "#Black",
  ];
  const soilTextureTags = ["#Loamy", "#Clay", "#Sandy", "#Silt", "#Rocky"];
  const [soilTexture, setSoilTexture] = useState("");
  const [suitability, setSuitability] = useState<
    "SUITABLE" | "NEEDS_IMPROVEMENT"
  >("SUITABLE");
  const [recommendations, setRecommendations] = useState("");

  useEffect(() => {
    if (!isOpen) {
      setShowTagsPanel(false);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAddTag = () => {
    const trimmedTag = tagInput.trim();
    if (trimmedTag) {
      // Ensure tag starts with # if not already present
      const formattedTag = trimmedTag.startsWith("#")
        ? trimmedTag
        : `#${trimmedTag}`;
      // Check if tag already exists (case-insensitive)
      if (
        !tags.some((tag) => tag.toLowerCase() === formattedTag.toLowerCase())
      ) {
        setTags([...tags, formattedTag]);
        setTagInput("");
      }
    }
  };

  const handleToggleTag = (tag: string) => {
    if (tags.includes(tag)) {
      setTags(tags.filter((t) => t !== tag));
    } else {
      setTags([...tags, tag]);
    }
  };

  const handleRemoveTag = (tagToRemove: string) => {
    setTags(tags.filter((tag) => tag !== tagToRemove));
  };

  const handleRemoveImage = () => {
    setImagePreview(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleClear = () => {
    setImagePreview(null);
    setLocation("");
    setTags([]);
    setTagInput("");
    setShowTagsPanel(false);
    setSoilColor("");
    setSoilTexture("");
    setSuitability("SUITABLE");
    setRecommendations("");
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleSubmit = () => {
    onSubmit({
      uploadedBy: user?.username || "",
      location: location.trim(),
      tags,
      soilColor: soilColor.trim(),
      soilTexture: soilTexture.trim(),
      suitability,
      recommendations: recommendations.trim(),
      imageUrl: imagePreview || undefined,
    });

    handleClear();
    onClose();
  };

  return (
    <>
      {/* Overlay */}
      <div
        className="fixed inset-0 bg-black/50 z-[60] flex items-center justify-center p-4 overflow-y-auto"
        onClick={onClose}
      >
        {/* Modal */}
        <div
          className="bg-white rounded-lg shadow-xl w-full max-w-4xl my-8 overflow-hidden flex flex-col max-h-[90vh]"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-gray-200">
            <h2 className="text-2xl font-bold text-gray-900">Add New Soil</h2>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 transition-colors"
              aria-label="Close modal"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto p-6 flex flex-col">
            <div className="flex gap-10 ">
              {/* Left Column - Image Upload */}

              <div className="relative w-[266px] h-[253px]">
                <div
                  onClick={() => fileInputRef.current?.click()}
                  className="w-full h-full border-2 border-dashed border-gray-300 rounded-lg flex flex-col items-center justify-center cursor-pointer hover:border-[#A0C878] transition-colors bg-gray-50"
                >
                  {imagePreview ? (
                    <img
                      src={imagePreview}
                      alt="Soil preview"
                      className="w-full h-full object-cover rounded-lg"
                    />
                  ) : (
                    <>
                      <Upload className="w-12 h-12 text-gray-400 mb-2" />
                      <p className="text-gray-600 font-medium">
                        UPLOAD SOIL IMAGE
                      </p>
                    </>
                  )}
                </div>
                {imagePreview && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleRemoveImage();
                    }}
                    className="absolute top-2 right-2 bg-red-500 hover:bg-red-600 text-white rounded-full p-1.5 shadow-lg transition-colors z-10"
                    aria-label="Remove image"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleImageUpload}
                className="hidden"
              />

              {/* Right Column - Form Fields */}
              <div className="space-y-4 flex-1">

                {/* Location */}
                <div>
                  <label className="block text-sm font-bold text-gray-900 uppercase mb-2">
                    Location
                  </label>
                  <input
                    type="text"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#A0C878] focus:border-transparent"
                    placeholder="Enter location"
                  />
                </div>

                {/* Tags */}
                <div>
                  <label className="block text-sm font-bold text-gray-900 uppercase mb-2">
                    Tags
                  </label>
                  <Button
                    type="button"
                    onClick={() => setShowTagsPanel(!showTagsPanel)}
                    className="bg-[#A0C878] hover:bg-[#8FB868] text-white font-semibold px-4 py-2 rounded-lg flex items-center gap-2"
                  >
                    <Tag className="w-4 h-4" />
                    ADD TAGS
                  </Button>

                  {/* Tags Panel */}
                  {showTagsPanel && (
                    <div className="mt-4 p-4 bg-[#A0C878] rounded-lg">
                      {/* Header */}
                      <div className="flex items-center gap-2 mb-4">
                        <Tag className="w-5 h-5 text-white" />
                        <h4 className="font-bold text-white uppercase">
                          ADD TAGS
                        </h4>
                      </div>

                      {/* Selected Tags Display */}
                      <div className="mb-4">
                        <label className="block text-sm font-medium text-white mb-2">
                          Tags:
                        </label>
                        <div className="flex flex-wrap gap-2 mb-2">
                          {tags.length > 0 ? (
                            tags.map((tag, index) => (
                              <span
                                key={index}
                                className="inline-flex items-center gap-1 px-3 py-1 bg-white text-gray-900 text-sm font-medium rounded-full border border-gray-300"
                              >
                                {tag}
                                <button
                                  onClick={() => handleRemoveTag(tag)}
                                  className="text-gray-500 hover:text-gray-700"
                                >
                                  ×
                                </button>
                              </span>
                            ))
                          ) : (
                            <span className="text-white text-sm italic border-b border-white pb-1">
                              (no tags selected)
                            </span>
                          )}
                        </div>
                        {/* Custom Tag Input */}
                        <div className="flex gap-2 mt-2">
                          <input
                            type="text"
                            value={tagInput}
                            onChange={(e) => setTagInput(e.target.value)}
                            onKeyPress={(e) => {
                              if (e.key === "Enter") {
                                e.preventDefault();
                                handleAddTag();
                              }
                            }}
                            className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-white focus:border-transparent text-sm bg-white"
                            placeholder="Enter custom tag..."
                          />
                          <Button
                            type="button"
                            onClick={handleAddTag}
                            className="bg-white hover:bg-gray-100 text-[#A0C878] font-semibold px-3 py-2 rounded-lg text-sm"
                          >
                            Add
                          </Button>
                        </div>
                      </div>

                      {/* SOIL COLOR TAGS */}
                      <div className="mb-4">
                        <h5 className="font-bold text-white uppercase mb-2">
                          SOIL COLOR TAGS
                        </h5>
                        <div className="flex flex-wrap gap-2">
                          {soilColorTags.map((tag) => {
                            const isSelected = tags.includes(tag);
                            return (
                              <button
                                key={tag}
                                type="button"
                                onClick={() => handleToggleTag(tag)}
                                className={`px-3 py-1 rounded-full text-sm font-medium transition-colors ${
                                  isSelected
                                    ? "bg-white text-gray-900"
                                    : "bg-[#8FB868] text-white hover:bg-[#7FA858]"
                                }`}
                              >
                                {tag}
                              </button>
                            );
                          })}
                        </div>
                      </div>

                      {/* SOIL TEXTURE TAGS */}
                      <div>
                        <h5 className="font-bold text-white uppercase mb-2">
                          SOIL TEXTURE TAGS
                        </h5>
                        <div className="flex flex-wrap gap-2">
                          {soilTextureTags.map((tag) => {
                            const isSelected = tags.includes(tag);
                            return (
                              <button
                                key={tag}
                                type="button"
                                onClick={() => handleToggleTag(tag)}
                                className={`px-3 py-1 rounded-full text-sm font-medium transition-colors ${
                                  isSelected
                                    ? "bg-white text-gray-900"
                                    : "bg-[#8FB868] text-white hover:bg-[#7FA858]"
                                }`}
                              >
                                {tag}
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Display selected tags outside panel */}
                  {!showTagsPanel && tags.length > 0 && (
                    <div className="flex flex-wrap gap-2 mt-2">
                      {tags.map((tag, index) => (
                        <span
                          key={index}
                          className="inline-flex items-center gap-1 px-3 py-1 bg-gray-100 text-gray-700 text-sm font-medium rounded-full border border-gray-300"
                        >
                          {tag}
                          <button
                            onClick={() => handleRemoveTag(tag)}
                            className="text-gray-500 hover:text-gray-700"
                          >
                            ×
                          </button>
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* RESULTS Section */}
            <div className="mt-6">
              <h3 className="text-lg font-bold text-gray-900 uppercase mb-4">
                RESULTS
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Soil Color Card */}
                <div className="bg-white border border-gray-200 rounded-lg p-4 min-h-[100px]">
                  <div className="flex items-center gap-2 mb-2">
                    <Sprout className="w-5 h-5 text-[#A0C878]" />
                    <h4 className="font-bold text-gray-900 uppercase">
                      SOIL COLOR
                    </h4>
                  </div>
                  <textarea
                    value={soilColor}
                    onChange={(e) => setSoilColor(e.target.value)}
                    className="w-full px-3 py-2 border-0 bg-transparent focus:outline-none focus:ring-0 text-sm text-gray-700 placeholder-gray-300 resize-none overflow-hidden"
                    placeholder="Enter soil color..."
                    rows={3}
                  />
                </div>

                {/* Soil Texture Card */}
                <div className="bg-white border border-gray-200 rounded-lg p-4 min-h-[100px]">
                  <div className="flex items-center gap-2 mb-2">
                    <BrickWall className="w-5 h-5 text-[#A0C878]" />
                    <h4 className="font-bold text-gray-900 uppercase">
                      SOIL TEXTURE
                    </h4>
                  </div>
                  <textarea
                    value={soilTexture}
                    onChange={(e) => setSoilTexture(e.target.value)}
                    className="w-full px-3 py-2 border-0 bg-transparent focus:outline-none focus:ring-0 text-sm text-gray-700 placeholder-gray-300 resize-none overflow-hidden"
                    placeholder="Enter soil texture..."
                    rows={3}
                  />
                </div>
              </div>
            </div>

            {/* Suitability Radio Buttons */}
            <div className="mt-6">
              <div className="flex gap-10 items-center">
                <label className="flex items-center gap-3 cursor-pointer flex-1">
                  <input
                    type="radio"
                    name="suitability"
                    value="SUITABLE"
                    checked={suitability === "SUITABLE"}
                    onChange={(e) =>
                      setSuitability(e.target.value as "SUITABLE")
                    }
                    className="w-5 h-5 text-[#A0C878] border-gray-300 focus:ring-[#A0C878] flex-shrink-0"
                  />
                  <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-[#A0C878] text-white flex-1 justify-center">
                    <Check className="w-5 h-5" />
                    <span className="font-semibold whitespace-nowrap">
                      SOIL IS SUITABLE FOR FARMING
                    </span>
                  </div>
                </label>
                <label className="flex items-center gap-3 cursor-pointer flex-1">
                  <input
                    type="radio"
                    name="suitability"
                    value="NEEDS_IMPROVEMENT"
                    checked={suitability === "NEEDS_IMPROVEMENT"}
                    onChange={(e) =>
                      setSuitability(e.target.value as "NEEDS_IMPROVEMENT")
                    }
                    className="w-5 h-5 text-red-500 border-gray-300 focus:ring-red-500 flex-shrink-0"
                  />
                  <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-red-500 text-white flex-1 justify-center">
                    <AlertCircle className="w-5 h-5" />
                    <span className="font-semibold whitespace-nowrap">
                      SOIL NEEDS IMPROVEMENT
                    </span>
                  </div>
                </label>
              </div>
            </div>

            {/* Recommendations & Reasoning */}
            <div className="mt-6 flex-1 flex flex-col">
              <h3 className="text-lg font-bold text-gray-900 uppercase mb-4 flex-shrink-0">
                RECOMMENDATIONS & REASONING
              </h3>
              <textarea
                value={recommendations}
                onChange={(e) => setRecommendations(e.target.value)}
                rows={6}
                className="w-full flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#A0C878] focus:border-transparent resize-none"
                placeholder="Add recommendations and reasonings..."
              />
            </div>
          </div>

          {/* Footer - Action Buttons */}
          <div className="flex items-center justify-end gap-3 p-6 border-t border-gray-200">
            <Button
              onClick={handleClear}
              className="bg-blue-500 hover:bg-blue-600 text-white font-semibold px-4 py-2 rounded-lg flex items-center gap-2"
            >
              <RotateCcw className="w-4 h-4" />
              CLEAR
            </Button>
            <Button
              onClick={handleSubmit}
              className="bg-[#A0C878] hover:bg-[#8FB868] text-white font-semibold px-4 py-2 rounded-lg flex items-center gap-2"
            >
              <Check className="w-4 h-4" />
              VALIDATE
            </Button>
          </div>
        </div>
      </div>
    </>
  );
}
