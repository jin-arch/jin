import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { User, Lock, Eye, EyeOff } from "lucide-react";
import { Button } from "@/components/atoms/button/button";
import { Input } from "@/components/atoms/input/input";
import { FormField } from "@/components/molecules/form-field/form-field";
import { loginSchema, type LoginFormData } from "@/validations/login";
import { useLogin } from "@/hooks/use-login";

export function LoginForm() {
  const [showPassword, setShowPassword] = useState(false);
  const loginMutation = useLogin();
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
    },
  });

  const onSubmit = (data: LoginFormData) => {
    loginMutation.mutate({
      username: data.username,
      password: data.password,
    });
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-[#A0C878] mb-6 uppercase tracking-tight text-center">
          WELCOME TO ADMIN PAGE
        </h1>
      </div>

      {loginMutation.isError && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">
          {loginMutation.error?.message || "Login failed. Please try again."}
        </div>
      )}

      <FormField label="" error={errors.username?.message}>
        <div className="relative">
          <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5 pointer-events-none" />
          <Input
            type="text"
            placeholder="Username"
            className="pl-10 rounded-lg border-gray-300"
            disabled={loginMutation.isPending}
            {...register("username")}
          />
        </div>
      </FormField>

      <FormField label="" error={errors.password?.message}>
        <div className="relative">
          <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5 pointer-events-none" />
          <Input
            type={showPassword ? "text" : "password"}
            placeholder="Password"
            className="pl-10 pr-10 rounded-lg border-gray-300"
            disabled={loginMutation.isPending}
            {...register("password")}
          />
          <button
            type="button"
            onClick={() => setShowPassword(!showPassword)}
            className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600 focus:outline-none"
            aria-label={showPassword ? "Hide password" : "Show password"}
            disabled={loginMutation.isPending}
          >
            {showPassword ? (
              <EyeOff className="w-5 h-5" />
            ) : (
              <Eye className="w-5 h-5" />
            )}
          </button>
        </div>
      </FormField>

      <Button
        type="submit"
        disabled={loginMutation.isPending}
        className="w-full bg-[#A0C878] hover:bg-[#8FB868] text-white font-bold py-3 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
      >
        {loginMutation.isPending ? "SIGNING IN..." : "SIGN IN"}
      </Button>
    </form>
  );
}
