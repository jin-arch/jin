import { Check, Eye, Trash2 } from "lucide-react";
import type { Soil } from "@/constants/soils";

interface SoilCardProps {
  soil: Soil;
  onView: (soil: Soil) => void;
  onDelete: (soilId: string) => void;
}

export function SoilCard({ soil, onView, onDelete }: SoilCardProps) {
  const handleDelete = () => {
    if (window.confirm(`Are you sure you want to delete soil ${soil.id}?`)) {
      onDelete(soil.id);
    }
  };

  return (
    <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-4 hover:shadow-md transition-shadow">
      <div className="flex gap-4">
        {/* Thumbnail Image */}
        <div className="flex-shrink-0">
          {soil.imageUrl ? (
            <img
              src={soil.imageUrl}
              alt={`Soil ${soil.id}`}
              className="w-24 h-24 rounded-lg object-cover border border-gray-200"
              onError={(e) => {
                // Fallback to placeholder if image fails to load
                const target = e.target as HTMLImageElement;
                target.src =
                  "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='96' height='96' viewBox='0 0 96 96'%3E%3Crect fill='%23e5e7eb' width='96' height='96'/%3E%3Ctext x='50%25' y='50%25' dominant-baseline='central' text-anchor='middle' font-family='Arial' font-size='12' fill='%239ca3af'%3ENo Image%3C/text%3E%3C/svg%3E";
              }}
            />
          ) : (
            <div className="w-24 h-24 rounded-lg bg-gray-200 border border-gray-300 flex items-center justify-center">
              <span className="text-xs text-gray-400 text-center px-2">
                No Image
              </span>
            </div>
          )}
        </div>

        {/* Content */}
        <div className="flex-1 min-w-0">
          <h3 className="text-lg font-bold text-gray-900 mb-2">{soil.id}</h3>
          <div className="space-y-1 text-sm text-gray-600 mb-3">
            <p>
              <span className="font-medium">Uploaded by:</span>{" "}
              {soil.uploadedBy}
            </p>
            <p>
              <span className="font-medium">Date created:</span>{" "}
              {soil.dateCreated}
            </p>
            <p>
              <span className="font-medium">Suitability Score:</span>{" "}
              <span className="font-semibold text-gray-900">
                {soil.suitabilityScore}%
              </span>
            </p>
          </div>

          {/* Tags */}
          <div className="flex flex-wrap gap-2 mb-3">
            <span className="text-sm font-medium text-gray-700">Tags:</span>
            {soil.tags.map((tag, index) => (
              <span
                key={index}
                className="px-2 py-1 bg-gray-100 text-gray-700 text-xs font-medium rounded-full border border-gray-300"
              >
                {tag}
              </span>
            ))}
          </div>
        </div>

        {/* Right Side Actions */}
        <div className="flex-shrink-0 flex flex-col items-end gap-2">
          {/* Status Badge */}
          <div className="flex flex-col items-end">
            {soil.status === "VALIDATED" && (
              <>
                <div className="flex items-center gap-1 px-3 py-1 bg-green-500 text-white text-xs font-semibold rounded-full">
                  <Check className="w-3 h-3" />
                  {soil.status}
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  {soil.verificationMethod}
                </p>
              </>
            )}
            {soil.status === "PENDING" && (
              <>
                <div className="px-3 py-1 bg-yellow-500 text-white text-xs font-semibold rounded-full">
                  {soil.status}
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  {soil.verificationMethod}
                </p>
              </>
            )}
            {soil.status === "REJECTED" && (
              <div className="px-3 py-1 bg-red-500 text-white text-xs font-semibold rounded-full">
                {soil.status}
              </div>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex gap-2 mt-auto">
            <button
              onClick={() => onView(soil)}
              className="w-8 h-8 rounded-full bg-green-500 hover:bg-green-600 text-white flex items-center justify-center transition-colors"
              title="View details"
            >
              <Eye className="w-4 h-4" />
            </button>
            <button
              onClick={handleDelete}
              className="w-8 h-8 rounded-full bg-red-500 hover:bg-red-600 text-white flex items-center justify-center transition-colors"
              title="Delete"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
