import { X } from "lucide-react";
import type { Feedback } from "@/constants/feedbacks";
import { useUsers } from "@/hooks/use-users";

interface FeedbackDetailModalProps {
  isOpen: boolean;
  feedback: Feedback | null;
  onClose: () => void;
}

export function FeedbackDetailModal({
  isOpen,
  feedback,
  onClose,
}: FeedbackDetailModalProps) {
  if (!isOpen || !feedback) return null;

  const { data: users } = useUsers();

  const getDisplayName = (fb: Feedback) => {
    if (fb.userName) return fb.userName;
    if (fb.userId && users) {
      const u = users.find((x) => x.id === fb.userId || (x.id && x.id === String(fb.userId)));
      if (u) return u.name;
    }
    return fb.userId || 'Anonymous';
  };

  const getDisplayEmail = (fb: Feedback) => {
    // Prefer resolved user email when users list is available
    if (fb.userId && users) {
      const u = users.find((x) => x.id === fb.userId || (x.id && x.id === String(fb.userId)));
      if (u && (u as any).email) return (u as any).email;
    }
    // Fallback to metadata.email when metadata is an object
    if (fb.metadata && typeof fb.metadata === 'object' && 'email' in fb.metadata) {
      return (fb.metadata as any).email;
    }
    return undefined;
  };

  return (
    <>
      {/* Overlay */}
      <div
        className="fixed inset-0 bg-slate-950/30 backdrop-blur-sm z-[60] flex items-center justify-center p-4"
        onClick={onClose}
      >
        {/* Modal */}
        <div
          className="font-['Poppins',sans-serif] relative w-full max-w-2xl max-h-[90vh] overflow-hidden rounded-[24px] border border-slate-200/80 bg-white shadow-[0_24px_72px_rgba(15,23,42,0.16)]"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="flex items-start justify-between gap-4 border-b border-slate-200/80 bg-slate-50 px-6 py-6">
            <div>
              <p className="text-xs uppercase tracking-[0.24em] text-emerald-700">
                Feedback details
              </p>
              <h2 className="mt-3 text-2xl font-semibold text-slate-950">Feedback</h2>
              <p className="mt-2 text-sm text-slate-500">{feedback.timestamp}</p>
            </div>
            <button
              onClick={onClose}
              className="inline-flex h-11 w-11 items-center justify-center rounded-xl border border-slate-200 bg-white text-slate-600 shadow-sm transition hover:bg-slate-100 hover:text-slate-900"
              aria-label="Close modal"
            >
                <X className="w-5 h-5" />
            </button>
          </div>

          {/* Content */}
                  <div className="flex-1 overflow-y-auto p-6 space-y-6">
                    {/* Name & Email cards */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="rounded-xl border border-slate-200/80 bg-white p-4">
                        <p className="text-xs uppercase tracking-[0.18em] text-slate-500">Name</p>
                        <p className="mt-2 text-base font-semibold text-slate-900">{getDisplayName(feedback)}</p>
                      </div>
                      <div className="rounded-xl border border-slate-200/80 bg-white p-4">
                        <p className="text-xs uppercase tracking-[0.18em] text-slate-500">Email</p>
                        <p className="mt-2 text-base text-slate-700">{getDisplayEmail(feedback) ?? 'Not provided'}</p>
                      </div>
                    </div>
                    <div className="rounded-[20px] border border-slate-200/80 bg-slate-50 p-5 shadow-sm">
                      <p className="text-xs uppercase tracking-[0.24em] text-slate-500">Subject</p>
                      <p className="mt-3 text-lg font-semibold text-slate-950">
                        {feedback.title || feedback.subject || 'No subject'}
                      </p>
                      <p className="mt-2 text-sm text-slate-500">
                        {feedback.created_at || feedback.timestamp || ''}
                      </p>
                    </div>

                    {typeof feedback.rating === 'number' && (
                      <div className="rounded-[20px] border border-slate-200/80 bg-slate-50 p-5 shadow-sm">
                        <p className="text-xs uppercase tracking-[0.24em] text-slate-500">Rating</p>
                        <div className="mt-3 flex items-center gap-2">
                          {Array.from({ length: 5 }).map((_, i) => (
                            <svg
                              key={i}
                              width="20"
                              height="20"
                              viewBox="0 0 24 24"
                              fill={i < (feedback.rating || 0) ? '#16a34a' : 'none'}
                              stroke="#16a34a"
                              strokeWidth="1.2"
                              className="inline-block"
                            >
                              <path d="M12 .587l3.668 7.431L23.5 9.75l-5.666 5.523L19.335 24 12 19.897 4.665 24l1.5-8.727L.5 9.75l7.832-1.732z" />
                            </svg>
                          ))}
                          <span className="text-sm text-slate-600">{feedback.rating}/5</span>
                        </div>
                      </div>
                    )}

                    <div className="rounded-[20px] border border-slate-200/80 bg-slate-50 p-5 shadow-sm">
                      <div className="flex items-center justify-between">
                        <p className="text-xs uppercase tracking-[0.24em] text-slate-500">Message</p>
                      </div>
                      <p className="mt-3 whitespace-pre-line text-sm leading-7 text-slate-700">
                        {feedback.message || ''}
                      </p>
                    </div>
                  </div>

          <div className="border-t border-slate-200/80 bg-slate-50 px-6 py-4">
            <button
              onClick={onClose}
              className="inline-flex w-full items-center justify-center rounded-2xl bg-slate-900 px-4 py-3 text-sm font-semibold text-white transition hover:bg-slate-800"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </>
  );
}
