import { PieChart, Pie, Cell, ResponsiveContainer } from "recharts";
import type { PieLabelRenderProps } from "recharts";

interface DatasetChartProps {
  crop?: {
    entries: number;
    percentage: number;
  } | null;
  soil?: {
    entries: number;
    percentage: number;
  } | null;
  loading?: boolean;
}

const COLORS = {
  soil: "#B4D78E", // Light green for Soil
  notSoil: "#52795B", // Dark green for Not Soil
};

export function DatasetChart({ crop, soil, loading = false }: DatasetChartProps) {
  const hasData = !!crop && !!soil && !loading;
  const data = hasData
    ? [
        { name: "Not Soil", value: crop!.entries, percentage: crop!.percentage, color: COLORS.notSoil },
        { name: "Soil", value: soil!.entries, percentage: soil!.percentage, color: COLORS.soil },
      ]
    : [];

  // Custom label to show just percentage outside the donut
  const renderLabel = (props: PieLabelRenderProps) => {
    const { cx, cy, midAngle, outerRadius, name } = props;
    if (!cx || !cy) return null;

    const entry = data.find((d) => d.name === name);
    if (!entry) return null;

    // Radius outside the donut
    const radius = Number(outerRadius) + 20; 
    const radian = (midAngle! - 90) * (Math.PI / 180);
    const x = Number(cx) + radius * Math.cos(radian);
    const y = Number(cy) + radius * Math.sin(radian);
    
    // Choose the color of the text to match the slice
    const fill = entry.color;

    return (
      <text
        x={x}
        y={y}
        textAnchor={x > Number(cx) ? 'start' : 'end'}
        dominantBaseline="central"
        fill={fill}
        fontSize="16"
        fontWeight="500"
      >
        {entry.percentage}%
      </text>
    );
  };

  // Custom legend at bottom right
  const renderCustomLegend = () => (
    <div className="flex flex-col gap-2 absolute bottom-6 right-6">
      <div className="flex items-center gap-2">
        <div className="w-3 h-3 rounded-full" style={{ backgroundColor: COLORS.soil }} />
        <p className="text-sm font-medium text-gray-700">Soil ({soil?.entries ?? '—'})</p>
      </div>
      <div className="flex items-center gap-2">
        <div className="w-3 h-3 rounded-full" style={{ backgroundColor: COLORS.notSoil }} />
        <p className="text-sm font-medium text-gray-700">Not Soil ({crop?.entries ?? '—'})</p>
      </div>
    </div>
  );

  return (
    <div className="relative overflow-hidden rounded-2xl p-6 shadow-2xl border border-gray-200 bg-white h-full flex flex-col">
      <h3 className="relative z-10 text-sm font-semibold uppercase tracking-[0.2em] mb-4 text-gray-700">Dataset Metrics</h3>

      <div className="relative z-10 flex-1 w-full min-h-[220px] flex items-center justify-center">
        {hasData ? (
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={data}
                cx="50%"
                cy="45%"
                innerRadius={70}
                outerRadius={110}
                startAngle={90}
                endAngle={-270}
                dataKey="value"
                labelLine={false}
                label={renderLabel}
              >
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} stroke="none" />
                ))}
              </Pie>
            </PieChart>
          </ResponsiveContainer>
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center gap-3">
            <div className="w-40 h-40 rounded-full bg-gray-100 animate-pulse" />
            <div className="flex items-center gap-4">
              <div className="w-20 h-4 rounded bg-gray-100 animate-pulse" />
              <div className="w-20 h-4 rounded bg-gray-100 animate-pulse" />
            </div>
          </div>
        )}
      </div>

      {renderCustomLegend()}
    </div>
  );
}
