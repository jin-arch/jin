import { useState, useRef } from "react";
import { X, Upload } from "lucide-react";
import { Button } from "@/components/atoms/button/button";

interface AddCropModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: {
    name: string;
    imageUrl?: string;
    preferredSoilType?: string;
    recommendedSoilColor?: string;
    reasoning?: string;
  }) => void;
}

const SOIL_TYPES = ["Loamy", "Sandy", "Clay", "Silt", "Sandy Loam", "Clay Loam"];
const SOIL_COLORS = [
  "Dark Brown",
  "Light Brown",
  "Reddish",
  "Grayish",
  "Black",
];

export function AddCropModal({
  isOpen,
  onClose,
  onSubmit,
}: AddCropModalProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [plantName, setPlantName] = useState("");
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [preferredSoilType, setPreferredSoilType] = useState("");
  const [recommendedSoilColor, setRecommendedSoilColor] = useState("");
  const [reasoning, setReasoning] = useState("");

  if (!isOpen) return null;

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemoveImage = () => {
    setImagePreview(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleClear = () => {
    setPlantName("");
    setImagePreview(null);
    setPreferredSoilType("");
    setRecommendedSoilColor("");
    setReasoning("");
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleSubmit = () => {
    if (!plantName.trim()) {
      alert("Please enter the plant name");
      return;
    }

    onSubmit({
      name: plantName.trim(),
      imageUrl: imagePreview || undefined,
      preferredSoilType: preferredSoilType || undefined,
      recommendedSoilColor: recommendedSoilColor || undefined,
      reasoning: reasoning.trim() || undefined,
    });

    handleClear();
    onClose();
  };

  return (
    <>
      {/* Overlay */}
      <div
        className="fixed inset-0 bg-black/50 z-[60] flex items-center justify-center p-4 overflow-y-auto"
        onClick={onClose}
      >
        {/* Modal */}
        <div
          className="bg-white rounded-lg shadow-xl w-full max-w-4xl my-8 overflow-hidden flex flex-col max-h-[90vh]"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header - Light green title bar */}
          <div className="flex items-center justify-between p-6 border-b border-gray-200 bg-[#A0C878]/10">
            <h2 className="text-2xl font-bold text-[#A0C878]">ADD NEW CROP</h2>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 transition-colors"
              aria-label="Close modal"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto p-6">
            <div className="flex gap-10">
              {/* Left Column - Form Fields */}
              <div className="space-y-4 flex-1 max-w-md">
                {/* Plant Name */}
                <div>
                  <label className="block text-sm font-bold text-gray-900 uppercase mb-2">
                    Plant name
                  </label>
                  <input
                    type="text"
                    value={plantName}
                    onChange={(e) => setPlantName(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#A0C878] focus:border-transparent"
                    placeholder="Enter plant name"
                  />
                </div>

                {/* Import Image from Gallery */}
                <div>
                  <Button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="bg-[#A0C878] hover:bg-[#8FB868] text-white font-semibold px-4 py-2 rounded-lg flex items-center gap-2 w-full justify-center"
                  >
                    <Upload className="w-4 h-4" />
                    IMPORT IMAGE FROM GALLERY
                  </Button>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                  />
                  {imagePreview && (
                    <div className="mt-2 relative inline-block">
                      <img
                        src={imagePreview}
                        alt="Crop preview"
                        className="h-24 w-24 object-cover rounded-lg border border-gray-300"
                      />
                      <button
                        onClick={handleRemoveImage}
                        className="absolute -top-1 -right-1 bg-red-500 hover:bg-red-600 text-white rounded-full p-1"
                        aria-label="Remove image"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  )}
                </div>

                {/* Preferred Soil Type */}
                <div>
                  <label className="block text-sm font-bold text-gray-900 uppercase mb-2">
                    Preferred Soil Type
                  </label>
                  <select
                    value={preferredSoilType}
                    onChange={(e) => setPreferredSoilType(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#A0C878] focus:border-transparent bg-white"
                  >
                    <option value="">Select soil type</option>
                    {SOIL_TYPES.map((type) => (
                      <option key={type} value={type}>
                        {type}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Recommended Soil Color */}
                <div>
                  <label className="block text-sm font-bold text-gray-900 uppercase mb-2">
                    Recommended Soil Color
                  </label>
                  <select
                    value={recommendedSoilColor}
                    onChange={(e) => setRecommendedSoilColor(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#A0C878] focus:border-transparent bg-white"
                  >
                    <option value="">Select soil color</option>
                    {SOIL_COLORS.map((color) => (
                      <option key={color} value={color}>
                        {color}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Right Column - Reasoning */}
              <div className="flex-1 flex flex-col">
                <label className="block text-sm font-bold text-gray-900 uppercase mb-2">
                  Reasoning
                </label>
                <textarea
                  value={reasoning}
                  onChange={(e) => setReasoning(e.target.value)}
                  rows={10}
                  className="w-full flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#A0C878] focus:border-transparent resize-none"
                  placeholder="Enter why this plant is good...."
                />
              </div>
            </div>
          </div>

          {/* Footer - Action Buttons */}
          <div className="flex items-center justify-end gap-3 p-6 border-t border-gray-200">
            <Button
              onClick={() => {
                handleClear();
                onClose();
              }}
              className="bg-blue-500 hover:bg-blue-600 text-white font-semibold px-4 py-2 rounded-lg flex items-center gap-2"
            >
              CANCEL
            </Button>
            <Button
              onClick={handleSubmit}
              className="bg-[#A0C878] hover:bg-[#8FB868] text-white font-semibold px-4 py-2 rounded-lg flex items-center gap-2"
            >
              ADD CROP
            </Button>
          </div>
        </div>
      </div>
    </>
  );
}
