import type { DataEntry, DataEntryStatus } from "@/constants/data-entries";
import { Button } from "@/components/atoms/button/button";
import { cn } from "@/lib/utils";

function StatusBadge({ status }: { status: DataEntryStatus }) {
  const active = status === "ACTIVE";
  const styles = active
    ? "bg-[#94C26F] text-white"
    : "bg-gray-500 text-white";
  const label = active ? "Active" : "Inactive";

  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold uppercase tracking-[0.08em] leading-none",
        styles
      )}
    >
      <span
        className="w-1.5 h-1.5 rounded-full bg-white/90 shrink-0"
        aria-hidden
      />
      {label}
    </span>
  );
}

interface DataEntryCardProps {
  entry: DataEntry;
  onView: (entry: DataEntry) => void;
}

export function DataEntryCard({ entry, onView }: DataEntryCardProps) {
  return (
    <article className="bg-[#efefef] rounded-[10px] border border-[#bebebe] shadow-[0_1px_4px_rgba(0,0,0,0.16)] p-3 flex flex-col md:flex-row md:items-stretch gap-3 md:gap-3 font-['Poppins',sans-serif]">
      <div className="flex flex-col md:flex-row md:items-center gap-3 md:gap-3 flex-1 min-w-0">
        <div className="shrink-0 rounded-lg border border-[#cccccc] overflow-hidden bg-stone-200 mx-auto md:mx-0 w-fit">
          <img
            src={entry.imageUrl || "/logo.svg"}
            alt={`Capture ${entry.scanId}`}
            className="w-[146px] h-[104px] object-cover object-center block"
          />
        </div>

        <div className="flex flex-col gap-y-0.5 text-[14px] leading-[1.2] text-[#2f2f2f] font-semibold flex-1 min-w-0 text-center md:text-left">
          <p>
            <span className="font-bold">Scan ID:</span> {entry.scanId}
          </p>
          <p>
            <span className="font-bold">User ID:</span> {entry.userId}
          </p>
          {entry.userProfile?.contactNumber && (
            <p>
              <span className="font-bold">Phone:</span> {entry.userProfile.contactNumber}
            </p>
          )}
          {entry.userProfile?.biography && (
            <p className="truncate">
              <span className="font-bold">Bio:</span> {entry.userProfile.biography}
            </p>
          )}
          <p>
            <span className="font-bold">Date Captured:</span> {entry.dateCaptured}
          </p>
          <p>
            <span className="font-bold">Location:</span> {entry.location}
          </p>
          <div className="flex items-center justify-center md:justify-start gap-1.5 pt-0.5">
            <span className="font-bold text-[#2f2f2f]">Status:</span>
            <span>
              <StatusBadge status={entry.status} />
            </span>
          </div>
        </div>
      </div>

      <div className="shrink-0 flex justify-center md:justify-end md:self-stretch md:items-end md:pl-2">
        <Button
          type="button"
          onClick={() => onView(entry)}
          className="w-[120px] md:w-[120px] h-[100px] md:h-[50px] !bg-[linear-gradient(90deg,#99CF7D_0%,#53C785_100%)] hover:!bg-[linear-gradient(90deg,#8dc273_0%,#48b977_100%)] !text-white font-bold text-[17px] md:text-[20px] leading-none tracking-[0.01em] rounded-md shadow-[0_2px_6px_rgba(0,0,0,0.18)]"
        >
          VIEW
        </Button>
      </div>
    </article>
  );
}
