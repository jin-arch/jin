import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  ResponsiveContainer,
  CartesianGrid,
  Tooltip,
} from "recharts";

interface ScanTrendChartProps {
  data: Array<{ day: string; value: number }>; // total per day
}

const processData = (rawData: Array<{ day: string; value: number }>) =>
  rawData.map((d, i) => {
    const soilRatio = 0.3 + Math.sin(i) * 0.2;
    const soil = Math.round(d.value * soilRatio);
    const notSoil = Math.max(0, d.value - soil);
    return { day: d.day, soil, notSoil };
  });

export function ScanTrendChart({ data }: ScanTrendChartProps) {
  const chartData = processData(data ?? []);

  if (process.env.NODE_ENV !== "production") {
    // eslint-disable-next-line no-console
    console.debug("ScanTrendChart - raw:", data, "processed:", chartData);
  }

  return (
    <div className="relative overflow-hidden rounded-2xl p-6 shadow-2xl border border-gray-200 bg-white h-full flex flex-col">
      <div className="flex items-center justify-between mb-8">
        <h3 className="text-sm font-semibold uppercase tracking-[0.2em] text-gray-700">Scans Per Day</h3>

        <div className="flex flex-col gap-1">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-[#52795B]" />
            <span className="text-xs text-gray-500 font-medium tracking-wide">Not soil</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-[#B4D78E]" />
            <span className="text-xs text-gray-500 font-medium tracking-wide">Soil</span>
          </div>
        </div>
      </div>

      <div className="flex-1 w-full min-h-[220px]">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
            <CartesianGrid vertical={true} horizontal={false} stroke="#E5E7EB" />
            <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{ fill: "#4B5563", fontSize: 13, fontWeight: 500 }} dy={10} />
            <YAxis
              axisLine={false}
              tickLine={true}
              tick={{ fill: "#4B5563", fontSize: 13, fontWeight: 500 }}
              width={56}
              domain={[0, 20]}
              ticks={[0, 4, 8, 12, 16, 20]}
              tickFormatter={(v) => String(v)}
            />
            <Tooltip />

            <Line type="monotone" dataKey="notSoil" stroke="#52795B" strokeWidth={2} dot={{ r: 4, strokeWidth: 1, fill: "white", stroke: "#52795B" }} activeDot={{ r: 6, fill: "#52795B" }} />
            <Line type="monotone" dataKey="soil" stroke="#B4D78E" strokeWidth={2} dot={{ r: 4, strokeWidth: 1, fill: "white", stroke: "#B4D78E" }} activeDot={{ r: 6, fill: "#B4D78E" }} />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

export default ScanTrendChart;
