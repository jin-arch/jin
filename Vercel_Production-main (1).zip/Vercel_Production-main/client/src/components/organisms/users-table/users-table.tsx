import { useState, useMemo, useEffect } from "react";
import { Eye, UserX, Check } from "lucide-react";
import { useUsers, useDisableUser } from "@/hooks/use-users";
import ConfirmModal from "@/components/molecules/confirm-modal/confirm-modal";
import Toast from "@/components/molecules/toast/toast";
import type { User } from "@/constants/users";
import { cn } from "@/lib/utils";
import { Pagination } from "@/components/molecules/pagination/pagination";
import { PAGINATION_PAGE_SIZE } from "@/constants/index";

interface UsersTableProps {
  onView?: (user: User) => void;
}

export function UsersTable({ onView }: UsersTableProps) {
  const { data: users, isLoading, error } = useUsers();
  const disableMutation = useDisableUser();
  const [currentPage, setCurrentPage] = useState(1);
  const [confirmUser, setConfirmUser] = useState<User | null>(null);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);
  const [pendingUserId, setPendingUserId] = useState<string | null>(null);

  // Format joinedAt into YYYY-MM-DD. Accepts numeric ms, ISO strings, or M/D/YYYY.
  const formatJoinedAt = (val?: string | null) => {
    if (!val) return "";
    const s = String(val).trim();

    const toPHDateString = (d: Date) => {
      if (isNaN(d.getTime())) return String(val);
      // Convert UTC ms -> add 8 hours to get Philippine time, then format YYYY-MM-DD
      const ph = new Date(d.getTime() + 8 * 60 * 60 * 1000);
      return ph.toISOString().slice(0, 10);
    };

    // All-digits -> milliseconds since epoch
    if (/^\d+$/.test(s)) {
      const t = Number(s);
      const d = new Date(t);
      return toPHDateString(d);
    }

    // Slash format M/D/YYYY or MM/DD/YYYY
    if (s.includes("/")) {
      const parts = s.split("/").map((p) => p.trim());
      if (parts.length >= 3) {
        const m = parseInt(parts[0], 10) - 1;
        const d = parseInt(parts[1], 10);
        const y = parseInt(parts[2], 10);
        const dt = new Date(Date.UTC(y, m, d));
        return toPHDateString(dt);
      }
      return s;
    }

    // Fallback parse (ISO or other string)
    const parsed = new Date(s);
    return isNaN(parsed.getTime()) ? s : toPHDateString(parsed);
  };

  const handleDisable = (user: User) => {
    // open confirmation modal
    setConfirmUser(user);
  };

  const handleDisableConfirm = (user: User, disabled = true) => {
    setPendingUserId(user.id);
    disableMutation.mutate(
      { id: user.id, disabled },
      {
        onSuccess: () => {
          setToast({ message: `User ${user.name} ${disabled ? 'disabled' : 'enabled'}`, type: 'success' });
          setConfirmUser(null);
          setPendingUserId(null);
          // optimistic update already applied; onSettled will invalidate the users cache
          setTimeout(() => setToast(null), 3500);
        },
        onError: (err: any) => {
          setToast({ message: `Failed to ${disabled ? 'disable' : 'enable'} ${user.name}: ${err?.message || err}`, type: 'error' });
          setConfirmUser(null);
          setPendingUserId(null);
          setTimeout(() => setToast(null), 5000);
        },
      }
    );
  };

  const handleView = (user: User) => {
    onView?.(user);
  };

  

  

  const getInitials = (name?: string): string => {
    const src = (name || "").trim();
    if (!src) return "--";
    return src
      .split(/\s+/)
      .map((n) => (n && n.length > 0 ? n[0] : ""))
      .join("")
      .toUpperCase()
      .substring(0, 2);
  };

  // Pagination logic - must be before early returns (Rules of Hooks)
  const paginatedUsers = useMemo(() => {
    if (!users) return [];
    const startIndex = (currentPage - 1) * PAGINATION_PAGE_SIZE;
    const endIndex = startIndex + PAGINATION_PAGE_SIZE;
    return users.slice(startIndex, endIndex);
  }, [users, currentPage]);

  const totalPages = Math.ceil((users?.length || 0) / PAGINATION_PAGE_SIZE);

  // Reset to page 1 if current page is out of bounds
  useEffect(() => {
    if (currentPage > totalPages && totalPages > 0) {
      setCurrentPage(1);
    }
  }, [currentPage, totalPages]);

  if (isLoading) {
    return (
      <div className="animate-pulse">
        <div className="overflow-x-auto">
          <table className="w-full table-fixed min-w-[920px]">
            <colgroup>
              {/* selection column removed */}
              <col className="w-[30%]" />
              <col className="w-[12%]" />
              <col className="w-[14%]" />
              <col className="w-[24%]" />
              <col className="w-[12%]" />
              <col className="w-[8%]" />
            </colgroup>
            <thead>
              <tr className="border-b border-gray-200">
                {/* selection header removed */}
                <th className="py-4 px-4 text-left text-sm font-medium text-gray-400 uppercase tracking-wide">NAME</th>
                <th className="py-4 px-4 text-left text-sm font-medium text-gray-400 uppercase tracking-wide">STATUS</th>
                <th className="py-4 px-4 text-left text-sm font-medium text-gray-400 uppercase tracking-wide">JOINED AT</th>
                <th className="py-4 px-4 text-left text-sm font-medium text-gray-400 uppercase tracking-wide">EMAIL</th>
                <th className="py-4 px-4 text-left text-sm font-medium text-gray-400 uppercase tracking-wide">CONTACT NUMBER</th>
                <th className="py-4 px-4 text-left text-sm font-medium text-gray-400 uppercase tracking-wide">ACTIONS</th>
              </tr>
            </thead>
            <tbody>
              {Array.from({ length: 6 }).map((_, index) => (
                <tr key={`users-loading-row-${index}`} className="border-b border-gray-200">
                  <td className="py-4 px-4">
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 rounded-full bg-gray-200" />
                      <div className="h-4 w-32 rounded bg-gray-200" />
                    </div>
                  </td>
                  <td className="py-4 px-4">
                    <div className="h-4 w-20 rounded bg-gray-200" />
                  </td>
                  <td className="py-4 px-4">
                    <div className="h-4 w-28 rounded bg-gray-200" />
                  </td>
                  <td className="py-4 px-4">
                    <div className="h-4 w-44 rounded bg-gray-200" />
                  </td>
                  <td className="py-4 px-4">
                    <div className="h-4 w-28 rounded bg-gray-200" />
                  </td>
                  <td className="py-4 px-4">
                    <div className="flex items-center gap-2">
                      <div className="h-8 w-8 rounded bg-gray-200" />
                      <div className="h-8 w-8 rounded bg-gray-200" />
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="mt-4 text-sm text-slate-500">Loading users...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center py-12">
        <p className="text-red-500">Error loading users</p>
      </div>
    );
  }

  if (!users || users.length === 0) {
    return (
      <div className="flex items-center justify-center py-12">
        <p className="text-gray-500">No users available.</p>
      </div>
    );
  }

  

  

  return (
    <div className="font-['Poppins',sans-serif]">
      <div className="overflow-x-auto">
          <table className="w-full table-fixed min-w-[920px]">
            <colgroup>
            {/* selection column removed */}
            <col className="w-[30%]" />
            <col className="w-[12%]" />
            <col className="w-[14%]" />
            <col className="w-[24%]" />
            <col className="w-[12%]" />
            <col className="w-[8%]" />
          </colgroup>
          <thead>
            <tr className="border-b border-gray-200">
              <th className="text-left py-4 px-4 text-sm font-medium text-gray-600 uppercase tracking-wide">NAME</th>
              <th className="text-left py-4 px-4 text-sm font-medium text-gray-600 uppercase tracking-wide">STATUS</th>
              <th className="text-left py-4 px-4 text-sm font-medium text-gray-600 uppercase tracking-wide">JOINED AT</th>
              <th className="text-left py-4 px-4 text-sm font-medium text-gray-600 uppercase tracking-wide">EMAIL</th>
              <th className="text-left py-4 px-4 text-sm font-medium text-gray-600 uppercase tracking-wide">CONTACT NUMBER</th>
              <th className="text-left py-4 px-4 text-sm font-medium text-gray-600 uppercase tracking-wide">ACTIONS</th>
            </tr>
          </thead>
          <tbody>
            {paginatedUsers.map((user) => (
              <tr key={user.id} className="border-b border-gray-200 hover:bg-gray-50 transition-colors">
                <td className="py-4 px-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-[#A0C878] flex items-center justify-center text-white font-semibold text-sm flex-shrink-0">
                      {user.avatar ? (
                        <img src={user.avatar} alt={user.name || user.id} className="w-full h-full rounded-full object-cover" />
                      ) : (
                        getInitials(user.name || user.id)
                      )}
                    </div>
                    <span className="font-medium text-gray-900 truncate">{user.name || user.id}</span>
                  </div>
                </td>
                <td className="py-4 px-4">
                  <div className="flex items-center gap-2">
                    <div className={cn("w-2 h-2 rounded-full", user.status === "ACTIVE" ? "bg-green-500" : "bg-red-500")} />
                    <span className="text-sm text-gray-700">{user.status}</span>
                  </div>
                </td>
                <td className="py-4 px-4 text-sm text-gray-700 whitespace-nowrap">{formatJoinedAt(user.joinedAt)}</td>
                <td className="py-4 px-4 text-sm text-gray-700 truncate" title={user.email}>{user.email}</td>
                <td className="py-4 px-4 text-sm text-gray-700 truncate" title={user.contactNumber}>{user.contactNumber}</td>
                <td className="py-4 px-4">
                  <div className="flex items-center gap-2">
                    <button onClick={() => handleView(user)} disabled={disableMutation.isPending} className="w-8 h-8 bg-[#A0C878] hover:bg-[#8FB868] text-white rounded flex items-center justify-center transition-colors disabled:opacity-50 disabled:cursor-not-allowed" aria-label={`View ${user.name}`}>
                      <Eye className="w-4 h-4" />
                    </button>
                    {user.status === 'ACTIVE' ? (
                      <button onClick={() => handleDisable(user)} disabled={disableMutation.isPending || pendingUserId === user.id} className="w-8 h-8 bg-yellow-500 hover:bg-yellow-600 text-white rounded flex items-center justify-center transition-colors disabled:opacity-50 disabled:cursor-not-allowed" aria-label={`Disable ${user.name}`} title="Disable user">
                        <UserX className="w-4 h-4" />
                      </button>
                    ) : (
                      <button onClick={() => setConfirmUser(user)} disabled={disableMutation.isPending || pendingUserId === user.id} className="w-8 h-8 bg-green-500 hover:bg-green-600 text-white rounded flex items-center justify-center transition-colors disabled:opacity-50 disabled:cursor-not-allowed" aria-label={`Enable ${user.name}`} title="Enable user">
                        <Check className="w-4 h-4" />
                      </button>
                    )}
                    {/* delete action removed — only disable/enable supported */}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {/* Confirmation modal and toast (shared components) */}
      <ConfirmModal
        isOpen={!!confirmUser}
        title={confirmUser ? (confirmUser.status === 'ACTIVE' ? 'Disable user' : 'Enable user') : undefined}
        description={confirmUser ? (
          <>Are you sure you want to {confirmUser.status === 'ACTIVE' ? 'disable' : 'enable'} <strong>{confirmUser.name}</strong>? This will {confirmUser.status === 'ACTIVE' ? 'prevent them from signing in.' : 'allow them to sign in.'}</>
        ) : undefined}
        confirmLabel={confirmUser ? (confirmUser.status === 'ACTIVE' ? 'Disable' : 'Enable') : 'Confirm'}
        loading={disableMutation.isPending && !!confirmUser && pendingUserId === confirmUser.id}
        onCancel={() => setConfirmUser(null)}
        onConfirm={() => confirmUser && handleDisableConfirm(confirmUser, confirmUser.status === 'ACTIVE')}
      />

      {toast && (
        <div className="fixed right-6 top-6 z-70">
          <Toast message={toast.message} type={toast.type === 'success' ? 'success' : 'error'} onClose={() => setToast(null)} />
        </div>
      )}

      {/* Pagination */}
      <Pagination
        currentPage={currentPage}
        totalPages={totalPages}
        onPageChange={setCurrentPage}
        pageSize={PAGINATION_PAGE_SIZE}
        totalItems={users.length}
      />
    </div>
  );
}
