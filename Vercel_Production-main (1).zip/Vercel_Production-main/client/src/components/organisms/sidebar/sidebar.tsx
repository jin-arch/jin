import { Link, useLocation, useNavigate } from "react-router-dom";
import {
  CircleGauge,
  Users,
  Menu,
  Sprout,
  LogOut,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/use-auth";

interface SidebarItem {
  label: string;
  path: string;
  icon: React.ComponentType<{ className?: string }>;
}

const sidebarItems: SidebarItem[] = [
  {
    label: "Dashboard",
    path: "/dashboard",
    icon: CircleGauge,
  },
  {
    label: "User Management",
    path: "/dashboard/users",
    icon: Users,
  },
  {
    label: "Data Management",
    path: "/dashboard/data",
    icon: Sprout,
  },
];

interface SidebarProps {
  isOpen: boolean;
  onToggle: () => void;
}

export function Sidebar({ isOpen, onToggle }: SidebarProps) {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, logout } = useAuth();

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 md:hidden"
          onClick={onToggle}
        />
      )}

      {/* Sidebar */}
      <aside
        className={cn(
          "fixed left-0 top-0 h-full bg-[#88A86F] text-white transition-all duration-300 z-50 flex flex-col border-l-2 border-black",
          isOpen
            ? "translate-x-0 w-64"
            : "-translate-x-full md:translate-x-0 md:w-20"
        )}
      >
        {/* Header with logo and toggle */}
        <div className="p-6 border-b border-white/20">
          <div className="flex items-center justify-between mb-6">
            <div
              className={cn(
                "flex items-center gap-2",
                !isOpen && "md:justify-center"
              )}
            >
              {isOpen && (
                <img src="/logo.svg" alt="EcoFarm AI" className="h-12 w-auto" />
              )}
            </div>
            <button
              onClick={onToggle}
              className="text-white hover:text-white/80 flex-shrink-0"
            >
              <Menu className="w-6 h-6" />
            </button>
          </div>

          {/* User Profile */}
          {user && (
            <div
              className={cn(
                "flex items-center gap-3",
                !isOpen && "md:justify-center"
              )}
            >
              <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center text-white font-semibold flex-shrink-0">
                {user.username.charAt(0).toUpperCase()}
              </div>
              {isOpen && (
                <div>
                  <p className="font-semibold text-sm">{user.username}</p>
                  <p className="text-xs text-white/80">
                    {user.role.toUpperCase()}
                  </p>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto p-4 flex flex-col">
          <ul className="space-y-2 flex-1">
            {sidebarItems.map((item) => {
              const Icon = item.icon;
              const isActive = location.pathname === item.path;

              return (
                <li key={item.path}>
                  <Link
                    to={item.path}
                    onClick={() => {
                      // Close sidebar on mobile when navigating
                      if (window.innerWidth < 768) {
                        onToggle();
                      }
                    }}
                    className={cn(
                      "flex items-center gap-3 px-4 py-3 rounded-lg transition-colors font-semibold text-sm text-white",
                      !isOpen && "md:justify-center md:px-2",
                      isActive
                        ? "border-2 border-white shadow-sm"
                        : "border-2 border-transparent hover:bg-white/10"
                    )}
                    title={!isOpen ? item.label : undefined}
                  >
                    <Icon className="w-5 h-5 flex-shrink-0" />
                    {isOpen && <span className="text-sm">{item.label}</span>}
                  </Link>
                </li>
              );
            })}
          </ul>

          {/* Logout Button */}
          <div className="pt-4 border-t border-white/20">
            <button
              onClick={handleLogout}
              className={cn(
                "w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors text-white hover:bg-white/10",
                !isOpen && "md:justify-center md:px-2"
              )}
              title={!isOpen ? "Logout" : undefined}
            >
              <LogOut className="w-5 h-5 flex-shrink-0" />
              {isOpen && <span className="text-sm">Logout</span>}
            </button>
          </div>
        </nav>
      </aside>
    </>
  );
}
