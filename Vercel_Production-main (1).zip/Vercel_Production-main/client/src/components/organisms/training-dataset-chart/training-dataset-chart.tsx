import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  ResponsiveContainer,
  Cell,
  LabelList,
} from "recharts";

interface TrainingDatasetChartProps {
  value: number;
  description?: string;
}

const COLORS = ["#A0C878", "#8FB868", "rgba(87, 199, 133, 0.84)"];

export function TrainingDatasetChart({
  value,
  description = "Samples",
}: TrainingDatasetChartProps) {
  const totalValue = value;
  const sampleData = [
    { name: "Training", value: Math.floor(totalValue * 0.6) }, // 60%
    { name: "Validation", value: Math.floor(totalValue * 0.2) }, // 20%
    { name: "Test", value: Math.floor(totalValue * 0.2) }, // 20%
  ];

  return (
    <div
      className="relative overflow-hidden rounded-2xl p-6 shadow-[0_18px_40px_rgba(42,123,155,0.18)] border border-white/25 text-white h-full flex flex-col"
      style={{
        background:
          "radial-gradient(120% 120% at 50% 50%, #2A7B9B 0%, #57C785 50%, #EDDD53 100%)",
      }}
    >
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(255,255,255,0.22),transparent_40%),radial-gradient(circle_at_bottom_left,rgba(255,255,255,0.12),transparent_36%)]" />

      <h3 className="relative z-10 text-sm font-semibold uppercase tracking-[0.2em] mb-6 text-white">
        Training Dataset Size
      </h3>
      <div className="relative z-10 flex-1 flex flex-col min-h-0">
        {/* Large number display */}
        <div className="mb-4">
          <p className="text-5xl font-bold text-white drop-shadow-[0_2px_8px_rgba(0,0,0,0.12)]">
            {value}
          </p>
        </div>

        {/* Bar chart */}
        <div className="flex-1 w-full min-h-0" style={{ minHeight: "200px" }}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={sampleData}
              margin={{ top: 30, right: 10, bottom: 5, left: 0 }}
            >
              <XAxis
                dataKey="name"
                tick={{ fontSize: 12, fill: "rgba(255,255,255,0.9)" }}
                axisLine={false}
                tickLine={false}
                label={{
                  value: description,
                  position: "insideBottom",
                  offset: -5,
                  style: {
                    textAnchor: "middle",
                    fill: "rgba(255,255,255,0.9)",
                    fontSize: "12px",
                  },
                }}
              />
              <YAxis
                type="number"
                tick={{ fontSize: 12, fill: "rgba(255,255,255,0.9)" }}
                axisLine={false}
                tickLine={false}
                width={40}
              />
              <Bar dataKey="value" radius={[8, 8, 0, 0]}>
                {sampleData.map((_entry, index) => (
                  <Cell
                    key={`cell-${index}`}
                    fill={COLORS[index % COLORS.length]}
                  />
                ))}
                <LabelList
                  dataKey="value"
                  position="top"
                  style={{
                    fill: "#ffffff",
                    fontSize: "12px",
                    fontWeight: "500",
                  }}
                />
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
