import { LoginForm } from "@/components/organisms/login-form/login-form";

export function LoginPage() {
  return (
    <div className="min-h-screen flex">
      {/* Left Column - 2/3 width with green background */}
      <div className="hidden md:flex w-2/3 bg-[#8FB868] items-center justify-center">
        <div className="text-center">
          <img
            src="/logo.svg"
            alt="EcoFarm AI Logo"
            className="mx-auto max-w-md w-full h-auto"
          />
        </div>
      </div>

      {/* Right Column - 1/3 width with white background */}
      <div className="w-full md:w-1/3 bg-white flex items-center justify-center px-8 py-12">
        <div className="w-full max-w-md">
          <LoginForm />
        </div>
      </div>
    </div>
  );
}
