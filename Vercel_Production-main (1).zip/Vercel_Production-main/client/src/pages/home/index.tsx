import { Link } from "react-router-dom";
import { ExampleForm } from "@/components/organisms/example-form/example-form";
import { Button } from "@/components/atoms/button/button";

export function HomePage() {
  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-2xl space-y-8">
        <div className="text-center">
          <h1 className="text-4xl font-bold mb-4">Welcome to ECOFARMAI</h1>
          <p className="text-muted-foreground mb-6">
            React + TypeScript + Vite + Tailwind CSS + shadcn/ui
          </p>
          <Link to="/login">
            <Button className="bg-[#A0C878] hover:bg-[#8FB868] text-white">
              Go to Login Page
            </Button>
          </Link>
        </div>

        <div className="border rounded-lg p-6">
          <h2 className="text-2xl font-semibold mb-4">Example Form</h2>
          <p className="text-sm text-muted-foreground mb-6">
            This form demonstrates react-hook-form with Zod validation
          </p>
          <ExampleForm />
        </div>
      </div>
    </div>
  );
}
