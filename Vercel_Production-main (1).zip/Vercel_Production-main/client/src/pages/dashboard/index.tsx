import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Users, Sprout, Target, MessageSquare } from "lucide-react";
import { DashboardLayout } from "@/components/templates/dashboard-layout/dashboard-layout";
import { MetricCard } from "@/components/molecules/metric-card/metric-card";
import { FeedbacksModal } from "@/components/organisms/feedbacks-modal/feedbacks-modal";
import { FeedbackDetailModal } from "@/components/organisms/feedback-detail-modal/feedback-detail-modal";
import { useDashboard } from "@/hooks/use-dashboard";
import { useFeedbacks } from "@/hooks/use-feedbacks";
import type { Feedback } from "@/constants/feedbacks";
import ScanTrendChart from "@/components/organisms/scan-trend-chart/scan-trend-chart";
import { DatasetChart } from "@/components/organisms/dataset-chart/dataset-chart";

const TOP_CARD_CLASSNAME = "min-h-[170px] w-full";

export function DashboardPage() {
  const { data, isLoading, error } = useDashboard();
  const { data: feedbackData } = useFeedbacks();
  const [isFeedbacksModalOpen, setIsFeedbacksModalOpen] = useState(false);
  const [isFeedbackDetailOpen, setIsFeedbackDetailOpen] = useState(false);
  const [selectedFeedback, setSelectedFeedback] = useState<Feedback | null>(null);
  const navigate = useNavigate();

  // Static accuracy per mockup request
  const accuracyValue = 91;
  const actualFeedbackCount = feedbackData?.length;
  const displayedFeedbackCount =
    typeof actualFeedbackCount === "number" && actualFeedbackCount > 0
      ? actualFeedbackCount
      : (data?.feedbacks ?? 0);

  // Render skeletons while loading
  if (isLoading) {
    return (
      <DashboardLayout title="Dashboard">
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 items-stretch">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="min-h-[170px] rounded-2xl bg-white p-6 shadow border border-gray-100">
                <div className="h-6 w-40 bg-gray-100 rounded mb-4 animate-pulse" />
                <div className="h-8 w-24 bg-gray-100 rounded animate-pulse" />
              </div>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-10 gap-6 items-stretch">
            <div className="lg:col-span-6 min-h-[360px] rounded-2xl bg-white p-6 shadow border border-gray-100 animate-pulse" />
            <div className="lg:col-span-4 min-h-[360px] rounded-2xl bg-white p-6 shadow border border-gray-100 animate-pulse" />
          </div>
        </div>
      </DashboardLayout>
    );
  }

  if (error) {
    return (
      <DashboardLayout title="Dashboard">
        <div className="flex items-center justify-center h-64">
          <p className="text-red-500">Error loading dashboard data</p>
        </div>
      </DashboardLayout>
    );
  }

  if (!data) return null;

  return (
    <DashboardLayout
      title="Dashboard"
      subtitle="Get an overview of users, model status, and system performance."
    >
      <div className="space-y-4">
        {/* Top Cards Row */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 items-stretch">
          <MetricCard
            label="Users"
            value={data.users}
            variant="light"
            icon={<Users className="w-5 h-5 text-gray-800" />}
            trend={{ value: "+1.2%", isPositive: true }}
            className={TOP_CARD_CLASSNAME}
            button={{
              label: "VIEW USER MANAGEMENT",
              onClick: () => navigate("/dashboard/users"),
            }}
          />
          <MetricCard
            label="Scans"
            value={data.scans ?? 0}
            variant="light"
            icon={<Sprout className="w-5 h-5 text-gray-800" />}
            trend={{ value: "+15.3%", isPositive: true }}
            className={TOP_CARD_CLASSNAME}
            button={{
              label: "VIEW DATA MANAGEMENT",
              onClick: () => navigate("/dashboard/data"),
            }}
          />
          <MetricCard
            label="Accuracy"
            value={`${accuracyValue}%`}
            variant="light"
            icon={<Target className="w-5 h-5 text-gray-800" />}
            className={TOP_CARD_CLASSNAME}
          />
          <MetricCard
            label="Feedbacks"
            value={displayedFeedbackCount}
            variant="light"
            icon={<MessageSquare className="w-5 h-5 text-gray-800 fill-gray-800" />}
            className={TOP_CARD_CLASSNAME}
            button={{
              label: "VIEW",
              hasNotification: true,
              onClick: () => setIsFeedbacksModalOpen(true),
            }}
          />
        </div>

        {/* Charts Row */}
        <div className="grid grid-cols-1 lg:grid-cols-10 gap-6 items-stretch">
          <div className="lg:col-span-6 min-h-[360px]">
            <ScanTrendChart data={data.scansPerDay ?? []} />
          </div>
          <div className="lg:col-span-4 min-h-[360px]">
            <DatasetChart
              crop={{ entries: 2527, percentage: 63 }}
              soil={{ entries: 1030, percentage: 37 }}
            />
          </div>
        </div>
      </div>

      {/* Feedbacks Modal */}
      <FeedbacksModal
        isOpen={isFeedbacksModalOpen}
        onClose={() => setIsFeedbacksModalOpen(false)}
        onView={(feedback) => {
          setSelectedFeedback(feedback);
          setIsFeedbackDetailOpen(true);
        }}
        onDelete={(feedbackId) => {
          if (selectedFeedback?.id === feedbackId) {
            setIsFeedbackDetailOpen(false);
            setSelectedFeedback(null);
          }
        }}
      />

      {/* Feedback Detail Modal */}
      <FeedbackDetailModal
        isOpen={isFeedbackDetailOpen}
        feedback={selectedFeedback}
        onClose={() => {
          setIsFeedbackDetailOpen(false);
          setSelectedFeedback(null);
        }}
      />
    </DashboardLayout>
  );
}
