import { useState, useMemo, useEffect } from "react";
import { Search, Filter, Upload, Plus } from "lucide-react";
import { DashboardLayout } from "@/components/templates/dashboard-layout/dashboard-layout";
import { SoilCard } from "@/components/organisms/soil-card/soil-card";
import { SoilDetailModal } from "@/components/organisms/soil-detail-modal/soil-detail-modal";
import { AddSoilModal } from "@/components/organisms/add-soil-modal/add-soil-modal";
import { useSoils, useDeleteSoil, useCreateSoil, useUpdateSoil } from "@/hooks/use-soils";
import { Button } from "@/components/atoms/button/button";
import { Pagination } from "@/components/molecules/pagination/pagination";
import { PAGINATION_PAGE_SIZE } from "@/constants/index";
import type { Soil } from "@/constants/soils";

export function SoilManagementContent() {
  const { data: soils, isLoading, error } = useSoils();
  const deleteSoilMutation = useDeleteSoil();
  const createSoilMutation = useCreateSoil();
  const updateSoilMutation = useUpdateSoil();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedSoil, setSelectedSoil] = useState<Soil | null>(null);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);

  const filteredSoils = useMemo(() => {
    if (!soils) return [];
    if (!searchQuery.trim()) return soils;

    const query = searchQuery.toLowerCase().trim();
    return soils.filter((soil) => soil.id.toLowerCase().includes(query));
  }, [soils, searchQuery]);

  const paginatedSoils = useMemo(() => {
    const startIndex = (currentPage - 1) * PAGINATION_PAGE_SIZE;
    const endIndex = startIndex + PAGINATION_PAGE_SIZE;
    return filteredSoils.slice(startIndex, endIndex);
  }, [filteredSoils, currentPage]);

  const totalPages = Math.ceil(filteredSoils.length / PAGINATION_PAGE_SIZE);

  useEffect(() => {
    setCurrentPage(1);
  }, [searchQuery]);

  useEffect(() => {
    if (currentPage > totalPages && totalPages > 0) {
      setCurrentPage(1);
    }
  }, [currentPage, totalPages]);

  const handleView = (soil: Soil) => {
    setSelectedSoil(soil);
    setIsDetailModalOpen(true);
  };

  const handleDelete = (soilId: string) => {
    deleteSoilMutation.mutate(soilId, {
      onSuccess: () => {
        if (selectedSoil?.id === soilId) {
          setIsDetailModalOpen(false);
          setSelectedSoil(null);
        }
      },
    });
  };

  const handleCloseModal = () => {
    setIsDetailModalOpen(false);
    setSelectedSoil(null);
  };

  const handleEdit = (soil: Soil) => {
    console.log("Edit soil:", soil);
  };

  const handleSubmitEdit = (data: {
    uploadedBy: string;
    location: string;
    tags: string[];
    soilColor: string;
    soilTexture: string;
    suitability: "SUITABLE" | "NEEDS_IMPROVEMENT";
    recommendations: string;
    imageUrl?: string;
  }) => {
    if (!selectedSoil) return;

    updateSoilMutation.mutate(
      {
        id: selectedSoil.id,
        data: {
          uploadedBy: data.uploadedBy,
          location: data.location.trim() || undefined,
          tags: data.tags.filter((tag) => tag.trim().length > 0),
          soilColor: data.soilColor.trim() || undefined,
          soilTexture: data.soilTexture.trim() || undefined,
          suitability: data.suitability,
          recommendations: data.recommendations.trim() || undefined,
          imageUrl: data.imageUrl,
        },
      },
      {
        onSuccess: (updatedSoil) => {
          setSelectedSoil(updatedSoil);
        },
        onError: (error) => {
          console.error("Error updating soil:", error);
          alert("Failed to update soil. Please try again.");
        },
      }
    );
  };

  const handleAddNewSoil = () => {
    setIsAddModalOpen(true);
  };

  const handleCloseAddModal = () => {
    setIsAddModalOpen(false);
  };

  const handleSubmitNewSoil = (data: {
    uploadedBy: string;
    location: string;
    tags: string[];
    soilColor: string;
    soilTexture: string;
    suitability: "SUITABLE" | "NEEDS_IMPROVEMENT";
    recommendations: string;
    imageUrl?: string;
  }) => {
    createSoilMutation.mutate(
      {
        uploadedBy: data.uploadedBy,
        location: data.location.trim() || undefined,
        tags: data.tags.filter((tag) => tag.trim().length > 0),
        soilColor: data.soilColor.trim() || undefined,
        soilTexture: data.soilTexture.trim() || undefined,
        suitability: data.suitability,
        recommendations: data.recommendations.trim() || undefined,
        imageUrl: data.imageUrl,
      },
      {
        onSuccess: () => {
          setIsAddModalOpen(false);
          setCurrentPage(1);
        },
        onError: (error) => {
          console.error("Error creating soil:", error);
          alert("Failed to create soil. Please try again.");
        },
      }
    );
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <p className="text-gray-500">Loading soils...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center h-64">
        <p className="text-red-500">Error loading soils</p>
      </div>
    );
  }

  return (
    <>
      <div className="space-y-6">
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-4">
          <div className="flex gap-3 mb-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Search soil by ID"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#A0C878] focus:border-transparent"
              />
            </div>
            <Button
              className="bg-[#A0C878] hover:bg-[#8FB868] text-white font-semibold px-4 py-2 rounded-lg flex items-center gap-2"
              onClick={() => {
                console.log("Filter clicked");
              }}
            >
              <Filter className="w-4 h-4" />
              FILTER
            </Button>
          </div>

          <div className="flex gap-3">
            <Button
              className="bg-[#A0C878] hover:bg-[#8FB868] text-white font-semibold px-4 py-2 rounded-lg flex items-center gap-2"
              onClick={() => {
                console.log("Upload soil clicked");
              }}
            >
              <Upload className="w-4 h-4" />
              UPLOAD SOIL
            </Button>
            <Button
              className="bg-[#A0C878] hover:bg-[#8FB868] text-white font-semibold px-4 py-2 rounded-lg flex items-center gap-2"
              onClick={handleAddNewSoil}
            >
              <Plus className="w-4 h-4" />
              ADD NEW SOIL
            </Button>
          </div>
        </div>

        <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
          <div className="p-4 space-y-4">
            {paginatedSoils.length > 0 ? (
              paginatedSoils.map((soil) => (
                <SoilCard
                  key={soil.id}
                  soil={soil}
                  onView={handleView}
                  onDelete={handleDelete}
                />
              ))
            ) : (
              <div className="p-12 text-center">
                <p className="text-gray-500">
                  {searchQuery.trim()
                    ? `No soils found matching "${searchQuery}"`
                    : "No soils available"}
                </p>
              </div>
            )}
          </div>

          {filteredSoils.length > 0 && (
            <Pagination
              currentPage={currentPage}
              totalPages={totalPages}
              onPageChange={setCurrentPage}
              pageSize={PAGINATION_PAGE_SIZE}
              totalItems={filteredSoils.length}
            />
          )}
        </div>
      </div>

      {isDetailModalOpen && selectedSoil && (
        <SoilDetailModal
          isOpen={isDetailModalOpen}
          soil={selectedSoil}
          onClose={handleCloseModal}
          onDelete={handleDelete}
          onEdit={handleEdit}
          onSubmit={handleSubmitEdit}
        />
      )}

      <AddSoilModal
        isOpen={isAddModalOpen}
        onClose={handleCloseAddModal}
        onSubmit={handleSubmitNewSoil}
      />
    </>
  );
}

export function SoilManagementPage() {
  return (
    <DashboardLayout title="Soil Management">
      <SoilManagementContent />
    </DashboardLayout>
  );
}
