import { useState, useMemo, useEffect } from "react";
import { Search, Filter, Upload, Plus, RotateCw } from "lucide-react";
import { DashboardLayout } from "@/components/templates/dashboard-layout/dashboard-layout";
import { CropCard } from "@/components/organisms/crop-card/crop-card";
import { AddCropModal } from "@/components/organisms/add-crop-modal";
import { useCrops, useDeleteCrop, useCreateCrop } from "@/hooks/use-crops";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/atoms/button/button";
import { Pagination } from "@/components/molecules/pagination/pagination";
import { PAGINATION_PAGE_SIZE } from "@/constants/index";
import type { Crop } from "@/constants/crops";

export function CropManagementContent() {
  const { user } = useAuth();
  const { data: crops, isLoading, error } = useCrops();
  const deleteCropMutation = useDeleteCrop();
  const createCropMutation = useCreateCrop();
  const [searchQuery, setSearchQuery] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [isAddCropModalOpen, setIsAddCropModalOpen] = useState(false);

  const filteredCrops = useMemo(() => {
    if (!crops) return [];
    if (!searchQuery.trim()) return crops;

    const query = searchQuery.toLowerCase().trim();
    return crops.filter((crop) => crop.name.toLowerCase().includes(query));
  }, [crops, searchQuery]);

  const paginatedCrops = useMemo(() => {
    const startIndex = (currentPage - 1) * PAGINATION_PAGE_SIZE;
    const endIndex = startIndex + PAGINATION_PAGE_SIZE;
    return filteredCrops.slice(startIndex, endIndex);
  }, [filteredCrops, currentPage]);

  const totalPages = Math.ceil(filteredCrops.length / PAGINATION_PAGE_SIZE);

  useEffect(() => {
    setCurrentPage(1);
  }, [searchQuery]);

  useEffect(() => {
    if (currentPage > totalPages && totalPages > 0) {
      setCurrentPage(1);
    }
  }, [currentPage, totalPages]);

  const handleDelete = (cropId: string) => {
    deleteCropMutation.mutate(cropId);
  };

  const handleEdit = (crop: Crop) => {
    console.log("Edit crop:", crop);
  };

  const handleAddCropSubmit = (data: {
    name: string;
    imageUrl?: string;
    preferredSoilType?: string;
    recommendedSoilColor?: string;
    reasoning?: string;
  }) => {
    createCropMutation.mutate({
      name: data.name,
      uploadedBy: user?.username || "Unknown",
      location: "",
      category: "Vegetable",
      tags: [],
      imageUrl: data.imageUrl,
      description: data.reasoning,
      preferredSoilType: data.preferredSoilType,
      recommendedSoilColor: data.recommendedSoilColor,
    });
    setIsAddCropModalOpen(false);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <p className="text-gray-500">Loading crops...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center h-64">
        <p className="text-red-500">Error loading crops</p>
      </div>
    );
  }

  return (
    <>
      <div className="space-y-6">
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-4">
          <div className="flex gap-3 mb-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Search crop by name"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#A0C878] focus:border-transparent"
              />
            </div>
            <Button
              className="bg-[#A0C878] hover:bg-[#8FB868] text-white font-semibold px-4 py-2 rounded-lg flex items-center gap-2"
              onClick={() => {
                console.log("Filter clicked");
              }}
            >
              <Filter className="w-4 h-4" />
              FILTER
            </Button>
          </div>

          <div className="flex gap-3 flex-wrap">
            <Button
              className="bg-[#A0C878] hover:bg-[#8FB868] text-white font-semibold px-4 py-2 rounded-lg flex items-center gap-2"
              onClick={() => setIsAddCropModalOpen(true)}
            >
              <Plus className="w-4 h-4" />
              ADD NEW CROP
            </Button>
            <Button
              className="bg-[#A0C878] hover:bg-[#8FB868] text-white font-semibold px-4 py-2 rounded-lg flex items-center gap-2"
              onClick={() => {
                console.log("Sync to AI clicked");
              }}
            >
              <RotateCw className="w-4 h-4" />
              SYNC TO AI
            </Button>
            <Button
              className="bg-[#A0C878] hover:bg-[#8FB868] text-white font-semibold px-4 py-2 rounded-lg flex items-center gap-2"
              onClick={() => {
                console.log("Upload crop data clicked");
              }}
            >
              <Upload className="w-4 h-4" />
              UPLOAD CROP DATA
            </Button>
          </div>
        </div>

        <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
          <div className="p-4">
            {paginatedCrops.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {paginatedCrops.map((crop) => (
                  <CropCard
                    key={crop.id}
                    crop={crop}
                    onEdit={handleEdit}
                    onDelete={handleDelete}
                  />
                ))}
              </div>
            ) : (
              <div className="p-12 text-center">
                <p className="text-gray-500">
                  {searchQuery.trim()
                    ? `No crops found matching "${searchQuery}"`
                    : "No crops available"}
                </p>
              </div>
            )}
          </div>

          {filteredCrops.length > 0 && (
            <Pagination
              currentPage={currentPage}
              totalPages={totalPages}
              onPageChange={setCurrentPage}
              pageSize={PAGINATION_PAGE_SIZE}
              totalItems={filteredCrops.length}
            />
          )}
        </div>
      </div>

      <AddCropModal
        isOpen={isAddCropModalOpen}
        onClose={() => setIsAddCropModalOpen(false)}
        onSubmit={handleAddCropSubmit}
      />
    </>
  );
}

export function CropManagementPage() {
  return (
    <DashboardLayout title="Crop Management">
      <CropManagementContent />
    </DashboardLayout>
  );
}
