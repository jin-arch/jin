import { useState, useRef, type ChangeEvent } from "react";
import { DashboardLayout } from "@/components/templates/dashboard-layout/dashboard-layout";
import { UsersTable } from "@/components/organisms/users-table/users-table";
import type { User } from "@/constants/users";
import { useUploadUserPhoto } from "@/hooks/use-users";

const getPlanDetails = (plan?: User["plan"] | string) => {
  const p = String(plan ?? "").toUpperCase();
  switch (p) {
    case "BASIC":
      return {
        label: "Basic",
        gradient: "linear-gradient(135deg, #9CA3AF 0%, #D1D5DB 100%)",
        textColor: "text-gray-900",
      };
    case "PRO":
      return {
        label: "Pro",
        gradient: "linear-gradient(135deg, #8B5CF6 0%, #EC4899 100%)",
        textColor: "text-white",
      };
    case "ENTERPRISE":
      return {
        label: "Enterprise",
        gradient: "linear-gradient(135deg, #0EA5E9 0%, #9333EA 100%)",
        textColor: "text-white",
      };
    case "PREMIUM_MONTHLY":
    case "PREMIUM_YEARLY":
    case "PREMIUM":
      return {
        label: "Premium",
        gradient: "linear-gradient(135deg, #FFD700 0%, #D4AF37 100%)",
        textColor: "text-white",
      };
    case "FREE":
    case "STANDARD":
    default:
      return {
        label: "Standard",
        gradient: "linear-gradient(135deg, #6EE7B7 0%, #3B82F6 100%)",
        textColor: "text-white",
      };
  }
};

export function UserManagementPage() {
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [userSubscription, setUserSubscription] = useState<any | null>(null);
  const [userScans, setUserScans] = useState<any[] | null>(null);
  const [loadingScans, setLoadingScans] = useState(false);
  const [isScansModalOpen, setIsScansModalOpen] = useState(false);
  const [photoError, setPhotoError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const uploadPhotoMutation = useUploadUserPhoto();

  const handleView = (user: User) => {
    setSelectedUser(user);
    setIsViewModalOpen(true);
    setPhotoError(null);
    // Fetch subscription and scans for this user (admin endpoints)
    setUserSubscription(null);
    setUserScans(null);
    fetchUserSubscription(user.id).catch(() => {});
    // Also fetch enriched user profile (may include contactNumber, biography, location)
    // and merge into the selected user for the modal display.
    (async () => {
      try {
        const resp = await fetch(`${API_BASE}/api/web/users/${encodeURIComponent(user.id)}`,
          { headers: { 'X-Admin-Key': ADMIN_KEY } }
        );
        if (resp.ok) {
          const json = await resp.json();
          if (json && json.user) {
            // Replace selectedUser with server-provided enriched user to ensure phone/bio/location appear
            setSelectedUser(json.user as User);
          }
        }
      } catch (e) {
        // ignore
      }
    })();
  };

  const API_BASE = (import.meta.env.VITE_FLASK_API_BASE_URL as string) || '';
  const ADMIN_KEY = (import.meta.env.VITE_ADMIN_KEY as string) || 'ecoadmin';

  async function fetchUserSubscription(uid: string) {
    try {
      const resp = await fetch(`${API_BASE}/api/admin/user-subscription/${encodeURIComponent(uid)}`, {
        headers: { 'X-Admin-Key': ADMIN_KEY },
      });
      const json = await resp.json();
      if (resp.ok && json.success) {
        setUserSubscription(json.subscription || null);
      } else if (resp.ok && json.subscription) {
        setUserSubscription(json.subscription);
      } else {
        setUserSubscription(null);
      }
    } catch (e) {
      setUserSubscription(null);
    }
  }

  async function fetchUserScans(uid: string) {
    try {
      setLoadingScans(true);
      const resp = await fetch(`${API_BASE}/api/admin/user-scans/${encodeURIComponent(uid)}`, {
        headers: { 'X-Admin-Key': ADMIN_KEY },
      });
      const json = await resp.json();
      if (resp.ok && json.success) {
        setUserScans(Array.isArray(json.scans) ? json.scans : []);
      } else {
        setUserScans([]);
      }
    } catch (e) {
      setUserScans([]);
    } finally {
      setLoadingScans(false);
    }
  }

  const handlePhotoChosen = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !selectedUser) return;
    if (!file.type.startsWith("image/")) {
      setPhotoError("Please choose an image file.");
      return;
    }
    setPhotoError(null);
    uploadPhotoMutation.mutate(
      { userId: selectedUser.id, file },
      {
        onSuccess: (data) => {
          setSelectedUser((prev) =>
            prev ? { ...prev, avatar: data.photoURL } : null,
          );
          if (fileInputRef.current) fileInputRef.current.value = "";
        },
        onError: (err) => setPhotoError(err.message),
      },
    );
  };

  return (
    <DashboardLayout title="User Management">
      <div className="font-['Poppins',sans-serif] bg-white rounded-lg border border-gray-200 shadow-sm">
        <div className="p-6">
          <UsersTable onView={handleView} />
        </div>
      </div>

      {/* User Detail Modal - You can create this similar to feedback detail modal */}
      {isViewModalOpen && selectedUser && (
        <div className="font-['Poppins',sans-serif] fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-lg rounded-[30px] overflow-hidden shadow-2xl">
            <div
              className="relative px-6 pb-14 pt-8"
              style={{
                backgroundImage: getPlanDetails(selectedUser.plan).gradient,
              }}
            >
              <div className="flex items-start justify-between gap-4">
                <p className="text-xs font-semibold uppercase tracking-[0.3em] text-white/85">
                  {getPlanDetails((userSubscription && userSubscription.planId) ? userSubscription.planId.toUpperCase() : selectedUser.plan).label} member
                </p>
                <button
                  onClick={() => {
                    setIsViewModalOpen(false);
                    setSelectedUser(null);
                  }}
                  className="text-white/85 transition hover:text-white"
                  aria-label="Close user details"
                >
                  ×
                </button>
              </div>
              <div className="absolute inset-x-0 bottom-0 flex justify-center">
                <div className="-mb-16 flex h-32 w-32 items-center justify-center rounded-full border-4 border-white bg-white shadow-xl">
                  {selectedUser.avatar ? (
                    <img
                      src={selectedUser.avatar}
                      alt={selectedUser.name}
                      className="h-28 w-28 rounded-full object-cover"
                    />
                  ) : (
                    <span className="text-4xl font-semibold text-gray-900">
                      {selectedUser.name
                        .split(" ")
                        .map((part) => part[0])
                        .join("")
                        .slice(0, 2)
                        .toUpperCase()}
                    </span>
                  )}
                </div>
              </div>
            </div>

            <div className="bg-white px-6 pb-6 pt-20">
              <div className="text-center">
                <h2 className="text-2xl font-semibold tracking-tight text-gray-900">
                  {selectedUser.name}
                </h2>
                <p className="mt-2 text-xs uppercase tracking-[0.24em] text-gray-400">
                  UID:{" "}
                  {selectedUser.id.startsWith("USR-")
                    ? selectedUser.id
                    : `USR-${selectedUser.id}`}
                </p>
              </div>

              <div className="space-y-4 mt-6">
                <div className="rounded-3xl border border-gray-200 bg-gray-50 px-4 py-4">
                  <p className="text-xs font-semibold uppercase tracking-[0.18em] text-gray-500">
                    Email
                  </p>
                  <p className="mt-2 text-sm font-semibold text-gray-900">
                    {selectedUser.email}
                  </p>
                </div>
                <div className="rounded-3xl border border-gray-200 bg-gray-50 px-4 py-4">
                  <p className="text-xs font-semibold uppercase tracking-[0.18em] text-gray-500">
                    Phone Number
                  </p>
                  <p className="mt-2 text-sm font-semibold text-gray-900">
                    {selectedUser.contactNumber}
                  </p>
                </div>
                <div className="rounded-3xl border border-gray-200 bg-gray-50 px-4 py-4">
                  <p className="text-xs font-semibold uppercase tracking-[0.18em] text-gray-500">
                    Biography
                  </p>
                  <p className="mt-2 text-sm text-gray-700">
                    {selectedUser.biography ?? "No biography available."}
                  </p>
                </div>
                <div className="rounded-3xl border border-gray-200 bg-gray-50 px-4 py-4">
                  <p className="text-xs font-semibold uppercase tracking-[0.18em] text-gray-500">
                    Location
                  </p>
                  <p className="mt-2 text-sm text-gray-700">
                    {selectedUser.location ?? "No location available."}
                  </p>
                </div>
              </div>

              <div className="mt-5">
                <div className="flex justify-end">
                  <button
                    type="button"
                    onClick={() => {
                      if (!selectedUser) return;
                      setIsScansModalOpen(true);
                      // fetch scans when opening the scans modal
                      fetchUserScans(selectedUser.id).catch(() => {});
                    }}
                    style={{
                      backgroundImage: getPlanDetails((userSubscription && userSubscription.planId) ? userSubscription.planId.toUpperCase() : selectedUser.plan).gradient,
                    }}
                    className="inline-flex items-center justify-center rounded-full px-5 py-3 text-sm font-semibold text-white transition disabled:opacity-50"
                  >
                    View Scan Logs
                  </button>
                </div>
                {/* Scan logs are shown in a separate modal opened by the button above */}
              </div>

              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handlePhotoChosen}
              />
              {photoError && (
                <p className="mt-3 text-sm text-red-500">{photoError}</p>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Scan Logs Modal */}
      {isScansModalOpen && selectedUser && (
        <div className="font-['Poppins',sans-serif] fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-2xl rounded-[20px] overflow-hidden shadow-2xl bg-white">
            <div
              className="flex items-center justify-between px-6 py-4"
              style={{
                backgroundImage: getPlanDetails((userSubscription && userSubscription.planId) ? userSubscription.planId.toUpperCase() : selectedUser.plan).gradient,
              }}
            >
              <h3 className="text-lg font-semibold text-white">Scan Logs — {selectedUser.name}</h3>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    if (selectedUser) fetchUserScans(selectedUser.id).catch(() => {});
                  }}
                  className="text-sm px-3 py-2 rounded bg-gray-100 hover:bg-gray-200"
                >
                  Refresh
                </button>
                <button
                  onClick={() => setIsScansModalOpen(false)}
                  className="text-xl px-3 py-1"
                  aria-label="Close scan logs"
                >
                  ×
                </button>
              </div>
            </div>
            <div className="p-6 max-h-[60vh] overflow-y-auto">
              {loadingScans && <p className="text-sm text-gray-600">Loading scans...</p>}
              {!loadingScans && userScans && userScans.length === 0 && (
                <p className="text-sm text-gray-600">No scans available for this user.</p>
              )}
              {!loadingScans && userScans && userScans.length > 0 && (
                <div className="space-y-3">
                  {userScans.map((s: any, idx: number) => (
                    <div key={s.id || s.scanId || s.scan_id || idx} className="flex items-center gap-3 rounded-xl border border-gray-100 bg-white p-3">
                      <img src={s.imageUrl || s.image || s.image_url || ''} alt="scan" className="w-20 h-14 object-cover rounded" />
                      <div className="flex-1">
                        <div className="text-sm font-semibold text-gray-900">{s.title || s.analysisResult || s.analysis || 'Soil scan'}</div>
                        <div className="text-xs text-gray-500">{s.timestamp || s.dateCaptured || s.created_at || ''}</div>
                        <div className="text-xs text-gray-600 mt-1">{(s.location || s.locationCoords) ? (s.location || `${s.locationCoords?.latitude}, ${s.locationCoords?.longitude}`) : ''}</div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </DashboardLayout>
  );
}
