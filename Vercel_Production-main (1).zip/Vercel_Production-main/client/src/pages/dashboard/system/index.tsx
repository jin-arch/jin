import { Upload, RotateCw } from "lucide-react";
import { DashboardLayout } from "@/components/templates/dashboard-layout/dashboard-layout";
import { Button } from "@/components/atoms/button/button";
import { useDashboard } from "@/hooks/use-dashboard";
import { useUploadHistory } from "@/hooks/use-system-config";

export function SystemConfigurationPage() {
  const { data: dashboardData, isLoading: isDashboardLoading } = useDashboard();
  const { data: uploadHistory = [], isLoading: isHistoryLoading } =
    useUploadHistory();

  if (isDashboardLoading) {
    return (
      <DashboardLayout title="Model Performance">
        <div className="flex items-center justify-center h-64">
          <p className="text-gray-500">Loading model performance...</p>
        </div>
      </DashboardLayout>
    );
  }

  const trainingDatasetSize = dashboardData?.trainingDatasetSize ?? 0;
  const modelVersion = dashboardData?.modelVersion ?? "N/A";
  const accuracy = dashboardData?.accuracy ?? 0;
  const status = dashboardData?.status ?? {
    label: "PENDING",
    description: "No entries available to be validated.",
    count: 0,
  };

  return (
    <DashboardLayout
      title="Model Performance"
      subtitle="Overview of AI model training and re-training."
    >
      <div className="space-y-6">
        {/* Metrics Cards Row */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Training Dataset Size */}
          <div className="bg-white rounded-lg border border-gray-200 p-6 shadow-sm">
            <h3 className="text-sm font-medium text-gray-600 uppercase tracking-wide mb-2">
              Training Dataset Size
            </h3>
            <p className="text-5xl font-bold text-gray-900">
              {trainingDatasetSize.toLocaleString()}
            </p>
            <p className="text-sm text-gray-600 mt-1">Samples</p>
          </div>

          {/* Model Version & Accuracy - Stacked */}
          <div className="space-y-4">
            <div className="bg-white rounded-lg border border-gray-200 p-6 shadow-sm">
              <h3 className="text-sm font-medium text-gray-600 uppercase tracking-wide mb-2">
                Model Version
              </h3>
              <p className="text-3xl font-bold text-gray-900">{modelVersion}</p>
            </div>
            <div className="bg-white rounded-lg border border-gray-200 p-6 shadow-sm">
              <h3 className="text-sm font-medium text-gray-600 uppercase tracking-wide mb-2">
                Accuracy
              </h3>
              <p className="text-3xl font-bold text-gray-900">{accuracy}%</p>
            </div>
          </div>

          {/* Status */}
          <div className="bg-white rounded-lg border border-gray-200 p-6 shadow-sm flex flex-col">
            <h3 className="text-sm font-medium text-gray-600 uppercase tracking-wide mb-2">
              Status
            </h3>
            <p className="text-3xl font-bold text-amber-500 mb-2">
              {status.label}
            </p>
            <p className="text-sm text-gray-500 mb-4 flex-1">
              {status.description}
            </p>
            <Button
              onClick={() => console.log("Validate clicked")}
              className="bg-amber-500 hover:bg-amber-600 text-white font-semibold px-4 py-2 rounded-lg w-fit"
            >
              VALIDATE
            </Button>
          </div>
        </div>

        {/* Bottom Section - Upload History & Upload New Dataset */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Upload History */}
          <div className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
            <div className="p-4 border-b border-gray-200">
              <h3 className="text-sm font-bold text-gray-900 uppercase tracking-wide">
                Upload History
              </h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="bg-gray-50 border-b border-gray-200">
                    <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">
                      Name
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">
                      Type
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">
                      Uploaded By
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">
                      Date
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">
                      Size
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {isHistoryLoading ? (
                    <tr>
                      <td
                        colSpan={5}
                        className="px-4 py-8 text-center text-gray-500"
                      >
                        Loading upload history...
                      </td>
                    </tr>
                  ) : uploadHistory.length === 0 ? (
                    <tr>
                      <td
                        colSpan={5}
                        className="px-4 py-8 text-center text-gray-500"
                      >
                        No upload history yet
                      </td>
                    </tr>
                  ) : (
                    uploadHistory.map((item) => (
                      <tr
                        key={item.id}
                        className="border-b border-gray-100 hover:bg-gray-50"
                      >
                        <td className="px-4 py-3 text-sm text-gray-900">
                          {item.name}
                        </td>
                        <td className="px-4 py-3 text-sm text-gray-600">
                          {item.type}
                        </td>
                        <td className="px-4 py-3 text-sm text-gray-600">
                          {item.uploadedBy}
                        </td>
                        <td className="px-4 py-3 text-sm text-gray-600">
                          {item.date}
                        </td>
                        <td className="px-4 py-3 text-sm text-gray-600">
                          {item.size}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Upload New Dataset for Retraining */}
          <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-6">
            <h3 className="text-sm font-bold text-gray-900 uppercase tracking-wide mb-6">
              Upload New Dataset for Retraining
            </h3>
            <div className="space-y-3">
              <Button
                onClick={() => console.log("Upload dataset clicked")}
                className="w-full bg-[#A0C878] hover:bg-[#8FB868] text-white font-semibold px-4 py-3 rounded-lg flex items-center justify-center gap-2"
              >
                <Upload className="w-4 h-4" />
                UPLOAD DATASET
              </Button>
              <Button
                onClick={() => console.log("Sync and retrain clicked")}
                className="w-full bg-[#A0C878] hover:bg-[#8FB868] text-white font-semibold px-4 py-3 rounded-lg flex items-center justify-center gap-2"
              >
                <RotateCw className="w-4 h-4" />
                SYNC AND RETRAIN
              </Button>
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
