import { useState } from "react";
import { DashboardLayout } from "@/components/templates/dashboard-layout/dashboard-layout";
import { DataEntryCard } from "@/components/organisms/data-entry-card/data-entry-card";
import { DataEntryDetailModal } from "@/components/organisms/data-entry-detail-modal/data-entry-detail-modal";
import { useAdminScans } from "@/hooks/use-admin-scans";

export function DataManagementPage() {
  const { data: entries, isLoading, error } = useAdminScans();
  const [selectedEntry, setSelectedEntry] = useState<any>(null);

  return (
    <DashboardLayout
      title="Data Management"
      subtitle="Overview of user entries, photos or images captured are stored here."
      mainClassName="p-4 md:p-5 bg-white"
    >
      {isLoading && (
        <div className="space-y-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="p-4 rounded-lg bg-white border border-gray-100 shadow animate-pulse">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 bg-gray-100 rounded" />
                <div className="flex-1">
                  <div className="h-4 w-1/3 bg-gray-100 rounded mb-2" />
                  <div className="h-3 w-1/2 bg-gray-100 rounded" />
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {error && (
        <div className="flex items-center justify-center min-h-[240px]">
          <p className="text-red-600">
            Could not load data entries. Please try again.
          </p>
        </div>
      )}


      {!isLoading && !error && entries && (
        <div className="space-y-3">
          {entries.length === 0 ? (
            <p className="text-center text-gray-500 py-16">No entries yet.</p>
          ) : (
            entries.map((entry: any) => (
              <DataEntryCard
                key={entry.id || entry.filename || entry.timestamp}
                entry={entry}
                onView={(e) => setSelectedEntry(e)}
              />
            ))
          )}
        </div>
      )}

      <DataEntryDetailModal
        entry={selectedEntry}
        isOpen={selectedEntry !== null}
        onClose={() => setSelectedEntry(null)}
      />
    </DashboardLayout>
  );
}
