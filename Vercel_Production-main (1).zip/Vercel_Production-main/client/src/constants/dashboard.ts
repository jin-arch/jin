// Mock dashboard data
export const MOCK_DASHBOARD_DATA = {
  users: 5,
  scans: 1217,
  modelVersion: "v1.0.1",
  accuracy: 91.4,
  status: {
    label: "PENDING",
    description: "2 soils entries are available to be validated.",
    count: 2,
  },
  scansPerDay: [
    { day: "Mon", value: 96 },
    { day: "Tue", value: 54 },
    { day: "Wed", value: 132 },
    { day: "Thu", value: 148 },
    { day: "Fri", value: 92 },
    { day: "Sat", value: 176 },
    { day: "Sun", value: 120 },
  ],
  cropsDatabase: 2,
  datasetContents: {
    crop: {
      entries: 587,
      percentage: 19.46,
    },
    soil: {
      entries: 2430,
      percentage: 80.54,
    },
  },
  trainingDatasetSize: 3017,
  feedbacks: 2,
} as const;

// Mock user data
export const MOCK_USER = {
  name: "Fiona Mae Apor",
  role: "ADMIN",
  avatar: "/api/placeholder/avatar", // You can replace with actual avatar URL
} as const;
