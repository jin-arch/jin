// Mock feedback data
export interface Feedback {
  id: string;
  // Optional fields coming from server
  userId?: string;
  userName?: string;
  // created_at used by server, keep timestamp for older mock data
  created_at?: string;
  timestamp?: string;
  // title (server) or subject (client mock) for headline
  title?: string;
  subject?: string;
  // the main message body (server uses `message`)
  message?: string;
  // optional numeric rating 1-5
  rating?: number;
  // raw metadata if present
  metadata?: Record<string, unknown> | string;
}

export const MOCK_FEEDBACKS: Feedback[] = [
  {
    id: "1",
    userName: "Jerald Monroid",
    timestamp: "Oct 20, 2025 - 1:18AM",
    subject: "Accuracy issue for soil analyzation",
    message:
      "Improve your soil analyzation, and expand your dataset for better accuracy.",
  },
  {
    id: "2",
    userName: "Rogin Galford",
    timestamp: "Oct 9, 2025 - 7:18AM",
    subject: "Feature request for crop management",
    message:
      "It would be great to have more detailed analytics for crop growth patterns and seasonal variations.",
  },
  {
    id: "3",
    userName: "Maria Santos",
    timestamp: "Oct 15, 2025 - 3:45PM",
    subject: "Bug report in dataset export",
    message:
      "When exporting the dataset, some entries are missing. Please fix this issue as it affects data integrity.",
  },
  {
    id: "4",
    userName: "John Anderson",
    timestamp: "Oct 12, 2025 - 10:30AM",
    subject: "Request for mobile app",
    message:
      "The platform works great on desktop, but we need a mobile application for field workers to input data on the go.",
  },
  {
    id: "5",
    userName: "Sarah Chen",
    timestamp: "Oct 8, 2025 - 2:15PM",
    subject: "Improvement suggestion for user interface",
    message:
      "The dashboard is functional but could benefit from better color contrast and larger font sizes for better readability.",
  },
  {
    id: "6",
    userName: "Michael Brown",
    timestamp: "Oct 5, 2025 - 9:20AM",
    subject: "Data visualization enhancement",
    message:
      "Can you add more chart types? Specifically, I'd like to see line graphs for tracking trends over time.",
  },
  {
    id: "7",
    userName: "Emily Davis",
    timestamp: "Oct 3, 2025 - 4:50PM",
    subject: "Performance optimization needed",
    message:
      "The system becomes slow when processing large datasets. Consider implementing pagination or lazy loading for better performance.",
  },
  {
    id: "8",
    userName: "David Wilson",
    timestamp: "Oct 1, 2025 - 11:10AM",
    subject: "Export format options",
    message:
      "Currently, we can only export to CSV. It would be helpful to have options for Excel, JSON, and PDF formats as well.",
  },
  {
    id: "9",
    userName: "Lisa Martinez",
    timestamp: "Sep 28, 2025 - 6:30PM",
    subject: "User permission system",
    message:
      "We need more granular permission controls. Different team members should have different access levels based on their roles.",
  },
  {
    id: "10",
    userName: "Robert Taylor",
    timestamp: "Sep 25, 2025 - 8:45AM",
    subject: "Integration with external APIs",
    message:
      "It would be beneficial to integrate with weather APIs and soil sensor data providers for more comprehensive analysis.",
  },
  {
    id: "11",
    userName: "Jennifer Lee",
    timestamp: "Sep 22, 2025 - 3:15PM",
    subject: "Notification system improvement",
    message:
      "The notification system needs improvement. Users should receive alerts when their soil analysis is complete or when there are system updates.",
  },
  {
    id: "12",
    userName: "James White",
    timestamp: "Sep 20, 2025 - 10:00AM",
    subject: "Search functionality enhancement",
    message:
      "The search feature works well but could be enhanced with filters for date range, status, and soil type to make finding specific records easier.",
  },
  {
    id: "13",
    userName: "Patricia Garcia",
    timestamp: "Sep 18, 2025 - 5:30PM",
    subject: "Batch upload feature request",
    message:
      "Currently, we can only upload one soil sample at a time. A batch upload feature would significantly speed up our workflow when processing multiple samples.",
  },
  {
    id: "14",
    userName: "William Rodriguez",
    timestamp: "Sep 15, 2025 - 2:20PM",
    subject: "Report generation feature",
    message:
      "It would be great to have an automated report generation feature that creates PDF reports with analysis results, charts, and recommendations.",
  },
  {
    id: "15",
    userName: "Linda Martinez",
    timestamp: "Sep 12, 2025 - 11:45AM",
    subject: "Data backup and recovery",
    message:
      "We need assurance that our data is being backed up regularly. Please implement a data backup and recovery system to prevent data loss.",
  },
  {
    id: "16",
    userName: "Richard Johnson",
    timestamp: "Sep 10, 2025 - 4:10PM",
    subject: "User activity logging",
    message:
      "For security and audit purposes, it would be helpful to have a log of all user activities, including who accessed what data and when.",
  },
  {
    id: "17",
    userName: "Barbara Williams",
    timestamp: "Sep 8, 2025 - 9:30AM",
    subject: "Multi-language support",
    message:
      "Our team includes members who speak different languages. Adding multi-language support would make the platform more accessible to everyone.",
  },
  {
    id: "18",
    userName: "Thomas Anderson",
    timestamp: "Sep 5, 2025 - 1:50PM",
    subject: "API documentation",
    message:
      "If there's an API available, please provide comprehensive documentation. This would help us integrate the system with our existing tools.",
  },
  {
    id: "19",
    userName: "Susan Jackson",
    timestamp: "Sep 3, 2025 - 7:25AM",
    subject: "Training materials and tutorials",
    message:
      "New users find it difficult to get started. Adding video tutorials and comprehensive documentation would help onboard new team members faster.",
  },
  {
    id: "20",
    userName: "Daniel Kim",
    timestamp: "Sep 1, 2025 - 12:00PM",
    subject: "Performance monitoring dashboard",
    message:
      "It would be useful to have a dashboard that shows system performance metrics, including response times, error rates, and data processing statistics.",
  },
];

export const SAMPLE_FEEDBACKS: Feedback[] = [
  {
    id: "sample-1",
    userName: "Amina Yusuf",
    timestamp: "Nov 5, 2025 - 9:10AM",
    subject: "Soil moisture chart request",
    message:
      "Please add a soil moisture chart that shows trend lines over time for each plot. It will help us react faster to dry conditions.",
  },
  {
    id: "sample-2",
    userName: "Carlos Rivera",
    timestamp: "Nov 3, 2025 - 4:25PM",
    subject: "Notification preferences",
    message:
      "I would love to receive alerts only for critical soil issues, not every minor change. A settings panel would be helpful.",
  },
  {
    id: "sample-3",
    userName: "Priya Singh",
    timestamp: "Nov 1, 2025 - 11:00AM",
    subject: "Data export enhancement",
    message:
      "Please add a direct export to PDF option with summary charts and key metrics for our weekly reports.",
  },
  {
    id: "sample-4",
    userName: "Nina Alvarez",
    timestamp: "Oct 29, 2025 - 2:40PM",
    subject: "Dashboard accessibility",
    message:
      "The interface looks nice, but a larger font option and stronger contrast would make it easier for field agents to read.",
  },
  {
    id: "sample-5",
    userName: "Owen Brooks",
    timestamp: "Oct 27, 2025 - 8:55AM",
    subject: "Mobile friendly layout",
    message:
      "Can you improve the mobile layout so the dashboard can be used on tablets and phones without horizontal scrolling?",
  },
];
