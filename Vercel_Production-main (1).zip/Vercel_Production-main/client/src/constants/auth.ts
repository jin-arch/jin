// Mock authentication data (only enabled when `VITE_ENABLE_MOCK_AUTH=true` in dev)
const enableMock = import.meta.env.DEV && (import.meta.env.VITE_ENABLE_MOCK_AUTH === 'true');

export const API_ENDPOINTS = {
  LOGIN: "/api/auth/login",
  LOGOUT: "/api/auth/logout",
  REFRESH: "/api/auth/refresh",
} as const;

// Provide a safe, env-driven mock for local development only.
// DO NOT commit real credentials. Use VITE_MOCK_ADMIN_USERNAME/VITE_MOCK_ADMIN_TOKEN if needed.
export const MOCK_USERS = enableMock
  ? {
      admin1: {
        username: import.meta.env.VITE_MOCK_ADMIN_USERNAME || 'admin1',
        // Use an environment variable for the password in dev; default is a placeholder.
        password: import.meta.env.VITE_MOCK_ADMIN_PASSWORD || 'dev-placeholder',
        token: import.meta.env.VITE_MOCK_ADMIN_TOKEN || 'mock-jwt-token-admin-12345',
        user: {
          id: import.meta.env.VITE_MOCK_ADMIN_ID || '1',
          username: import.meta.env.VITE_MOCK_ADMIN_USERNAME || 'admin1',
          email: import.meta.env.VITE_MOCK_ADMIN_EMAIL || 'admin1@local',
          role: 'admin',
        },
      },
    }
  : {} as const;
