/** Local soil texture photo — served from `public/soil-scan-placeholder.png`. */
export const SOIL_PLACEHOLDER_IMAGE = "/soil-scan-placeholder.png";

export type DataEntryStatus = "ACTIVE" | "PENDING" | "ARCHIVED";

/** Soil analysis shown in the scan detail modal (matches dashboard soil UX). */
export interface SoilScanAnalysis {
  healthLevel: string;
  scoreDisplay: string;
  soilTexture: string;
  textureSuitability: string;
  soilColor: string;
  soilColorNote: string;
}

export interface DataEntry {
  id: string;
  scanId: string;
  userId: string;
  dateCaptured: string;
  location: string;
  status: DataEntryStatus;
  imageUrl?: string;
  analysis: SoilScanAnalysis;
  // Optional lightweight user profile for admin cards
  userProfile?: {
    contactNumber?: string | null;
    biography?: string | null;
    location?: string | null;
  };
}

export const MOCK_DATA_ENTRIES: DataEntry[] = [
  {
    id: "de-001",
    scanId: "ECF-000-101",
    userId: "USR-000-100",
    dateCaptured: "4/3/2026",
    location: "TapTap, Cebu City, Cebu",
    status: "ACTIVE",
    imageUrl: SOIL_PLACEHOLDER_IMAGE,
    analysis: {
      healthLevel: "Fair",
      scoreDisplay: "56",
      soilTexture: "Loam",
      textureSuitability: "Suitability: 92%",
      soilColor: "Light Brown",
      soilColorNote: "Low organic matter (1-2%), limited fertility",
    },
  },
  {
    id: "de-002",
    scanId: "ECF-000-102",
    userId: "USR-000-101",
    dateCaptured: "4/2/2026",
    location: "Lahug, Cebu City, Cebu",
    status: "ACTIVE",
    imageUrl: SOIL_PLACEHOLDER_IMAGE,
    analysis: {
      healthLevel: "Good",
      scoreDisplay: "72",
      soilTexture: "Clay loam",
      textureSuitability: "Suitability: 88%",
      soilColor: "Dark brown",
      soilColorNote: "Moderate organic matter (3-4%), good water retention",
    },
  },
  {
    id: "de-003",
    scanId: "ECF-000-103",
    userId: "USR-000-102",
    dateCaptured: "4/1/2026",
    location: "Mandaue City, Cebu",
    status: "PENDING",
    imageUrl: SOIL_PLACEHOLDER_IMAGE,
    analysis: {
      healthLevel: "Poor",
      scoreDisplay: "38",
      soilTexture: "Sandy",
      textureSuitability: "Suitability: 61%",
      soilColor: "Pale tan",
      soilColorNote: "Very low organic matter, prone to drought stress",
    },
  },
  {
    id: "de-004",
    scanId: "ECF-000-104",
    userId: "USR-000-100",
    dateCaptured: "3/30/2026",
    location: "Talamban, Cebu City, Cebu",
    status: "ACTIVE",
    imageUrl: SOIL_PLACEHOLDER_IMAGE,
    analysis: {
      healthLevel: "Fair",
      scoreDisplay: "56",
      soilTexture: "Loam",
      textureSuitability: "Suitability: 92%",
      soilColor: "Light Brown",
      soilColorNote: "Low organic matter (1-2%), limited fertility",
    },
  },
  {
    id: "de-005",
    scanId: "ECF-000-105",
    userId: "USR-000-103",
    dateCaptured: "3/28/2026",
    location: "Consolacion, Cebu",
    status: "ARCHIVED",
    imageUrl: SOIL_PLACEHOLDER_IMAGE,
    analysis: {
      healthLevel: "Excellent",
      scoreDisplay: "91",
      soilTexture: "Silty loam",
      textureSuitability: "Suitability: 96%",
      soilColor: "Rich brown",
      soilColorNote: "High organic matter (5%+), excellent structure",
    },
  },
];
