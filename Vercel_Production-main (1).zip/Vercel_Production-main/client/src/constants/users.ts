// User data types and constants
export type UserStatus = "ACTIVE" | "OFFLINE";
export type UserPlan = "BASIC" | "STANDARD" | "PRO" | "ENTERPRISE";

export interface User {
  id: string;
  name: string;
  email: string;
  contactNumber: string;
  joinedAt: string; // Format: "M/D/YYYY"
  status: UserStatus;
  plan?: UserPlan;
  biography?: string;
  location?: string;
  avatar?: string; // URL or path to avatar image
}

export const MOCK_USERS: User[] = [
  {
    id: "1",
    name: "Jerald Monroid",
    email: "jeraldmonroid@example.com",
    contactNumber: "+63815341432",
    joinedAt: "9/29/2025",
    status: "ACTIVE",
    plan: "PRO",
  },
  {
    id: "2",
    name: "Mikel Aboyme",
    email: "mikelboang@example.com",
    contactNumber: "+63815133213",
    joinedAt: "9/27/2025",
    status: "OFFLINE",
  },
  {
    id: "3",
    name: "Leonard Tariman",
    email: "yunardbatumbak@example.com",
    contactNumber: "+63832132332",
    joinedAt: "9/21/2025",
    status: "ACTIVE",
  },
  {
    id: "4",
    name: "Cindy Cinco",
    email: "cindymyloves@example.com",
    contactNumber: "+6383213432",
    joinedAt: "9/25/2025",
    status: "ACTIVE",
  },
  {
    id: "5",
    name: "Rogin Galford",
    email: "rogingwapo123@example.com",
    contactNumber: "+63832134322",
    joinedAt: "9/7/2025",
    status: "ACTIVE",
  },
  {
    id: "6",
    name: "Maria Santos",
    email: "mariasantos@example.com",
    contactNumber: "+639123456789",
    joinedAt: "9/20/2025",
    status: "ACTIVE",
  },
  {
    id: "7",
    name: "John Anderson",
    email: "johnanderson@example.com",
    contactNumber: "+639234567890",
    joinedAt: "9/18/2025",
    status: "ACTIVE",
  },
  {
    id: "8",
    name: "Sarah Chen",
    email: "sarahchen@example.com",
    contactNumber: "+639345678901",
    joinedAt: "9/15/2025",
    status: "OFFLINE",
  },
  {
    id: "9",
    name: "Michael Brown",
    email: "michaelbrown@example.com",
    contactNumber: "+639456789012",
    joinedAt: "9/12/2025",
    status: "ACTIVE",
  },
  {
    id: "10",
    name: "Emily Davis",
    email: "emilydavis@example.com",
    contactNumber: "+639567890123",
    joinedAt: "9/10/2025",
    status: "ACTIVE",
  },
  {
    id: "11",
    name: "David Wilson",
    email: "davidwilson@example.com",
    contactNumber: "+639678901234",
    joinedAt: "9/8/2025",
    status: "OFFLINE",
  },
  {
    id: "12",
    name: "Lisa Martinez",
    email: "lisamartinez@example.com",
    contactNumber: "+639789012345",
    joinedAt: "9/5/2025",
    status: "ACTIVE",
  },
  {
    id: "13",
    name: "Robert Taylor",
    email: "roberttaylor@example.com",
    contactNumber: "+639890123456",
    joinedAt: "9/3/2025",
    status: "ACTIVE",
  },
  {
    id: "14",
    name: "Jennifer Lee",
    email: "jenniferlee@example.com",
    contactNumber: "+639901234567",
    joinedAt: "9/1/2025",
    status: "ACTIVE",
  },
  {
    id: "15",
    name: "James White",
    email: "jameswhite@example.com",
    contactNumber: "+639012345678",
    joinedAt: "8/28/2025",
    status: "OFFLINE",
  },
  {
    id: "16",
    name: "Patricia Garcia",
    email: "patriciagarcia@example.com",
    contactNumber: "+639123456780",
    joinedAt: "8/25/2025",
    status: "ACTIVE",
  },
  {
    id: "17",
    name: "William Rodriguez",
    email: "williamrodriguez@example.com",
    contactNumber: "+639234567801",
    joinedAt: "8/22/2025",
    status: "ACTIVE",
  },
  {
    id: "18",
    name: "Linda Martinez",
    email: "lindamartinez@example.com",
    contactNumber: "+639345678012",
    joinedAt: "8/20/2025",
    status: "OFFLINE",
  },
  {
    id: "19",
    name: "Richard Johnson",
    email: "richardjohnson@example.com",
    contactNumber: "+639456789023",
    joinedAt: "8/18/2025",
    status: "ACTIVE",
  },
  {
    id: "20",
    name: "Barbara Williams",
    email: "barbarawilliams@example.com",
    contactNumber: "+639567890134",
    joinedAt: "8/15/2025",
    status: "ACTIVE",
  },
];
