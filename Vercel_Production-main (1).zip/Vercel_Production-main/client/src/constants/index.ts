// App constants
export const APP_NAME = "ECOFARMAI";

export const PAGINATION_PAGE_SIZE = 10;
