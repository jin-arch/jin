// Soil data types and constants
import soilSample1 from "@/assets/images/soil-sample-1.png";
import soilSample2 from "@/assets/images/soil-sample-2.png";

export type SoilVerificationMethod = "AUTO ANALYZED" | "ADMIN VERIFIED";
export type SoilSuitability = "SUITABLE" | "NEEDS_IMPROVEMENT";

export interface Soil {
  id: string; // e.g., "SL-001"
  imageUrl?: string; // Path to image in assets (base64 or URL)
  uploadedBy: string;
  location?: string;
  dateCreated: string; // Format: "M/D/YYYY"
  suitabilityScore: number; // 0-100 percentage
  tags: string[]; // e.g., ["#DarkBrown", "#Loamy"]
  status: "VALIDATED" | "PENDING" | "REJECTED";
  verificationMethod: SoilVerificationMethod;
  soilColor?: string;
  soilTexture?: string;
  suitability?: SoilSuitability;
  recommendations?: string;
}

export const MOCK_SOILS: Soil[] = [
  {
    id: "SL-001",
    imageUrl: soilSample1,
    uploadedBy: "Jerald Monroid",
    dateCreated: "9/7/2025",
    suitabilityScore: 87,
    tags: ["#DarkBrown", "#Loamy"],
    status: "VALIDATED",
    verificationMethod: "AUTO ANALYZED",
  },
  {
    id: "SL-002",
    imageUrl: soilSample2,
    uploadedBy: "Jerald Monroid",
    dateCreated: "9/7/2025",
    suitabilityScore: 23,
    tags: ["#LightBrown", "#Clay"],
    status: "VALIDATED",
    verificationMethod: "ADMIN VERIFIED",
  },
  {
    id: "SL-003",
    uploadedBy: "Rogin Galford",
    dateCreated: "9/6/2025",
    suitabilityScore: 65,
    tags: ["#Brown", "#Sandy"],
    status: "PENDING",
    verificationMethod: "AUTO ANALYZED",
  },
  {
    id: "SL-004",
    uploadedBy: "Cindy Cinco",
    dateCreated: "9/5/2025",
    suitabilityScore: 92,
    tags: ["#DarkBrown", "#Loamy", "#Organic"],
    status: "VALIDATED",
    verificationMethod: "ADMIN VERIFIED",
  },
  {
    id: "SL-005",
    uploadedBy: "Leonard Tariman",
    dateCreated: "9/4/2025",
    suitabilityScore: 45,
    tags: ["#LightBrown", "#Clay"],
    status: "VALIDATED",
    verificationMethod: "AUTO ANALYZED",
  },
  {
    id: "SL-006",
    uploadedBy: "Maria Santos",
    dateCreated: "9/3/2025",
    suitabilityScore: 78,
    tags: ["#DarkBrown", "#Loamy"],
    status: "VALIDATED",
    verificationMethod: "AUTO ANALYZED",
  },
  {
    id: "SL-007",
    uploadedBy: "John Anderson",
    dateCreated: "9/2/2025",
    suitabilityScore: 56,
    tags: ["#Brown", "#Sandy", "#Dry"],
    status: "VALIDATED",
    verificationMethod: "ADMIN VERIFIED",
  },
  {
    id: "SL-008",
    uploadedBy: "Sarah Chen",
    dateCreated: "9/1/2025",
    suitabilityScore: 34,
    tags: ["#LightBrown", "#Clay"],
    status: "PENDING",
    verificationMethod: "AUTO ANALYZED",
  },
  {
    id: "SL-009",
    uploadedBy: "Michael Brown",
    dateCreated: "8/31/2025",
    suitabilityScore: 89,
    tags: ["#DarkBrown", "#Loamy", "#Rich"],
    status: "VALIDATED",
    verificationMethod: "ADMIN VERIFIED",
  },
  {
    id: "SL-010",
    uploadedBy: "Emily Davis",
    dateCreated: "8/30/2025",
    suitabilityScore: 42,
    tags: ["#Brown", "#Sandy"],
    status: "VALIDATED",
    verificationMethod: "AUTO ANALYZED",
  },
  {
    id: "SL-011",
    uploadedBy: "David Wilson",
    dateCreated: "8/29/2025",
    suitabilityScore: 71,
    tags: ["#DarkBrown", "#Loamy", "#Moist"],
    status: "VALIDATED",
    verificationMethod: "AUTO ANALYZED",
  },
  {
    id: "SL-012",
    uploadedBy: "Lisa Martinez",
    dateCreated: "8/28/2025",
    suitabilityScore: 63,
    tags: ["#LightBrown", "#Clay"],
    status: "PENDING",
    verificationMethod: "AUTO ANALYZED",
  },
  {
    id: "SL-013",
    uploadedBy: "Robert Taylor",
    dateCreated: "8/27/2025",
    suitabilityScore: 95,
    tags: ["#DarkBrown", "#Loamy", "#Organic", "#Rich"],
    status: "VALIDATED",
    verificationMethod: "ADMIN VERIFIED",
  },
  {
    id: "SL-014",
    uploadedBy: "Jennifer Lee",
    dateCreated: "8/26/2025",
    suitabilityScore: 38,
    tags: ["#Brown", "#Sandy", "#Dry"],
    status: "VALIDATED",
    verificationMethod: "AUTO ANALYZED",
  },
  {
    id: "SL-015",
    uploadedBy: "James White",
    dateCreated: "8/25/2025",
    suitabilityScore: 82,
    tags: ["#DarkBrown", "#Loamy"],
    status: "VALIDATED",
    verificationMethod: "ADMIN VERIFIED",
  },
  {
    id: "SL-016",
    uploadedBy: "Patricia Garcia",
    dateCreated: "8/24/2025",
    suitabilityScore: 59,
    tags: ["#LightBrown", "#Clay"],
    status: "VALIDATED",
    verificationMethod: "AUTO ANALYZED",
  },
  {
    id: "SL-017",
    uploadedBy: "William Rodriguez",
    dateCreated: "8/23/2025",
    suitabilityScore: 76,
    tags: ["#Brown", "#Sandy"],
    status: "VALIDATED",
    verificationMethod: "AUTO ANALYZED",
  },
  {
    id: "SL-018",
    uploadedBy: "Linda Martinez",
    dateCreated: "8/22/2025",
    suitabilityScore: 48,
    tags: ["#LightBrown", "#Clay", "#Dry"],
    status: "PENDING",
    verificationMethod: "AUTO ANALYZED",
  },
  {
    id: "SL-019",
    uploadedBy: "Richard Johnson",
    dateCreated: "8/21/2025",
    suitabilityScore: 91,
    tags: ["#DarkBrown", "#Loamy", "#Organic"],
    status: "VALIDATED",
    verificationMethod: "ADMIN VERIFIED",
  },
  {
    id: "SL-020",
    uploadedBy: "Barbara Williams",
    dateCreated: "8/20/2025",
    suitabilityScore: 67,
    tags: ["#Brown", "#Sandy", "#Moist"],
    status: "VALIDATED",
    verificationMethod: "AUTO ANALYZED",
  },
];
