export interface UploadHistoryItem {
  id: string;
  name: string;
  type: "Crop" | "Soil" | "Dataset";
  uploadedBy: string;
  date: string;
  size: string;
}

export const MOCK_UPLOAD_HISTORY: UploadHistoryItem[] = [
  {
    id: "1",
    name: "Test1",
    type: "Crop",
    uploadedBy: "Fiona May Apor",
    date: "9/7/2025",
    size: "708.7MB",
  },
  {
    id: "2",
    name: "Soil Dataset Q3",
    type: "Soil",
    uploadedBy: "Jerald Monroid",
    date: "9/6/2025",
    size: "1.2GB",
  },
  {
    id: "3",
    name: "Crop Samples 2025",
    type: "Crop",
    uploadedBy: "Maria Garcia",
    date: "9/5/2025",
    size: "450.3MB",
  },
];
