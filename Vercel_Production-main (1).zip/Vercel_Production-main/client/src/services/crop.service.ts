import type { Crop } from "@/constants/crops";
import { apiDelete, apiGet, apiPost } from "./api";

export async function getCrops(): Promise<Crop[]> {
  return apiGet<Crop[]>("/api/web/crops");
}

export async function getCropById(id: string): Promise<Crop | null> {
  return apiGet<Crop>(`/api/web/crops/${id}`);
}

export async function deleteCrop(id: string): Promise<void> {
  await apiDelete(`/api/web/crops/${id}`);
}

export async function createCrop(
  cropData: Omit<Crop, "id" | "dateCreated" | "status" | "verificationMethod">
): Promise<Crop> {
  return apiPost<Crop>("/api/web/crops", cropData);
}
