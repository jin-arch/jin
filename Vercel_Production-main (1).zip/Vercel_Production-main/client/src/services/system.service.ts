import type { UploadHistoryItem } from "@/constants/system";
import { apiGet } from "./api";

export async function getUploadHistory(): Promise<UploadHistoryItem[]> {
  return apiGet<UploadHistoryItem[]>("/api/web/system/upload-history");
}
