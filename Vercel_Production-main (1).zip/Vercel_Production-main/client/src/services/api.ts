
// --- API BASE: Use Flask/Python backend in production, proxy in dev ---
function normalizeApiBase(raw: string): string {
  return raw.trim().replace(/\/$/, '')
}

const flaskBase = typeof import.meta.env.VITE_FLASK_API_BASE_URL === 'string' ? import.meta.env.VITE_FLASK_API_BASE_URL.trim() : '';
export const API_BASE_URL =
  flaskBase.length > 0
    ? normalizeApiBase(flaskBase)
    : import.meta.env.DEV
      ? ''
      : '';

if (!import.meta.env.DEV && flaskBase.length === 0) {
  console.warn('[EcoFarm] VITE_FLASK_API_BASE_URL is not set. API calls will fail until you set it to your Python/Flask backend URL.');
}

function getAuthHeaders(includeJson = true): HeadersInit {
  const token = localStorage.getItem('auth_token')
  const headers: HeadersInit = {}

  if (includeJson) {
    headers['Content-Type'] = 'application/json'
  }

  if (token) {
    headers['Authorization'] = `Bearer ${token}`
  }

  // Development convenience: send admin key from env as X-Admin-Key when present
  const envAdminKey = typeof import.meta.env.VITE_ADMIN_KEY === 'string' ? import.meta.env.VITE_ADMIN_KEY.trim() : '';
  if (envAdminKey) {
    headers['X-Admin-Key'] = envAdminKey;
  }

  return headers
}

async function parseResponse<T>(response: Response): Promise<T> {
  const data = await response.json().catch(() => null)

  if (!response.ok) {
    const message = data?.error || data?.message || `Request failed (${response.status})`
    throw new Error(message)
  }

  return data as T
}

export async function apiGet<T>(path: string): Promise<T> {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    method: 'GET',
    headers: getAuthHeaders(false),
  })

  return parseResponse<T>(response)
}

export async function apiPost<T>(path: string, body: unknown): Promise<T> {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    method: 'POST',
    headers: getAuthHeaders(true),
    body: JSON.stringify(body),
  })

  return parseResponse<T>(response)
}

export async function apiPut<T>(path: string, body: unknown): Promise<T> {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    method: 'PUT',
    headers: getAuthHeaders(true),
    body: JSON.stringify(body),
  })

  return parseResponse<T>(response)
}

export async function apiDelete(path: string): Promise<void> {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    method: 'DELETE',
    headers: getAuthHeaders(false),
  })

  if (!response.ok) {
    const data = await response.json().catch(() => null)
    const message = data?.error || data?.message || `Request failed (${response.status})`
    throw new Error(message)
  }
}
