// Delete feedback (if you implement DELETE in Python backend or want to keep the API consistent)
export async function deleteFeedback(id: string): Promise<void> {
  return apiDelete(`/api/web/feedbacks/${id}`);
}
import type { Feedback } from "@/constants/feedbacks";
import { apiDelete, apiGet, apiPost } from "./api";

// Fetch all feedbacks (if you implement GET in Python backend)
export async function getFeedbacks(): Promise<Feedback[]> {
  const res = await apiGet<any>("/api/web/feedbacks");
  // Server may return either an array or an object { feedbacks: [...] }
  const rawList: any[] = Array.isArray(res) ? res : (res?.feedbacks || []);

  // Normalize server feedback shape into client Feedback model
  const normalize = (f: any): Feedback => {
    const metadata = f.metadata ?? f.meta ?? null;
    const userId = f.userId || (metadata && metadata.userId) || undefined;
    const userName = f.userName || (metadata && (metadata.displayName || metadata.name)) || undefined;
    const created_at = f.created_at || f.createdAt || f.created || undefined;
    const message = f.message || f.msg || f.description || '';
    const title = f.title || f.subject || '';
    const rating = typeof f.rating === 'number' ? f.rating : (metadata && typeof metadata.rating === 'number' ? metadata.rating : undefined);

    return {
      id: f.id || f._id || `${title}-${Math.random().toString(36).slice(2, 9)}`,
      userId,
      userName,
      created_at,
      timestamp: created_at || f.timestamp || undefined,
      title,
      subject: f.subject || undefined,
      message,
      rating,
      metadata,
    } as Feedback;
  };

  return rawList.map(normalize);
}

// Submit feedback to Python backend
export async function submitFeedback(feedback: Partial<Feedback>): Promise<any> {
  return apiPost("/api/web/feedbacks", feedback);
}
