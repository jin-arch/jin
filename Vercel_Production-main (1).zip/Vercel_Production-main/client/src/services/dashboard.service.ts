import { apiGet } from "./api";

// Types
export interface DashboardData {
  users: number;
  scans?: number;
  modelVersion: string;
  accuracy: number;
  status: {
    label: string;
    description: string;
    count: number;
  };
  scansPerDay?: Array<{
    day: string;
    value: number;
  }>;
  cropsDatabase: number;
  datasetContents: {
    crop: {
      entries: number;
      percentage: number;
    };
    soil: {
      entries: number;
      percentage: number;
    };
  };
  trainingDatasetSize: number;
  feedbacks: number;
}

export async function getDashboardData(): Promise<DashboardData> {
  // Python backend: GET /api/web/dashboard
  return apiGet<DashboardData>("/api/web/dashboard");
}
