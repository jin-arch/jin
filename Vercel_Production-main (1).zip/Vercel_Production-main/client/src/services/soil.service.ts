import type { Soil } from "@/constants/soils";
import { apiDelete, apiGet, apiPost, apiPut } from "./api";

export async function getSoils(): Promise<Soil[]> {
  return apiGet<Soil[]>("/api/web/soils");
}

export async function getSoilById(id: string): Promise<Soil | null> {
  return apiGet<Soil>(`/api/web/soils/${id}`);
}

export async function deleteSoil(id: string): Promise<void> {
  await apiDelete(`/api/web/soils/${id}`);
}

export async function createSoil(
  soilData: Omit<
    Soil,
    "id" | "dateCreated" | "status" | "verificationMethod" | "suitabilityScore"
  > & {
    suitability: "SUITABLE" | "NEEDS_IMPROVEMENT";
  }
): Promise<Soil> {
  return apiPost<Soil>("/api/web/soils", soilData);
}

export async function updateSoil(
  id: string,
  soilData: Omit<
    Soil,
    "id" | "dateCreated" | "status" | "verificationMethod" | "suitabilityScore"
  > & {
    suitability: "SUITABLE" | "NEEDS_IMPROVEMENT";
  }
): Promise<Soil> {
  return apiPut<Soil>(`/api/web/soils/${id}`, soilData);
}
