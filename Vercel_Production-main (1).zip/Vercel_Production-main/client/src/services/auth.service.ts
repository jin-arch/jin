import { apiPost, API_BASE_URL } from "./api";

function apiUnreachableHint(): string {
  if (API_BASE_URL) return API_BASE_URL;
  if (import.meta.env.DEV) {
    return "Vite dev proxy → Express (start EcoFarm server on port 5000, or set VITE_API_PROXY_TARGET in .env)";
  }
  return "production build without VITE_API_BASE_URL (rebuild with VITE_API_BASE_URL=https://YOUR-EXPRESS-SERVICE.up.railway.app)";
}

// Types
export interface LoginCredentials {
  username: string;
  password: string;
}

export interface LoginResponse {
  token: string;
  user: {
    id: string;
    username: string;
    email: string;
    role: string;
  };
}

export interface ApiError {
  message: string;
  status?: number;
}

export async function loginService(
  credentials: LoginCredentials
): Promise<LoginResponse> {
  try {
    // If a Vite admin key is provided (dev convenience), include it in the login payload.
    const envAdminKey = typeof import.meta.env.VITE_ADMIN_KEY === 'string' ? import.meta.env.VITE_ADMIN_KEY.trim() : '';
    const payload: any = { ...(credentials as any) };
    if (envAdminKey && !payload.adminKey) {
      payload.adminKey = envAdminKey;
    }

    return await apiPost<LoginResponse>("/api/web/auth/login", payload);
  } catch (error: unknown) {
    const err = error as { message?: string; name?: string };
    let message = err?.message || "Invalid username or password";
    if (err?.name === "TypeError" || /failed to fetch|networkerror|load failed/i.test(message)) {
      message = `Cannot reach the API (${apiUnreachableHint()}). The old default host was an ML-only service — use the URL of your Node/Express Railway service.`;
    }
    const apiError: ApiError = {
      message,
      status: 401,
    };
    throw apiError;
  }
}

export async function logoutService(): Promise<void> {
  return Promise.resolve();
}

export async function refreshTokenService(
  token: string
): Promise<LoginResponse> {
  const storedUser = localStorage.getItem("user");
  const parsedUser = storedUser ? JSON.parse(storedUser) : null;

  if (!parsedUser) {
    throw {
      message: "No user session available",
      status: 401,
    } as ApiError;
  }

  return {
    token,
    user: parsedUser,
  };
}
