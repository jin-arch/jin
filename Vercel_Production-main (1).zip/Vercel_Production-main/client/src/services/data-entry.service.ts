import type { DataEntry } from "@/constants/data-entries";
import { apiGet } from "./api";

/**
 * Fetches all user scan entries from the backend.
 */
export async function getDataEntries(): Promise<DataEntry[]> {
  return apiGet<DataEntry[]>("/api/web/data-entries");
}
