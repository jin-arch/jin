// Service to fetch all user scans from Flask admin endpoint
import axios from "axios";

const FLASK_API_BASE = (import.meta.env.VITE_FLASK_API_BASE_URL as string) || "https://web-production-b538b.up.railway.app";
const ADMIN_KEY = (import.meta.env.VITE_ADMIN_KEY as string) || "ecoadmin";

export async function fetchAllScans() {
  const res = await axios.get(`${FLASK_API_BASE}/api/admin/all-scans`, {
    headers: {
      "X-Admin-Key": ADMIN_KEY,
    },
    withCredentials: false,
  });
  if (res.data && res.data.success) {
    // Normalize records to the DataEntry shape expected by the dashboard
    const raw: any[] = res.data.scans || [];
    const normalized = raw.map((s: any, idx: number) => {
      const scanId = s.id || s.scan_id || s.filename || s.scanId || `scan-${idx}`;
      const userId = s.user_id || s.userId || s.__uid || s.user || 'unknown';
      const ts = s.timestamp || s.created_at || s.date || s.time || null;
      // Format date in Philippine timezone (Asia/Manila)
      let dateCaptured = '';
      if (ts) {
        try {
          dateCaptured = new Date(ts).toLocaleString('en-PH', { timeZone: 'Asia/Manila' });
        } catch {
          dateCaptured = new Date(ts).toLocaleString();
        }
      }
      const imageUrl = s.image_url || s.imageUrl || s.image || s.imageUrlRaw || '';
      const location = s.location || (s.locationCoords ? `${s.locationCoords.latitude}, ${s.locationCoords.longitude}` : '') || '';

      const recommendations =
        s.recommendations || s.recommendation || s.fullResponse?.recommendations || s.fullResponse?.result?.recommendations || [];
      const confidence = s.confidence || (s.fullResponse && s.fullResponse.confidence) || 0;
      const score = s.score || s.fullResponse?.score || Math.round((confidence || 0) * 100);
      const healthLevel =
        s.healthLevel ||
        (s.health_assessment && (s.health_assessment.health_level || s.health_assessment.level)) ||
        (s.fullResponse && (s.fullResponse.healthLevel || s.fullResponse.health || s.fullResponse.health_assessment?.health_level)) ||
        (s.condition) ||
        (confidence >= 0.85 ? 'Excellent' : confidence >= 0.65 ? 'Good' : confidence >= 0.4 ? 'Fair' : 'Poor');

      return {
        id: scanId,
        scanId: scanId,
        userId,
        dateCaptured,
        location,
        status: 'ACTIVE',
        imageUrl,
        recommendations,
        analysis: {
          healthLevel: healthLevel,
          scoreDisplay: String(score),
          soilTexture: s.soil_type || s.analysisResult || '',
          textureSuitability: s.textureSuitability || '',
          soilColor: s.soilColor || s.fullResponse?.result?.soil_color?.primary || s.fullResponse?.result?.soil_color || '',
          soilColorNote: s.soilColorNote || s.fullResponse?.result?.soil_color?.note || '',
        },
        // keep raw payload for detail view
        _raw: s,
        // user profile fields (enriched by server)
        userProfile: s.user_profile || s.userProfile || {
          contactNumber: s.contactNumber || s.contact_number || null,
          biography: s.biography || s.bio || null,
          location: s.location || null,
        },
      };
    });

    return normalized;
  }
  throw new Error(res.data?.error || "Failed to fetch scans");
}
