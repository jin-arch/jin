import type { User } from "@/constants/users";
import { API_BASE_URL, apiDelete, apiGet, apiPost } from "./api";

async function parseJson<T>(response: Response): Promise<T> {
  const data = await response.json().catch(() => null);
  if (!response.ok) {
    const message = data?.error || data?.message || `Request failed (${response.status})`;
    throw new Error(message);
  }
  return data as T;
}

export async function getUsers(): Promise<User[]> {
  const res = await apiGet<any>("/api/web/users");
  if (Array.isArray(res)) return res as User[];
  return (res?.users as User[]) || [];
}

export async function getUserById(id: string): Promise<User | null> {
  return apiGet<User>(`/api/web/users/${id}`);
}

export async function deleteUser(id: string): Promise<void> {
  await apiDelete(`/api/web/users/${id}`);
}

export async function disableUser(id: string, disabled = true): Promise<{ success: boolean; uid?: string; disabled?: boolean }> {
  return apiPost(`/api/admin/users/${encodeURIComponent(id)}/disable`, { disabled });
}

/** Admin: upload a new profile picture for any user (multipart). */
export async function uploadUserProfilePhoto(
  userId: string,
  file: File
): Promise<{ photoURL: string }> {
  const token = localStorage.getItem("auth_token");
  const formData = new FormData();
  formData.append("photo", file);

  const response = await fetch(`${API_BASE_URL}/api/web/users/${userId}/photo`, {
    method: "POST",
    headers: token ? { Authorization: `Bearer ${token}` } : {},
    body: formData,
  });

  return parseJson<{ photoURL: string }>(response);
}

/**
 * Mask email address (shows first part and hides the rest)
 */
export function maskEmail(email: string): string {
  const [localPart, domain] = email.split("@");
  if (!domain) return email;

  // Show first few characters and mask the rest
  const visibleChars = Math.min(4, localPart.length);
  const masked = "*".repeat(Math.max(4, localPart.length - visibleChars));
  return `${localPart.substring(0, visibleChars)}${masked}@${domain.substring(
    0,
    2
  )}***`;
}
