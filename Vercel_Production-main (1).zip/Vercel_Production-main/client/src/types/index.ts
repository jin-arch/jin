// Global TypeScript types
export type {};
