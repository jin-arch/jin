import { z } from "zod";

// Example validation schemas
export const exampleFormSchema = z.object({
  email: z.string().email("Invalid email address"),
  password: z.string().min(8, "Password must be at least 8 characters"),
});

export type ExampleFormData = z.infer<typeof exampleFormSchema>;
