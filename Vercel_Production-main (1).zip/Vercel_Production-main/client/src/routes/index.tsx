import type { RouteObject } from "react-router-dom";
import { Navigate } from "react-router-dom";
import { HomePage } from "@/pages/home";
import { LoginPage } from "@/pages/login";
import { DashboardPage } from "@/pages/dashboard";
import { UserManagementPage } from "@/pages/dashboard/users";
import { DataManagementPage } from "@/pages/dashboard/data";
import { RequireAuth } from "@/components/auth/require-auth";

export const routes: RouteObject[] = [
  {
    path: "/",
    element: <Navigate to="/login" replace />,
  },
  {
    path: "/login",
    element: <LoginPage />,
  },
  {
    path: "/home",
    element: <HomePage />,
  },
  {
    path: "/dashboard",
    element: (
      <RequireAuth>
        <DashboardPage />
      </RequireAuth>
    ),
  },
  {
    path: "/dashboard/users",
    element: (
      <RequireAuth>
        <UserManagementPage />
      </RequireAuth>
    ),
  },
  {
    path: "/dashboard/data",
    element: (
      <RequireAuth>
        <DataManagementPage />
      </RequireAuth>
    ),
  },
  {
    path: "/dashboard/soil",
    element: <Navigate to="/dashboard/data" replace />,
  },
  {
    path: "/dashboard/crops",
    element: <Navigate to="/dashboard/data" replace />,
  },
  // System (Model Performance) route removed from navigation - not used in the simplified dashboard
];
