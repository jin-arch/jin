# ECOFARMAI Web

A modern React + TypeScript application built with Vite, following Atomic Design principles.

## Tech Stack

- **React 19** with **TypeScript**
- **Vite** - Build tool and dev server
- **Tailwind CSS** - Utility-first CSS framework
- **shadcn/ui** - Component library
- **React Router DOM** - Client-side routing
- **TanStack Query** - Data fetching and state management
- **React Hook Form** - Form management
- **Zod** - Schema validation
- **Lucide React** - Icon library
- **React Icons** - Additional icons

## Project Structure

```
src/
├── app/                  # App initialization, providers, React Query setup
├── routes/               # React Router route definitions
├── pages/                # Page-level components
├── components/
│   ├── atoms/           # Basic building blocks (Button, Input, etc.)
│   ├── molecules/       # Simple component groups (FormField, etc.)
│   ├── organisms/       # Complex components (Forms, Cards, etc.)
│   ├── templates/       # Page templates
│   └── ui/              # shadcn/ui components
├── features/             # Feature-based logic
├── hooks/                # Custom reusable hooks
├── validations/          # Zod schemas
├── store/                # React Query / global state
├── lib/                  # External library configurations
├── utils/                # Helper functions
├── constants/            # App constants
├── types/                # Global TypeScript types
└── styles/               # Global styles
```

## Getting Started

### Installation

```bash
npm install
```

### Development

```bash
npm run dev
```

### Build

```bash
npm run build
```

### Preview

```bash
npm run preview
```

## Architecture Principles

### Atomic Design

The project follows Atomic Design principles:

- **Atoms**: Basic building blocks (Button, Input, Label)
- **Molecules**: Simple component groups (FormField = Label + Input + Error)
- **Organisms**: Complex components (Forms, Cards with multiple molecules)
- **Templates**: Page layouts
- **Pages**: Complete pages using templates and organisms

### Form Management

- All forms use `react-hook-form` with `useForm` hook
- Validation schemas are defined in `src/validations/` using Zod
- Form logic is kept in custom hooks in `src/hooks/`
- UI components remain presentational

### Best Practices

- Strong TypeScript typing everywhere
- Components are reusable and composable
- Separation of concerns: UI, logic, and validation
- Clean, maintainable, and production-ready code

## Adding shadcn/ui Components

To add new shadcn/ui components:

```bash
npx shadcn@latest add [component-name]
```

Components will be added to `src/components/ui/`.

## License

MIT
