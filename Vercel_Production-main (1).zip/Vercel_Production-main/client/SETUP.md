# Setup Guide

## shadcn/ui Setup

This project is configured for shadcn/ui. To add new components:

```bash
npx shadcn@latest add [component-name]
```

For example:

```bash
npx shadcn@latest add button
npx shadcn@latest add card
npx shadcn@latest add dialog
```

Components will be automatically added to `src/components/ui/` and can be imported from there.

## Project Structure Guidelines

### Atomic Design Principles

1. **Atoms** (`src/components/atoms/`)

   - Basic building blocks
   - Examples: Button, Input, Label, Icon
   - Should be highly reusable

2. **Molecules** (`src/components/molecules/`)

   - Simple combinations of atoms
   - Examples: FormField (Label + Input + Error), SearchBar
   - Should handle simple interactions

3. **Organisms** (`src/components/organisms/`)

   - Complex components combining molecules and atoms
   - Examples: Forms, Navigation, Cards with multiple sections
   - Should handle complex logic

4. **Templates** (`src/components/templates/`)

   - Page layouts and structure
   - Examples: PageLayout, DashboardLayout
   - Should define page structure

5. **Pages** (`src/pages/`)
   - Complete pages using templates and organisms
   - Examples: HomePage, LoginPage
   - Should be route-specific

### Form Management

1. **Validation Schemas** (`src/validations/`)

   - Define Zod schemas for form validation
   - Export types from schemas

2. **Form Hooks** (`src/hooks/`)

   - Custom hooks using `useForm` from react-hook-form
   - Handle form logic and submission
   - Use zodResolver for validation

3. **Form Components** (`src/components/organisms/`)
   - Presentational form components
   - Use form hooks for logic
   - Keep UI separate from business logic

### Example Form Structure

```typescript
// src/validations/login.ts
import { z } from "zod";
export const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
});
export type LoginFormData = z.infer<typeof loginSchema>;

// src/hooks/use-login-form.ts
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { loginSchema, type LoginFormData } from "@/validations/login";

export function useLoginForm() {
  const form = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
    defaultValues: { email: "", password: "" },
  });

  const onSubmit = (data: LoginFormData) => {
    // Handle submission
  };

  return { form, onSubmit: form.handleSubmit(onSubmit) };
}

// src/components/organisms/login-form/login-form.tsx
import { useLoginForm } from "@/hooks/use-login-form";
import { Button } from "@/components/atoms/button";
import { Input } from "@/components/atoms/input";
import { FormField } from "@/components/molecules/form-field";

export function LoginForm() {
  const { form, onSubmit } = useLoginForm();
  const {
    register,
    formState: { errors },
  } = form;

  return (
    <form onSubmit={onSubmit}>
      <FormField label="Email" error={errors.email?.message}>
        <Input {...register("email")} />
      </FormField>
      {/* ... */}
    </form>
  );
}
```

### React Query Usage

```typescript
// src/hooks/use-data.ts
import { useQuery } from "@tanstack/react-query";

export function useData() {
  return useQuery({
    queryKey: ["data"],
    queryFn: async () => {
      const res = await fetch("/api/data");
      return res.json();
    },
  });
}

// In component
const { data, isLoading, error } = useData();
```

## Best Practices

1. **TypeScript**: Use strict typing everywhere
2. **Components**: Keep components presentational, logic in hooks
3. **Validation**: All validation in `src/validations/` using Zod
4. **Forms**: Always use `react-hook-form` with `useForm`
5. **State**: Use React Query for server state, React state for UI state
6. **Styling**: Use Tailwind CSS utility classes, shadcn/ui for components
7. **Imports**: Use path aliases (`@/`) for cleaner imports
